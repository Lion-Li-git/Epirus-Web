/* Epirus — 对抗自对战训练器（轻量进化锦标赛）。
 * 候选策略每代与「当前冠军 + 脚本基准」对战打分；精英保留 + 变异/交叉；
 * 最强挑战者与冠军加赛，胜率 ≥55% 才换冠军（对抗门控）。同步计算，UI 分帧调用。
 */
(function (global) {
  'use strict';
  const R = global.EpirusRules;
  const S = global.EpirusState;
  const Play = global.EpirusPlay;
  const P = global.EpirusPolicy;
  const Bots = global.EpirusBots;
  /* v7：这个包是"旧形状"吗（v5/v6 的动作段只有 14 维 ⇒ 候选新增维度会被忽略）。
   * 旧包一律走**旧口径**（键 + pickTargetN 目标），否则历史基线（eco-34 的 41.4%）不可比。 */
  function LEGACY(params) {
    /* v1.5.19：`params` 可能为 null —— 健康门槛拒绝首次提升时 `t.champion` 会短暂为 null，
     * 而 champVsBaseline 会拿它去建 chooser ⇒ 旧写法直接 TypeError（实测 train-best 崩在这里）。
     * 防御性判空：null 一律按"旧口径"处理（宁可用错口径，也不要整条训练线崩掉）。 */
    if (!params) return true;
    /* v1.5.64：**容器显式标记优先**（嵌入 v7 的旧冠军仍必须走旧口径，否则目标退化）。 */
    if (P.isLegacyChooser && P.isLegacyChooser(params)) return true;
    const sh = P.shapeOf(params);
    return !sh || sh.legacy === true;
  }

  /* ===== 训练模式（v1.5.0）=====
   * `oneGameN` 从 v1.4.0 起就支持 `opts.mode`，但**训练路径没有一处传它**（19 个调用点里
   * 唯一传过的是评测工具 eval-5p.mjs）⇒ 历次训练（hA9 / hB12 / wall2 / ms2 / ring2…）
   * 全部按 'multi'（3 血）建局，"5 血冠军"从来没被训过；产物 meta 里连模式字段都没有，
   * 因为那个值是永远不变的默认值。
   * 这里由**调用方**显式设置 —— 沿用 setWrTol 的模式：引擎内不读 process.env
   * （np-test L3 守护这条），默认 'multi' ⇒ 既有路径逐位不变。
   * 反证（np-test D10）：把下面任意一处 mode 传参删掉，D10 立刻红。 */
  let TRAIN_MODE = 'multi';
  function setTrainMode(m) { if (m && R.MODES && R.MODES[m]) TRAIN_MODE = m; return TRAIN_MODE; }
  function trainMode() { return TRAIN_MODE; }

  /* ===== 风格表现切片：复合适应度（v1.5.2）=====
   * 动机：两次"改对手池"的干预都落空（ring2 加 1 个脚本对手、mix 加 4 个真实风格冠军），
   * 而且后者还**摊薄**了每个对手的练习量。所以这里**不改池子**：在每个个体身上**追加** k 局
   * 对风格冠军的局（在池子预算之外 ⇒ 不摊薄），把 1st 率作为**有界加分**并进 fit。
   * 为什么不是替换 fit：这些局走**原生规则**（regen=0、无补贴），量的是真实强度 ⇒
   * 是诚实的复合目标，不会把人推向"只在特殊口径下成立"的策略（§5.2 的教训）。
   * 由**调用方**显式设置（与 setWrTol/setTrainMode 同一模式），默认关闭 ⇒ 既有路径逐位不变。
   * 反证（np-test D13）：把 scoreMemberN 里的 styleGames 记账删掉，D13 立刻红。 */
  let STYLE_OPPS = null, STYLE_W = 0, STYLE_GAMES = 0;
  function setStyleSlice(opps, w, games) {
    STYLE_OPPS = (opps && opps.length) ? opps : null;
    STYLE_W = (typeof w === 'number' && w > 0) ? w : 0;
    STYLE_GAMES = (typeof games === 'number' && games > 0) ? (games | 0) : 0;
    if (!STYLE_OPPS) { STYLE_W = 0; STYLE_GAMES = 0; }   // 没有对手就整体关闭（避免"权重在、对手没了"的半开状态）
    return styleSlice();
  }
  function styleSlice() {
    return { w: STYLE_W, games: STYLE_GAMES, n: STYLE_OPPS ? STYLE_OPPS.length : 0 };
  }

  /* v1.5.52: per-game slot salt. The tie-break order of opponent slots must be
   * UNPREDICTABLE across games in training, otherwise the net can learn "slot 0 = seat X"
   * (L7: no deterministic identity mapping in ties). Salt is a pure function of the
   * seed/game index => the same experiment stays reproducible, and no random stream is
   * consumed (so sampling and game behaviour are untouched). */
  function slotSaltFor(seed) {
    let h = (Math.imul((seed | 0) + 1, 0x9e3779b9) ^ 0x5bf03635) >>> 0;
    h ^= h >>> 15; h = Math.imul(h, 0x2c1b3c6d) >>> 0; h ^= h >>> 13;
    return h >>> 0;
  }

  /* v1.5.65 曾在这里放"4 席全被动"暴露注入（`EPIRUS_PASSIVE_FIELD`），**于 v1.5.163 整族删除**（用户裁定）。
   * 墓碑留两行就够，但别删：那段机制**自落地起一局都没开过火** —— 消费点查 `BOT_PICKS['farmer'|'deepsaver']`，
   * 而那张表从来没有这两个键（它是对手池注册表，加键会改默认训练）；两道门都判在**变量**上（序号谓词 + 横幅读回），
   * 没一道判在**效果**上 ⇒ 白跑两臂才被查出（§N11）。真要做收割压力请看下面的 `KILL_FIELD`，来龙去脉见 CHANGELOG v1.5.160/163。 */

  /* ===== v1.5.160（qoder §N13 · 用户 09-22 裁定"场B 缺口走对手池"）：收割席注入 =====
   * 要买的东西：7′ 的 3P 只挂"场B 清场 0.10 < 0.3/局"，而**现役 cmin4 同读法是 0.33** ⇒ 缺口是候选自己的。
   * 奖励侧已否证过（§N8 的 `xn10b`：`CLEAR_W` 一生效，带内最高分被"纯ジ龟包"拿走 ⇒ **奖励收割 ≠ 学会收割**）
   * ⇒ 只能从**环境**买：桌上放一个**会跟你抢收割**的对手（`pickKillSecure`，v1.5.156），
   *   "该打死的不打死，别人替你打" ⇒ 转化才有价格。
   * 三条设计约束，全部来自 §N11/§N12 用两臂白跑换来的教训：
   *   ① 取函数**直接走 `Bots.pickKillSecure`**，不查 `BOT_PICKS`（那是对手池注册表，`buildOpps`/`champVsBaseline`
   *      都 `Object.keys` 它 ⇒ 往里加键会顺带改默认池与基线均值，`evo.js:1799` 自己警告过）；
   *   ② **每局只注 1 席**（不是 v1.5.65 那条已删注入的 4 席全注）——要的是"抢收割的对手"，不是一桌木桩；
   *      而且注的**必须是会还手的**：用户 09-22 明说"囤一点 ep 放大招也是有好处的"⇒ 只攒不打的 `farmer`
   *      当陪练等于"出一道没有反击的题"，罚的是正常打法（D123 把这条钉成门）。
   *   ③ **去座位偏置**：v1.5.65 那条注入的默认 1/8 在 `GAMES=8` 下恒落在 `g=0` ⇒ 恒 0 号座（`seat=g%n`）、
   *      恒偶数 ⇒ 只喂 farmer、且 g=0 同时是**不进 fit 的承诺局**（三处错位）。这里相位按代旋转
   *      （步长 3 与 games=8 / n=5 互质）、注的席位由 `(gen+g)` 决定并**避开受评席本身**、且**跳过承诺局**。
   * **默认 0 = 一个都不注 ⇒ 历史臂逐位不变 ✓**（这路方向是新语义，必须显式下达）。
   * `countKillSeats()` 是 §N12 的教训的机器化：**setter + 横幅读回证明不了作用点开火**，必须有开火计数。 */
  /* ===== §E798（10-27 夜班 · 千问）：训练桌形状 `EPIRUS_FAMILY_FIELD=<k>`（默认 0 ⇒ 历史臂逐字不变）=====
   * 语义：每局 `n-1` 个非受评席里，**k 席换成受评个体自己的副本**（同一个 `params`、同一个适应度用的 chooser），
   *   其余席仍是脚本对手 ⇒ `k=3`（5 人桌）就是考卷那张桌的形状：**4 席同包 + 1 席外部人**。
   * 动因（09-19 的 v1.5.133 预注册留下的后半句，从没跑过；原文见 `js/train/bots.js:967` 那段注释尾）：
   *   训练桌"1 候选 vs 4 外部"里枪手子弹只有约 1/4 落在我方，考卷"4 席被测 vs 1 席枪手"里全落在被测家族；
   *   ⇒ "时机性反弹 / 破防当回合有人兑现"这种**条件于对手类型**的行为，在没有"我方被集中打"经验的桌上长不出来。
   *   今夜段一（§E797）的外生证据：把这条规则硬写进决策（"最近真被枪打过才弹"）能把 8 个只枪格全部压进 ≤60%，
   *   而 `BLOCK_W` 两臂连反弹次数都没抬 ⇒ 缺的可能是**经验分布**，不是权重。本旋钮就是去量这一件事。
   * ⚠ 三条边界：① 只动**适应度桌**（主训练路 + 风格切片两处）；三把评测尺 `evalEconProbe` ‖ `evalSubsidyProbe` ‖
   *   `evalN` 一字不动 —— 否则考卷跟着桌子一起变，"无短板"就不再是同一件事；② 家族席**不进 econ 包装**
   *   （不吃补贴、不吃强迫、不吃模仿），它们是"同一个策略的副本"，不是"另一个被喂的个体"；
   *   ③ 席位按代旋转（`(g+gen)` 起算）且必留 1 席外部人，照 v1.5.186 `sliceHit` 那条教训 —— 相位不旋转就会与
   *   `g % n` 锁死，把座位运气读成策略差异。作用计数照 §N12/`KILL_FIELD` 先例：`countFamilyField()` 报注了几局几席，
   *   CLI 侧 0 局 ⇒ `exit 8`（横幅读回 ≠ 作用点开火）。 */
  let FAMILY_FIELD = 0;
  const FAM_STAT = { games: 0, seats: 0, bySeat: {} };
  function setFamilyField(v) {
    const k = Number(v);
    FAMILY_FIELD = (isFinite(k) && k >= 1) ? Math.floor(k) : 0;
    return FAMILY_FIELD;
  }
  function familyField() { return FAMILY_FIELD; }
  function countFamilyField() {
    return { field: FAMILY_FIELD, games: FAM_STAT.games, seats: FAM_STAT.seats, bySeat: Object.assign({}, FAM_STAT.bySeat) };
  }
  /** 本局哪些非受评席走家族副本 ⇒ Set。默认关（或桌子放不下）⇒ 空集，旧路径一行不多跑。 */
  function familySeatSet(g, gen, n, seat, k) {
    const out = new Set();
    if (!k || k <= 0 || n < 3) return out;
    const others = [];
    for (let pid = 0; pid < n; pid++) if (pid !== seat) others.push(pid);
    const kk = Math.min(k, others.length - 1);      // 至少留 1 席外部人
    if (kk <= 0) return out;
    const off = ((((g + (gen || 0)) % others.length) + others.length) % others.length);
    for (let i = 0; i < kk; i++) out.add(others[(off + i) % others.length]);
    return out;
  }
  let KILL_FIELD = 0, KILL_EVERY = 0;
  const KILL_STAT = { fired: 0, seats: {}, names: {} };
  function setKillField(v) {
    const n = Number(v);
    KILL_FIELD = (isFinite(n) && n > 0) ? Math.min(1, n) : 0;
    KILL_EVERY = KILL_FIELD > 0 ? Math.max(2, Math.round(1 / KILL_FIELD)) : 0;
    return KILL_FIELD;
  }
  function killField() { return KILL_FIELD; }
  function countKillSeats() {
    return { fired: KILL_STAT.fired, seats: Object.assign({}, KILL_STAT.seats), names: Object.assign({}, KILL_STAT.names) };
  }
  /* ===== v1.5.186（qoder 复核 DS 交接 §3 坑#8）：切片相位必须按代旋转，否则**与座位轮换锁死** =====
   * 病（实测，不是推断）：受评席是 `seat = g % n`，而承诺局用 `g % 3`、补贴局用 `g % step` ⇒
   *   **n=3 时 `g ≡ c (mod 3)` 把 `g % 3` 钉成同一个常数** ⇒ 每代补贴/示范只落在同一个席位上：
   *   示范注入覆盖席 `{0:236, 1:20, 2:1}`（**92% 在 0 号席**）；n=5·每代 12 局时 **2 号席整晚一次都没拿到**（`{0:32,1:43,3:80,4:49}`）。
   *   ⇒ 一切"给钱/示范"类读数都混着席位运气 —— 而"这个席位"恰恰不是任何判据想问的问题
   *   （用户 09-22 已就同族病裁过："要么删掉，要么调整成不至于座位偏置"）。
   * 修法：相位按代旋转（与 v1.5.160 `killSeatFor` 的 `(g + gen*3)` 同一招），并且**收成一个单一来源 `sliceHit`** ——
   *   原来"承诺局"这个概念在 `killSeatFor` 与 `scoreMemberN` 各写了一遍 `g % 3 === 0`，那正是本仓栽过四次的"两处各写一遍"。
   * ⚠️ 不传 `gen` ⇒ 相位 0 ⇒ 与旧版逐字相同（历史臂仍可复现）；调用点必须**显式把 gen 传进来**。 */
  function sliceHit(g, step, gen) {
    /* ⚠ 这一行是全仓**唯一**的切片地板（"每局都补"不允许存在）：v1.7.158 起 `regenForGame` 不再自己夹一次。
     *   要改这个下限只许改这里 —— 在调用方再夹一次 = 回到"摘一处不红"那枚形状（D132 的判据注释记着那次实测）。 */
    const s = Math.max(2, Number(step) || 2);
    return ((((g + (gen || 0)) % s) + s) % s) === 0;
  }
  /** 承诺局（每 3 局 1 局，h 来自基因）—— 唯一判据，别处不许再写 `% 3` */
  function isCommitGame(g, gen, hGene) { return hGene > 0 && sliceHit(g, 3, gen); }
  /** 本局要不要注、注在第几席；-1 = 不注。 */
  function killSeatFor(g, gen, seat, n, hGene) {
    if (KILL_EVERY === 0 || n < 3) return -1;   // **只注多人局**：2P 那条切片的全部意义是"对着考卷基准打"（v1.5.150），
                                                // 2P 只有 1 个对手席，注进去等于把参照换掉 ⇒ 目标与验收就不一致了。
    if (((g + gen * 3) % KILL_EVERY) !== 0) return -1;
    if (isCommitGame(g, gen, hGene)) return -1;   // 承诺局一分不进 fit ⇒ 注了也白注（v1.5.186：与 scoreMemberN 同一个判据）
    return (seat + 1 + ((gen + g) % (n - 1))) % n;
  }
  function killSeatBot() {
    return (Bots && typeof Bots.pickKillSecure === 'function') ? Bots.pickKillSecure : null;
  }
  /* v1.7.158：注入名单里的名字改成**从真被叫到的那个函数反查注册名**（原来 `KILL_STAT.names.killsecure` 那个键是写死的标签）。
   * 动因（10-22 门禁审查第十二批实测）：把 `killSeatBot()` 换成 `pickFarmer` 之后，旧标签照旧印 `killsecure`，
   * 而"注入席到底调了谁"这件事当时**只有**测试里那层注册表包装接得住 ⇒ 引擎自己的收据在说谎（或者说，它根本没在测量）。
   * ⚠ 为什么要处理"同一个函数挂在两个键上"：按 `===` 实测今天的注册表是 **53 个键 / 53 个不同函数**（没有别名），
   *   但"兼容用的第二个名字"在本仓是有先例的一类东西（`D191` 那条量具就是为此存在的）。
   *   默默取第一个 = 把"名单"重新变成一枚标签 ⇒ 全部列出，让别名**看得见**而不是被选中。
   * ⚑ 顺带记一笔我自己的坑：第一版我用 `byFn[functionObject] = …` 分组，得到"53 键 / 50 函数、两组别名"——那是**假读数**，
   *   因为对象键会把函数**强转成它的源码字符串**，而 `makeRhythm([...])` 造出来的几个闭包源码逐字相同 ⇒ 被并成一组。
   *   真别名要用 `===` 两两比（门里 ②c 那格改成"自己造一个别名再反查"，不去赌注册表里有没有别名）。 */
  function botRegisteredName(fn) {
    if (!fn || typeof fn !== 'function' || !Bots) return 'anonymous';
    const hits = [];
    for (const nm of Object.keys(Bots)) { if (Bots[nm] === fn) hits.push(nm); }
    if (hits.length === 0) return 'anonymous';
    if (hits.length === 1) return hits[0];
    return hits.sort().join('+');
  }

  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function policyChooser(params, temp) {
    return function (state, pid, legal) {
      // 只在"可负担"技能里选：AI 绝不主动贷款自爆
      const aff = legal.filter(function (l) { return l.affordable; });
      const base = aff.length ? aff : [{ key: R.SK.JI, affordable: true }];
      /* v7：**旧包走旧口径、新包走候选**。
       * 旧包（v5/v6）的动作段只有 14 维 ⇒ 候选新增的 8 维会被完全忽略，但"目标怎么选"会变；
       * 为了让历史基线（如 eco-34 的 41.4%）保持逐位可比，旧包必须继续用 pickTargetN 那套启发式。 */
      if (LEGACY(params)) return P.choose(state, pid, base, params, { temp: temp });
      const cands = P.candidatesFor(state, pid, base, { lockTarget: lastCancelOther(state, pid) });
      return P.chooseCandidates(state, pid, cands, params, { temp: temp });
    };
  }
  const BOT_PICKS = {
    aggro: Bots.pickAggro, defend: Bots.pickDefend,
    balanced: Bots.pickBalanced, random: Bots.pickRandom,
    breakdef: Bots.pickBreakDef,
    mix: Bots.pickMix, wall: Bots.pickWall,
    reflectspam: Bots.pickReflectSpam, guardspam: Bots.pickGuardSpam, baguaspam: Bots.pickBaguaSpam, combocounter: Bots.pickComboCounter,
    tankline: Bots.pickTankLine, heavyfire: Bots.pickHeavyFire, guardgun: Bots.pickGuardGun,
    protowall: Bots.pickProtoWall, whiff: Bots.pickWhiff,
    reflectmix: Bots.pickReflectMix, reflecttank: Bots.pickReflectTank, defreflectgun: Bots.pickDefReflectGun,
    /* ===== v1.5.130：**珠爆发线**（ジ→蓄电珠→电磁炮，残血摄魂）—— 进**默认池**是有意的例外 =====
     * 它把当时的线上 2P 冠军打到 **100% 胜**（探针 `tools/probe-beadburst.mjs`：100.0% / 均 9.2 回合）。
     * `np-test` 的判词里写着"不许往默认池加键"，那条纪律针对的是 `ringspam` 这类**专精**
     * （加进来会改变所有后续训练的分布，而它并非"打穿线上包"的线）。这里的理由**相反**：
     *   ① 它是**实测打穿线上包**的线 —— 不进来就等于"训练永远看不见自己最大的洞"；
     *   ② v7 特征**本来就有**"对手持珠 / 对手刚蓄能"的输入（`policy.js:208-212` / `:242` / `:259`），
     *      缺的只是"对手池里从没人这么干过"这条梯度。
     * ⚠️ **代价要说清**：池子分布变了 ⇒ 之后所有 2P 训练臂的数字与本版之前**不可直接比**
     *    （先例 v1.5.119：动了对手池，代价落在场B 清场）。 */
    beadburst: Bots.pickBeadBurst
  };
  // 硬门槛：任何一条基准 <50% 的候选一律不许当冠军（否则"对某类打法更脆"会被 avg 平均掉）。
  // 起初只挡人类式三条，实测仍放过"永久防御 50% / 永久反弹 27%"这类洞，故扩到全部基准。
  const GATE_ALL = true;

  function oneGame(aSel, bSel, seed, mode) {
    const st = S.createState(mode || 'standard', { next: mulberry32(seed) });
    st.slotSalt = slotSaltFor(seed);
    Play.autoGame(st, aSel, bSel);
    const dmg = [0, 0];
    for (const e of st.events) if (e.type === 'damage') dmg[e.to] = (dmg[e.to] || 0) + e.amt;
    return { winner: st.winner, rounds: st.round, dmg };
  }

  /* a 相对 b 的胜率（含换边公平化）。games 建议偶数。 */
  function correctedWinRate(aSel, bSel, games, seedBase) {
    let w = 0, d = 0, l = 0;
    for (let i = 0; i < games; i++) {
      const aIsP0 = i % 2 === 0;
      const r = aIsP0 ? oneGame(aSel, bSel, seedBase + i) : oneGame(bSel, aSel, seedBase + i);
      if (r.winner === 'draw') d++;
      else if (aIsP0) { if (r.winner === 0) w++; else l++; }
      else { if (r.winner === 1) w++; else l++; }
    }
    return { w, d, l, wr: games ? (w + d * 0.5) / games : 0 };
  }

  function makeTrainer(opts) {
    opts = opts || {};
    const t = {
      popSize: opts.popSize || 14,
      gamesPerOpp: opts.gamesPerOpp || 5,
      playoffGames: opts.playoffGames || 30,
      elite: opts.elite || 4,
      sigma: opts.sigma || 0.18,
      mode: opts.mode || 'standard',
      gen: 0,
      champion: opts.champion || P.makePolicy(0.2),
      championAge: 0,
      bestParams: null,
      bestChamp: null, bestChampScore: -1, bestChampAttack: 0,
      pop: [],
      history: [],
      baselineEvery: opts.baselineEvery || 5,
      lastTop: [],          // 最近一代按 shaped 分排序的前3个个体 params（用于末尾真实胜率择优）
      running: false
    };
    for (let i = 0; i < t.popSize; i++) {
      t.pop.push({ params: P.makePolicy(0.25), score: 0, attackGames: 0, attackRate: 0 });
    }
    return t;
  }

  function seedOf(t, i, tag) {
    let h = 17;
    const s = String(t.gen * 7919 + i * 104729 + tag.length * 31);
    for (let k = 0; k < s.length; k++) h = (h * 31 + s.charCodeAt(k)) >>> 0;
    return h;
  }

  /* 构建每代的对手池（champion + 脚本基准），含权重。 */
  function buildOpps(championParams, temp) {
    return [
      { name: 'champion', w: 1.5, sel: policyChooser(championParams, temp || 0.05) },
      { name: 'breakdef', w: 1.5, sel: BOT_PICKS.breakdef },
      { name: 'wall', w: 1.5, sel: BOT_PICKS.wall },       // 防御/反弹墙：逼迫学会破架势
      { name: 'tankline', w: 2.0, sel: BOT_PICKS.tankline },   // 人类式：坦克线（优先级3作废枪/狙击）
      { name: 'heavyfire', w: 1.8, sel: BOT_PICKS.heavyfire },  // 人类式：重火力压制
      { name: 'guardgun', w: 1.8, sel: BOT_PICKS.guardgun },    // 人类式：防御+枪三拍
      { name: 'protowall', w: 1.6, sel: BOT_PICKS.protowall },  // 原型制御墙：只有地雷/转移能绕
      { name: 'whiff', w: 1.2, sel: BOT_PICKS.whiff },          // 空放型：训练 lastSkill=null 状态
      { name: 'reflectmix', w: 1.8, sel: BOT_PICKS.reflectmix }, // 反弹与攻击交替：克「枪/狙击吃反弹」
      { name: 'reflecttank', w: 1.8, sel: BOT_PICKS.reflecttank },   // 反弹→反弹→坦克（实测打穿旧冠军）
      { name: 'defreflectgun', w: 1.8, sel: BOT_PICKS.defreflectgun }, // 防御→反弹→枪（实测打穿旧冠军）
      { name: 'reflectspam', w: 1.6, sel: BOT_PICKS.reflectspam }, // 永久反弹：修"一键反弹打死冠军"
      { name: 'mix', w: 1.3, sel: BOT_PICKS.mix },
      { name: 'aggro', w: 1.2, sel: BOT_PICKS.aggro },
      { name: 'combocounter', w: 1.8, sel: BOT_PICKS.combocounter },   // 连招反制：逼 AI 别被看穿
      { name: 'guardspam', w: 1.6, sel: BOT_PICKS.guardspam },
      { name: 'baguaspam', w: 1.0, sel: BOT_PICKS.baguaspam },
      { name: 'balanced', w: 1.0, sel: BOT_PICKS.balanced },
      /* v1.5.130：**唯一"蓄珠 → 放电"的对手线**，权重给到 2.0（与 tankline 同档；它 100% 打穿越线包）。
       * ≈ 6% 的对局（池子总权重 30 → 32）—— 与 guardspam(5%) 同量级，不动整个分布的重心。 */
      { name: 'beadburst', w: 2.0, sel: BOT_PICKS.beadburst },
      { name: 'defend', w: 2.2, sel: BOT_PICKS.defend }
    ];
  }
  function seedOfGen(gen, idx, tag) {
    let h = 17;
    /* ⚠ 已知 bug（2026-10-17 实测，**没修**，理由写在下面）：这里只混 `tag.length` ⇒ `champion` / `breakdef` /
     *   `tankline` / `guardgun` / `balanced` 这些**等长**的对手共享同一个局种子 ⇒「对 N 个基准的胜率」里有一部分
     *   **不是独立样本**，配对差的显著性被系统性高估（千问 DONE-1/E4 的账）。
     *   **修法试过了**（把 tag 的字符混进去：`String(gen*7919+idx*104729) + '|' + String(tag)`）⇒ 立即真红两条门：
     *     ① `train-runner.mjs:953` D135「没有示范 ⇒ 该席大雷出手必须恒 0」实测变成 **1**；
     *     ② `train-runner.mjs:1674` D165「开档臂必须训出不同的权重」实测**相同**。
     *   ⇒ 这两条是**种子校准过的行为读数**，改种子必须**同一批里一起重新基线**（不是各自孤立的数字）。
     *   ⚠ **但两条红不是等价的**（10-17 复查，别一起放宽）：
     *     · **D165 的红不是开关空转**：同一条门 `:1636-1643` 的**直接**断言（`f1.fit !== f0.fit` 且 `f1.fit < f0.fit`、
     *       `fitMean` 逐位不变）在新种子下**全过** ⇒ 机制活着。红的是 `:1674` 那条「2 代臂产物必须不同」的
     *       **弱端到端**判据 —— 2 代 × pop 12 里排序没变，权重当然相同。
     *     · **D135 的红是 `:953` 的精确 0**：而 `:954` 已经断言「一条链都不许出现」，那才是
     *       「非零信号只能来自教师注入」的本义 ⇒ `:953` 是种子校准出来的观察，不是不变量。
     *   所以本行**暂留旧口径**。要落这条种子修，需要一条完整批次（改种子 + 放宽 `:953`/`:1674` 这两条弱判据 +
     *   复核在册臂读数）；而**在那之前应先定尺** —— 尺换了，所有臂读数都要重基线，这笔记号会被那一笔吸收。 */
    const s = String(gen * 7919 + idx * 104729 + tag.length * 31);
    for (let k = 0; k < s.length; k++) h = (h * 31 + s.charCodeAt(k)) >>> 0;
    return h;
  }
  /* 计算单个个体（params）对 opps 的 shaped fitness + 攻防统计。纯函数：可被并行 worker 调用。
   * 与旧 evaluatePopulation 的单个体逻辑完全一致（sel 只在循环外建一次，行为不变）。 */
  function scoreMember(params, opps, gamesPerOpp, gen, idx) {
    let score = 0, n = 0, attackGames = 0, attackChoices = 0, totalChoices = 0;
    const skillUse = {};   // 该个体全部对局里的出招分布（用于多样性奖励）
    const sel = policyChooser(params, 0.05);
    for (const opp of opps) {
      let acc = 0;
      for (let g = 0; g < gamesPerOpp; g++) {
        const aOn0 = (g % 2 === 0);
        const rec = { offensive: false, choices: 0, attackChoices: 0, prevKey: null, curRun: 0, maxRun: 0 };
        const selWrapped = function (state, pid, legal) {
          const k = sel(state, pid, legal);   // 与实战一致的贪心
          if ((aOn0 && pid === 0) || (!aOn0 && pid === 1)) {
            rec.choices++;
            if (R.ATK_EFFECT.indexOf(k) >= 0) { rec.offensive = true; rec.attackChoices++; }
            rec.curRun = (k === rec.prevKey) ? rec.curRun + 1 : 1;
            if (rec.curRun > rec.maxRun) rec.maxRun = rec.curRun;
            rec.prevKey = k;
            skillUse[k] = (skillUse[k] || 0) + 1;
          }
          return k;
        };
        const r = aOn0 ? oneGame(selWrapped, opp.sel, seedOfGen(gen, idx, opp.name) + g)
                        : oneGame(opp.sel, selWrapped, seedOfGen(gen, idx, opp.name) + g);
        if (rec.offensive) attackGames++;
        attackChoices += rec.attackChoices;
        totalChoices += rec.choices;
        let base = r.winner === 'draw' ? 0.1 : (aOn0 ? (r.winner === 0 ? 1 : 0) : (r.winner === 1 ? 1 : 0));
        const dmgDealt = aOn0 ? r.dmg[1] : r.dmg[0];   // 我造成的伤害（含反弹）
        const dmgTaken = aOn0 ? r.dmg[0] : r.dmg[1];
        const diff = dmgDealt - dmgTaken;
        // 换血正向 = 进攻奖励；反向 = 挨打惩罚（修正原 sign 乘积负负得正的 bug）
        // 出手/进攻类奖励整体收敛：原先 offensive±0.04 + deal + slow 把"永远不摆架势"变成最优解
        const proact = 0.03 * Math.max(-1, Math.min(1, diff / 6));
        const deal = 0.015 * Math.min(1, dmgDealt / 4);
        const slow = 0.015 * Math.min(1, r.rounds / 60);
        let gs = Math.max(-0.3, Math.min(1.3, base + proact + deal - slow + (rec.offensive ? 0.015 : -0.015)));
        // 单调循环惩罚：同一招连放 >5 次 → 每多一次扣 0.03（抑制"永久反弹/ジ枪循环"退化）
        if (rec.maxRun > 5) gs -= 0.03 * (rec.maxRun - 5);
        acc += gs;
      }
      score += (acc / gamesPerOpp) * opp.w;
      n += opp.w;
    }
    const attackRate = attackGames / (opps.length * gamesPerOpp);
    const attackShare = totalChoices ? attackChoices / totalChoices : 0;
    // 多样性奖励：出招分布的香农熵（3 bit 封顶，权重 0.05）——直接把"覆盖率/熵"从 7/28、1.5bit 往上推，
    // 否则"ジ+枪"两招循环在适应度上照样是最优解（玩家手感里 AI 会显得死板）。
    let ent = 0; const totUse = Object.keys(skillUse).reduce(function (a, k) { return a + skillUse[k]; }, 0) || 1;
    for (const k in skillUse) { const p = skillUse[k] / totUse; ent -= p * Math.log2(p); }
    const div = 0.05 * Math.min(1, ent / 3);
    return { score: (n ? score / n : 0) + div, div: div, distinct: Object.keys(skillUse).length, entropy: ent, attackGames: attackGames, attackChoices: attackChoices, totalChoices: totalChoices, attackRate: attackRate, attackShare: attackShare };
  }
  /* 串行评估整代（浏览器 / 自测用）。行为与旧版逐成员完全一致。 */
  /* ================= N 人（N19）================= */
  /* 目标启发（N 人）：优先血量最低的存活对手 */
  /* 上回合与我互为目标、结果双方被相抵的对手（用于反锁） */
  function lastCancelOther(state, pid) {
    for (let i = state.events.length - 1; i >= 0; i--) {
      const e = state.events[i];
      if (e.type === 'cancel' && e.round === state.round - 1 && e.pids && e.pids.indexOf(pid) >= 0) {
        return e.pids[0] === pid ? e.pids[1] : e.pids[0];
      }
    }
    return null;
  }

  /* N 人目标选择 v2：
   *   1) 反锁：上回合与某对手互为目标而相抵 → 本回合不再打他（否则就是无意义的互相消耗死循环）
   *   2) 能一击必杀 → 打能杀的（取血最低）
   *   3) 否则 → 打血量最高的（领先者），避免放任任一家坐大
   *   并列时随机（去 pid 偏差）。 */
  function pickTargetN(state, pid, key) {
    const def = R.byKey[key];
    if (!def || def.target === 'self') return null;
    const opps = S.opponentsOf(state, pid);
    if (!opps.length) return null;
    let pool = opps;
    const locked = lastCancelOther(state, pid);
    if (locked != null) {
      const alt = opps.filter(function (o) { return o !== locked; });
      if (alt.length) pool = alt;
    }
    const dmg = (def.dmg && def.dmg.amt) ? def.dmg.amt : 0;
    const killable = dmg > 0 ? pool.filter(function (o) { return state.p[o].hp <= dmg; }) : [];
    let best = [], bestHp = killable.length ? Infinity : -Infinity;
    for (const o of (killable.length ? killable : pool)) {
      const h = state.p[o].hp;
      if (killable.length ? (h < bestHp - 1e-9) : (h > bestHp + 1e-9)) { bestHp = h; best = [o]; }
      else if (Math.abs(h - bestHp) < 1e-9) best.push(o);
    }
    if (!best.length) best = pool.slice();
    if (best.length === 1) return best[0];
    return best[Math.floor(state.rng.next() * best.length)];
  }
  function pickTarget2N(state, pid, key, t1) {
    if (key !== R.SK.DUAL_GUN && key !== R.SK.MIRROR) return null;
    const opps = S.opponentsOf(state, pid).filter(function (o) { return o !== t1; });
    return opps.length ? opps[0] : null;
  }

  /* N 人版策略 chooser（v7：**候选**= (技能, 目标, 珠类型)，目标由网络自己选，不再走 pickTargetN）。
   * eps = ε-探索：以概率 eps 在**候选**里均匀抽一个（v6 是"在可负担技能里抽"）。
   * 为什么必须有：策略在 ep≥1 时 99.8% 选枪，"不花钱攒钱"这个动作
   * 几乎不可能被 softmax 采样到 → 奖励再大也没有梯度（经验：
   * save/conv/hold 三项都加了，max ep 仍然死守 1）。
   * 训练用 eps>0；评测/UI 不传 eps → 行为不变。
   * `lockTarget`：上回合与本玩家"相抵"的对手不进候选（沿用 v6 pickTargetN 的反锁策略，
   * 避免无意义的互相消耗死循环）。第二目标 t2 仍由 pickTarget2N 兜底 —— 枚举 t2 会让候选数再 ×(N−1)。 */
  /* ===== v1.5.82（用户裁定，v1.5.83 抽成单一真源）：**蓄能的经济门槛** =====
   * 用户原话："ep=1 的时候本来就不应该蓄能……至少要让他 ep>=2 才开始用，不然就是浪费。"
   * 规则依据（已核）：蓄能 cost=1，能量珠"只保留到下一回合"；珠子消费卡有两张 ——
   *   · 电磁炮 railgun：2 ジ + 1 **电珠**（攻破反弹/防御）
   *   · 激光眼 laserEye：首次 **1 ジ + 1 爆珠**、连续使用 2 ジ（无效化防御类/转移伤害；偏结盟用）
   * 收入约 1 ジ/回合 ⇒ ep=1 蓄能后下回合刚好够激光眼、却完全不够电磁炮，且一旦被打断就白扔 ⇒ 取保守门槛 ep>=2。
   * ⚠ 启发式不是定律：收入 >1/回合（聚能环第 3 次起 +3、避雷针 +4）时 ep=1 蓄能也可能成立。
   * ⚠ 只作用于 v7 口径：legacy（v5/v6）保持旧口径，历史基线才可比。
   * 抽成函数的动机：探针（tools/probe-beadloop.mjs）必须与线上**同一份**门槛，否则又会量错（对比 v1.5.83 的教训）。 */
  /* v1.5.143（千问 0921 晚）：**蓄能门槛可调**，默认 2 = v1.5.82 的原裁定 ⇒ 不设则逐字不变。
   * 为什么要有这个旋钮（0921 取证钉出来的机制）：包在 **ep=2** 蓄能 ⇒ 扣 1 之后手上剩 1 ジ，而珠活到下一回合末
   * ⇒ "**有珠的那一回合必然买不起电磁炮**（要 2 ジ + 1 珠）"。实测 `v7beadseed-31`：226 次持珠决策里 **225 次 ep=1**、
   * 唯一一次 ep=2 它就放了（1/1）。⇒ 训练分布本身在教"珠=花不掉"，所以 `BEAD_W` 四档与状态塑形都买不动。
   * 把门槛抬到 3（蓄完仍 ≥2）是让"有珠"与"可负担"**同时出现**的最小改动 —— 只作用于训练侧评测口径时可以随消息设。 */
  let CHARGE_MIN_EP = 2;
  function setChargeMinEp(v) {
    const n = Number(v);
    if (isFinite(n) && n > 0) CHARGE_MIN_EP = Math.min(9, Math.floor(n));
    return CHARGE_MIN_EP;
  }
  function chargeMinEpOn() { return CHARGE_MIN_EP; }

  /* ===== v1.5.199（用户实机报"空净化"）：净化有没有东西可清 =====
   * 清单**逐项对齐 `js/core/resolve.js` 的 `purgeSelf`**（R60 / v1.5.110 的清除清单从状态字段推导）：
   *   `stickers`（符咒）· `nightmare`（梦魇 R50）· `tauntPending`/`tauntByPending`（挑衅）·
   *   `fireWeakNow`/`fireWeakNext`（藤甲 R58）· `mineArmed`/`mineTurns`（地雷 R59）· `rodGuard`（避雷针 R31）·
   *   `cooldown`（大雷禁用 R29）。
   * ⚠️ 这是"同一份清单写在两个文件里"——**故意如此**：`resolve.js` 是**规则指纹面**（改它 = 规则换代、
   *   全部历史基线作废），不能为了共享一行代码去动它。漂移风险由门 **D142** 用引擎本身逐字段对账
   *   （挂上某个状态 ⇒ 引擎真清得动 ⇒ 本函数必须返回 true；全空 ⇒ 引擎 `purify.curses===0` 且状态零变化）。
   * 判"能不能清"而不是"值不值"：身上挂着地雷/避雷针时净化会**自损增益**（R60 裁定的自然结果），
   *   那属于策略权衡，不归这道门管 —— 这道门只挡"3 ジ 清 0 个"的**恒亏**动作。 */
  function hasPurgeable(p) {
    if (!p) return false;
    if (p.stickers && p.stickers.length > 0) return true;
    if (p.nightmare) return true;
    if (p.tauntPending) return true;
    if (p.tauntByPending && p.tauntByPending.length > 0) return true;
    if (p.fireWeakNow || p.fireWeakNext) return true;
    if (p.mineArmed || (p.mineTurns || 0) > 0) return true;
    if ((p.rodGuard || 0) > 0) return true;
    if (p.cooldown && Object.keys(p.cooldown).length > 0) return true;
    return false;
  }

  function econBase(state, pid, legal) {
    /* 菜单级"严格必废"闸门（v1.5.139 扩第二项，用户实机报"空爆"）：
     * ① ep<2 不蓄能（v1.5.82 原裁定，注释见 policyChooserN 上方）；
     * ② 全场无人带符咒 ⇒ 天火必然 0 引爆（花 2 ジ 放空气）——从菜单摘掉。
     * ③ v1.5.199：自己身上没有任何持续状态 ⇒ 净化必然"清除 0 枚"（花 3 ジ 放空气）——同样摘掉。
     * 与①②同性质：这是"恒亏动作"的门禁，不是新的规则语义（README 净化的作用对象就是自身持续状态）；
     * 键级探索（下面 epsK）因此永远不会把净化采进 top-K。训练/浏览器同享此菜单。 */
    // v1.5.139：天火引爆的是**施法者自己贴出、age≤3** 的符咒（resolve `case SK.FIRESTORM` 的
    // owner/age 判定）——闸门必须与它同判据：数"pid 拥有的存活符咒"，不是"场上任何符咒"。
    let myLiveStickers = 0;
    for (let i = 0; i < state.p.length; i++) {
      const tk = state.p[i].stickers || [];
      for (let j = 0; j < tk.length; j++) if (tk[j].owner === pid && tk[j].age <= 3) myLiveStickers++;
    }
    const gated = legal.filter(function (l) {
      if (l.key === R.SK.FIRESTORM) return myLiveStickers > 0;
      if (l.key === R.SK.PURIFY) return hasPurgeable(state.p[pid]);
      if (l.key !== R.SK.CHARGE) return true;
      const pp = state.p[pid];
      return !!pp && (pp.ep || 0) >= CHARGE_MIN_EP;
    });
    return gated.length ? gated : legal;
  }

  /* ===== v1.5.146（qoder 0921 审计抓到的静默坑）=====
   * 把 `window.EPIRUS_CHAMPION[_3P]` 的**原始外壳**直接喂进 chooser 时：checkPack 照过、
   * 不抛任何异常，而权重取不到 ⇒ forwardCands 输出**均匀分布** ⇒ 工具会拿着"冠军只出ジ"
   * 这种假结论对账（09-21 写对战台实测踩中；单独复跑 unpack 后同包 50/50 胜 balanced）。
   * 现在：① 原始包外壳 ⇒ **自动 unpack**（对调用方是行为修复，不是口径变更）；
   * ② 其它非权重输入 ⇒ **显式抛错**，绝不静默均匀。
   * ⚠️ 认"已 unpack 的 typed array"不许用 `instanceof Float64Array` —— np-test/tools 把 evo 装进
   *   vm 沙箱，params 可能在**另一个 realm** 里造出来（沙箱间 Float64Array 不同构）；
   *   旧路径靠 shapeOf 只读 `.length` 恰好跨 realm 可用，守卫不能反而把它打破 ⇒ 用鸭子判据。 */
  function normChampParams(params) {
    if (!params) return params;                                   // null = 既有"按旧口径兜底"路径，不动
    if (typeof params.length === 'number' && typeof params[0] === 'number') return params;  // typed array（含跨 realm）
    if (typeof params === 'object' && Array.isArray(params.a)) {
      const q = P.unpack(params, true);
      if (q) return q;
      throw new Error('policyChooserN: 原始包 checkPack 失败（版本/维度不符）⇒ 需重训重发，不能直喂');
    }
    throw new Error('policyChooserN: params 必须是 EpirusPolicy.unpack() 后的权重数组；不许直喂 window.EPIRUS_CHAMPION（忘 unpack 会静默输出均匀分布）');
  }

  /* ===== v1.5.149-night · 序列窗锁的判据（纯函数，门 D115 直接喂构造态）=====
   * 夜测（`RESEARCH-LOG-2026-09-22-qoder-night.md` §N4）：电磁炮 4.30/局在 **ε=0.1 就跌到 0.90** ——
   * 悬崖与 ε 大小不成比例。机理：蓄能→开炮/贴符→引爆是**跨回合序列**，任何一步被改判都会让整条链归零
   * （蓄能被换 ⇒ 下回合无珠；持珠没开炮 ⇒ 珠回合末过期）。D111 三规则保证"收尾卡在菜单上"（可达性），
   * 但探索仍能在**序列步**上改判（原子性没人管）。
   * ⚠️ 判据挂在**状态特征**上而不是"贪心采样结果"上（D115 首版实测泄漏：temp0.15 的贪心本身是随机的，
   *   RAILGUN 贪心率 <1 的持珠态有 (1−q)·ε 概率被改判 ⇒ 采样后判锁 40 抽样只锁住 11）。
   * 锁语义：
   *   · 持电珠 ⇒ 锁（终点 RAILGUN 在手，回合不赌）；持爆珠 ⇒ 锁（终点 LASER_EYE）；
   *   · 身上有自己贴的存活符咒 ⇒ 锁（终点 FIRESTORM / 续贴线）；
   *   · 上一手 = CHARGE ⇒ 锁（无论本手开什么，都不许在链中途撒手）；
   *   · CHARGE ∧ ep≥3 **不锁起点**（否则 D111①"ep<3 不进探索"的噪声源就被清零——起点交给终点锁 + 上手段保护，
   *     实测蓄能频率仍受 ε 影响但**放炮链**完整，悬崖修复见夜测复跑）。
   * 只在 `epsMode==='soft'` 生效 ⇒ 训练/评测/门禁（eps=0 或缺省口径）逐字不变。 */
  function seqLockedTurn(state, pid) {
    if (!state || !state.p || !state.p[pid]) return false;
    const me = state.p[pid];
    if ((me.elec || 0) > 0 || (me.boom || 0) > 0) return true;
    if (me.lastSkill === R.SK.CHARGE) return true;
    for (let zi = 0; zi < state.p.length; zi++) {
      const zs = state.p[zi].stickers || [];
      for (let zj = 0; zj < zs.length; zj++) if (zs[zj] && zs[zj].owner === pid) return true;
    }
    return false;
  }

  /* ===== v1.5.237（E28 · **默认关 ⇒ 出厂读数逐字不变**）：训练/选择的"执行口径"旋钮 =====
   * 建台时先纠正我自己的一条前提（差点据此写进报告）：我原以为"适应度在 ε=0"。实测**不是**：
   *   · 每代评分那一路（`scoreMemberN` 里被评席的 base chooser）出厂就是 **temp 0.35 · ε=0.15 · 不带 epsMode**；
   *   · 而 5 人产品是 **temp 0.15 · ε=0.2 · k=5 · soft**（`ui.js:464`）；自评/健康门槛那一路（`mirrorHealth` 漏斗）才是 ε=0。
   *   ⇒ 真正的问题不是"训练 ε=0 vs 产品 ε=0.2"，而是**选择压力作用在一格玩家永远看不见的硬档噪声上**：
   *     `epsMode` 缺省 ⇒ 不走 v1.5.141 的"防御/环豁免"、不走 v1.5.149 的序列窗锁、防御键**留在探索池里**。
   *     而那三件事的原始动机正是"同一包同一装配下，硬档把防御出现率从 4.0% 抬到 26.4%、把聚能环从 1.2% 抬到 0.0%"
   *     —— 也就是说：**我们在用一种已知会虚增防御、杀死滚环的口径去挑"该防不防、该环不环"的包。**
   * ⇒ 这个旋钮让一臂可以改在**产品口径**下被选择（ε/temp/k/mode 一起挪），与同配方的出厂臂孪生对跑。
   * 作用范围（D162 钉这条，别让它悄悄扩大）：只有 `trainChooser()`（自评/门槛四处漏斗）与 `fitChooser()`（每代评分被评席）
   *   读它；`tools/audit-lib.mjs` 自己写死的 9 处**不经过这里** ⇒ 同一进程里 promote 类读数仍 ε=0；
   *   `makeCommitChooser` 的内部 chooser（承诺局，出厂 ε=0）**也不经过这里** ⇒ 承诺局口径不动。
   * ⚠️ 关档分支必须与出厂**同一串参数**（`0.15` / `0.35, 0.15`），否则"默认不变"没法证；
   *   也不许用 `Number(env.X || 默认)` 之外的写法吞掉 0（`--eps=0` 会被 `||` 吃掉，v1.5.174 的 `drainHpMax` 同族）。 */
  let TRAIN_EPS = 0, TRAIN_EPS_K = 5, TRAIN_EPS_MODE = 'soft', TRAIN_TEMP = null;
  const TRAIN_EPS_ST = { seen: 0, built: 0, fitSeen: 0 };
  function setTrainEps(v, k, m, temp) {
    const n = Number(v);
    if (!Number.isFinite(n) || n < 0 || n > 1) throw new Error('setTrainEps: eps 必须是 0~1 的数，收到 ' + JSON.stringify(v));
    TRAIN_EPS = n;
    if (k != null && k !== '') TRAIN_EPS_K = Math.max(1, Number(k) | 0);
    if (m) TRAIN_EPS_MODE = String(m);
    if (temp != null && temp !== '') {
      const t = Number(temp);
      if (!Number.isFinite(t) || t <= 0) throw new Error('setTrainEps: temp 必须是正数，收到 ' + JSON.stringify(temp));
      TRAIN_TEMP = t;
    }
    return { eps: TRAIN_EPS, k: TRAIN_EPS_K, mode: TRAIN_EPS_MODE, temp: TRAIN_TEMP };
  }
  function trainEps() { return { eps: TRAIN_EPS, k: TRAIN_EPS_K, mode: TRAIN_EPS_MODE, temp: TRAIN_TEMP }; }
  function countTrainEps() {
    return { eps: TRAIN_EPS, k: TRAIN_EPS_K, mode: TRAIN_EPS_MODE, temp: TRAIN_TEMP, seen: TRAIN_EPS_ST.seen, built: TRAIN_EPS_ST.built, fitSeen: TRAIN_EPS_ST.fitSeen };
  }
  function resetTrainEpsStat() { TRAIN_EPS_ST.seen = 0; TRAIN_EPS_ST.built = 0; TRAIN_EPS_ST.fitSeen = 0; }

  /* 自评/健康门槛那一族的**唯一漏斗**（出厂 temp 0.15 · ε=0）。
   * ⚠️ 关档那一行必须保留"两参直调 `policyChooserN`"这个**原形状**（权重 + 温度，不传 eps）：
   *   `tools/probe-layer-caliber.mjs` 的 route ① 就是靠匹配那串字面量、在装载前做替换来"把口径打进内部调用点"的
   *   （门 D150 判的是"替换数 = 源码现算数"；形状一改或注释里再出现一次，搬运会静默少覆盖而自检仍绿）。
   *    ⇒ 顺带一条好消息：漏斗之前 route ① 要命中四处，现在只需一处，少三处漏网的可能。 */
  function trainChooser(params) {
    if (!TRAIN_EPS) return policyChooserN(params, 0.15);
    TRAIN_EPS_ST.built++;
    const f = policyChooserN(params, TRAIN_TEMP == null ? 0.15 : TRAIN_TEMP, TRAIN_EPS, TRAIN_EPS_K, TRAIN_EPS_MODE);
    return function (state, pid, legal, econ) { TRAIN_EPS_ST.seen++; return f(state, pid, legal, econ); };
  }

  /* 每代评分里**被评席**的 chooser（出厂 temp 0.35 · ε=0.15 · 硬档）。关档分支逐字保留出厂那三个参数。 */
  function fitChooser(params) {
    if (!TRAIN_EPS) return policyChooserN(params, 0.35, 0.15);
    TRAIN_EPS_ST.fitSeen++;
    return policyChooserN(params, TRAIN_TEMP == null ? 0.35 : TRAIN_TEMP, TRAIN_EPS, TRAIN_EPS_K, TRAIN_EPS_MODE);
  }

  /* ===== v1.5.334（用户 10-03 晚：「你把 p=8 默认开吧」→ 量出 G5 被击穿后改口「那换 p=12 吧」）：大雷的"看得见"档 **默认就是 12** =====
   * 沿革：v1.5.332 先做成"引擎默认 0=关 + 页面 `ui.js` 显式开 8"，用户看完读数后把它提成**默认行为**
   *   ⇒ 现在**唯一的来源就是下面这个常数**（页面不再调 setter，避免"两处开关必漂移"这一族的老账）；
   *   ⇒ 连带后果（是**有意的**）：**训练 / 评测 / 门禁现在也带着这一档跑** ⇒
   *      以后要"出厂 vs 处理"的配对，**必须显式 `--shipbigt=0`**，"不设旗标"已经等于"开着"。
   * 用户的话：「最后大雷只要每四五局有一次就行了，亏损这一点没什么关系」+「按 p=8 准备上线」+「p=8 默认开」。
   * 机制：在这张牌现在打得出来的窗口里（= 引擎自己的候选枚举判过价格/珠/封锁，不在这里抄第二份费用表），
   *   按 (每局盐, 回合, 座位) 的确定性 avalanche 散列取 1/N ⇒ 命中就把这一手交给大雷，目标 = ep 最高的对手（平手取血少，再取座位号小）。
   * ⚠ 三条形状纪律：
   *   ① **不消耗 `state.rng`**（散列是纯函数 ⇒ 不新增随机流）；代价是这一手跳过了冠军自己的抽样，
   *      而"少抽一次"的后果**已经包含在下面那个实测价里** —— 量的就是这同一段代码（`eval-5p --shipbigt=`）。
   *   ② **剂量不许按 1/N 换算**：窗口密度会随剂量自己漂（N=2 时 0.85 个/局 ‖ N=10 时 1.63 个/局，不打就一直攥着 5 珠）
   *      ⇒ "每几局一张"只有考卷说了算（§E270 那张表就是这条的实测）。
   *   ③ **"多久出现一次"是分装配的**（§E272 实测于 N=8）：3~5 人每 5.2 ‖ 3.2 局一张，2 人镜像每 2.9 局一张（**N=12 的 2 人镜像未测**），
   *      而 **2 人真桌（冠军 + 脚本）每 250 局 ≈ 看不见**（那张牌在 2 人桌上开不了窗口）⇒ 用户裁定「**2p 下不用大雷是正确的情况**」，所以不为 2 人做任何补偿。
   *   ④ **这一档会挤压破防能力**（§E274 实测，G5 防席夺冠）：关掉档 12% ‖ 18% → N=8 41% ‖ 30% → **N=12 36% ‖ 27%**。
   *      ⇒ 用户裁定「G5 稍微差一点问题不大」⇒ `gate-drafts` 改成**两行分开判**：`G5[...]` 仍按关掉档判 ≤25%（判别力不降），
   *        `G5带档[...]` 按现网形状判 ≤40%。**换成 8 会更糟（41%/30%）⇒ 12 是"看得见"与"还清得了场"之间用户选的那一点。**
   * 实测价（产品考卷 24 局 × 2925 桌 · 与同树**关掉档**逐桌配对 · §E270/§E271/§E274）：
   *   **默认 N=12 ⇒ 3 血每 7.0 局一张、−0.34 ±0.12pt ‖ 5 血每 4.6 局一张、−0.22 ±0.11pt**；
   *   更猛的 N=8 是每 5.2 ‖ 3.2 局一张、−0.52 ‖ −0.40pt；N=6 每 4.2 局一张、−0.85 ±0.19pt。
   * ⚠ 这与"改规则"不是一回事：**不动** `BIG_T` 的 5 珠单价与 3 回合封锁（`js/core/*` 一字未动、指纹仍 `ebdbff36`），
   *    只是给冠军的出牌加一条部署层的抽样；**回退 = 把下面这个常数改成 0**（门 **D224** 钉"默认值在册 / 关掉要显式 / 开档真改落点 / 两条路径必须同意"）。 */
  let BIGT_PUSH = 12;
  function setBigTPush(v) {
    const n = (v == null || v === '') ? 0 : Number(v);
    if (!(n === 0 || (Number.isInteger(n) && n >= 1 && n <= 12))) {
      throw new Error('setBigTPush: 只能是 0 或 1..12（0 = 关；N = 每 N 个窗口兑现一次；收到 `' + v + '`）');
    }
    BIGT_PUSH = n;
  }
  function bigTPushOn() { return BIGT_PUSH; }
  /* ===== §E646（路线 B · 用户 10-18 晚裁「那你顺便做一下 B 吧」；版本号留到合并那一刻再写，见规矩③）=====
   * **部署层先验：档 1 只改送盾的目标；档 2 在此基础上"挑不到就不送（改攒）"。** 默认 **0 = 关** ⇒ 训练/评测/门禁与现网逐字不变，
   *   开档必须显式 `setSupportPrior(1|2)`（评测侧 = `tools/eval-5p.mjs --support=1|2`，对照臂 = `--support=0`）。
   * 谓词不是拍脑袋，是本轮实测挑出来的（§E644 二 ‖ §E643 二 补的四臂表）：
   *   `churning = ringStreak ≥ 1 ∨ ep ≥ 3`（正在攒长招）**且 `hp > 1`（还没濒死）**，取 `ep` 最大、排除自己。
   * ⚠ 反过来那两种写法都被量过、都是错的：**"挑血最少"送得比现状还多而兑现 0/235 ‖ 0/233**（`weak` 臂），
   *   **随机给**只有 3/210（`rand` 臂）⇒ 濒死那一格一回合的盾救不回来，不许拿 `hp` 最低当判据。
   * ⚑ **这是先验，不是学到的**（主语规矩）；收益不归送礼者（§E644 三：打到其威胁只有 0~2.6%），
   *   所以它**不进 reward、不进特征**，也不许在产品文案里写成"AI 学会辅助"。
   * 不新增门（默认关的开关不在现网路径上）；三条腿的可跑自证在 `tools/probe-support-prior.mjs`。 */
  let SUPPORT_PRIOR = 0;
  function setSupportPrior(v) {
    const n = (v == null || v === '') ? 0 : Number(v);
    if (!(n === 0 || n === 1 || n === 2)) {
      throw new Error('setSupportPrior: 只能是 0（关，默认）、1（只改送盾目标）或 2（改目标 + 挑不到就不送、改攒）；收到 `' + v + '`');
    }
    SUPPORT_PRIOR = n;
  }
  function supportPriorOn() { return SUPPORT_PRIOR; }
/* v1.7.105（用户 10-18：「SUPPORT_PRIOR 压得太死，留一些阈值或随机性，免得完全变成脚本工作」）。
 *   旋钮都**不消耗 `state.rng`**（用无状态 hash 派生）⇒ 开/关档的随机流仍逐字同：
 *     `SUPPORT_PRIOR_MIN_EP`  —— “在搓长招”的软阈值（默认 3，与 `ringStreak ≥ 1` 并联）；
 *     `SUPPORT_PRIOR_SKIP_P`  —— 档 2 挑不到目标时“改攒”的概率（默认 0.6；其余照网络自己走）；
 *     `SUPPORT_PRIOR_PICK`    —— 挑人的形状：`'weighted'`（默认，按 ep 加权抽）‖ `'max'`（**永远取 ep 最大**）。
 *   ⚑ 千问 §E648 为什么补第三条：§E643 二 被量过的那条 churn 臂、以及 §E647 那张三起点强度表，量的都是 `max` + `skipP=1` 的形状；
 *     v1.7.105 把码改成 weighted/0.6 之后**没有任何 CLI 能回到那个形状** ⇒ 同一句 `--support=2` 指向了另一个对象，
 *     在册读数就成了"命令还能跑、但量的不是当初那件事"。这条 knob 只为**让旧口径可复现**而存在，默认值一字不动 ⇒ 产品行为逐字不变（自证：默认档对拍在册读数）。 */
let SUPPORT_PRIOR_MIN_EP = 3;
let SUPPORT_PRIOR_SKIP_P = 0.6;
let SUPPORT_PRIOR_PICK = 'weighted';
/* setter 的牙（与 `setBigTPush`/`setSupportPrior` 同形，也是门 D218 那条"不许静默吞参数"在 knobs 上的对应物）：
 *   给了就必须合法、名单外的键要拒（打错 `skipp` 不能变成"悄悄用默认值跑"）；不给的键保持原值。 */
function setSupportPriorKnobs(o) {
  if (o == null || typeof o !== 'object') throw new Error('setSupportPriorKnobs: 要一个对象 {minEp, skipP, pick}；收到 `' + o + '`');
  const KN = ['minEp', 'skipP', 'pick'];
  for (const k in o) if (KN.indexOf(k) < 0) throw new Error('setSupportPriorKnobs: 不认识的旋钮 `' + k + '`（合法只有 ' + KN.join('/') + '）');
  if (o.minEp != null) {
    const a = Number(o.minEp);
    if (!(isFinite(a) && a >= 1 && Number.isInteger(a))) throw new Error('setSupportPriorKnobs: `minEp` 要是 ≥1 的整数；收到 `' + o.minEp + '`');
    SUPPORT_PRIOR_MIN_EP = a;
  }
  if (o.skipP != null) {
    const b = Number(o.skipP);
    if (!(isFinite(b) && b >= 0 && b <= 1)) throw new Error('setSupportPriorKnobs: `skipP` 要在 0..1；收到 `' + o.skipP + '`');
    SUPPORT_PRIOR_SKIP_P = b;
  }
  if (o.pick != null) {
    if (o.pick !== 'weighted' && o.pick !== 'max') throw new Error("setSupportPriorKnobs: `pick` 只能是 'weighted'（默认）或 'max'；收到 `" + o.pick + '`');
    SUPPORT_PRIOR_PICK = o.pick;
  }
}
function supportPriorKnobs() { return { minEp: SUPPORT_PRIOR_MIN_EP, skipP: SUPPORT_PRIOR_SKIP_P, pick: SUPPORT_PRIOR_PICK }; }
/* 无状态伪随机（**不碰 state.rng**）：同一 (回合, 席, 盐) 永远同一个数 ⇒ 可复现。 */
function supportPriorRand(state, pid, salt) {
  const t = (state.turn != null) ? state.turn : (state.round != null ? state.round : 0);
  const s = t + '|' + pid + '|' + (salt || 0);
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return h / 4294967296;
}
  /* 挑不到就返回 null ⇒ 照网络自己的选择（那一格是**分母 0**，不是"先验表现差"）。不消耗 `state.rng`。 */
  function supportPriorTarget(state, pid) {
    /* v1.7.105：从「**永远取 ep 最大**」改成「**按 ep 加权抽一个**」（无状态 hash，不碰 state.rng）
     *   ⇒ 挑人里有随机成分，不再是一张固定脚本；同 (回合,席) 仍可复现。 */
    const cand = [];
    let wsum = 0;
    for (let i = 0; i < state.p.length; i++) {
      if (i === pid || state.p[i].hp <= 1) continue;
      const churning = (state.p[i].ringStreak | 0) >= 1 || state.p[i].ep >= SUPPORT_PRIOR_MIN_EP;
      if (!churning) continue;
      const wgt = Math.max(1, state.p[i].ep | 0);
      cand.push({ i: i, w: wgt, e: state.p[i].ep | 0 }); wsum += wgt;
    }
    if (!cand.length) return null;
    /* `pick='max'` = §E643/§E647 当初被量的那个形状（升序扫、严格大于 ⇒ **并列取席号最小那一位**）。
     *   写在这里而不是"顺手复用加权那支"：并列时的取值规则就是那个旧读数的一部分，改了它旧数就不复现了。
     *   ⚑ 比较的是**原始 ep**（`e`）而不是钳过 1 的权重（`w`）：`Math.max(1, ep)` 会把 0 与 1 压成同值 ⇒
     *     "ep=0 但在搓环流"会赢过"ep=1 也在搓环流"（退化成选席号小的那个），与旧形状不等价。
     *     这一格是我自己 A1 那版写错的，抓它的是 `tools/probe-support-prior.mjs` 的腿④d（构造态：ep=1 必须赢过 ep=0 且在搓招）。 */
    if (SUPPORT_PRIOR_PICK === 'max') {
      let b = cand[0].i, be = cand[0].e;
      for (let k = 1; k < cand.length; k++) { if (cand[k].e > be) { be = cand[k].e; b = cand[k].i; } }
      return b;
    }
    let r = supportPriorRand(state, pid, 1) * wsum;
    for (let k = 0; k < cand.length; k++) { r -= cand[k].w; if (r <= 0) return cand[k].i; }
    return cand[cand.length - 1].i;
  }
  /* ===== §E275（v1.5.334 · 用户 10-03 晚：「你把摄魂的给做一下」+「HP=1 是**仅调整探索时软提升的窗口**，不是调整实际规则」）=====
   * 与大雷那档的**根本区别**：这条**不强行落子**，只在**探索那一支**里把"摄魂指法"并入探索集（= 软提升，
   *   与 v1.5.142 给电磁炮/激光眼/天火开的 `forced` 口子同一形状、同一作用面）。
   * ⇒ 三条后果都是用户要的那句话的直接推论，不是借口：
   *   ① **不改规则**：这张牌的合法性照旧由 `js/core/state.js` 按 `mode.drainHpMax` 判（长程仍是 ≤2），我们一行都不碰；
   *   ② **只影响浏览器口径**：训练/评测/门禁一律 `eps=0` ⇒ 走不到探索那一支 ⇒ 既有读数逐字不变（G4/G5 也不受影响）；
   *   ③ 窗口条件 `自己 hp ≤ 1` 是**加在提升上的门槛**，不是加在牌上的门槛 ⇒ 长程桌里 HP=2 的自己照样不会被提。
   * 默认 **1 = 开**（用户 10-03 夜裁定「那就开一下摄魂软注入吧」，依据 §E283 的**实机**读数）：
   *   真页面 5 席同包 · 页面自己的逐回合 ε ⇒ **桌上每 4.3 局出现一次摄魂**（3 血 · 每席每 21.3 局 · 五席 6/9/11/9/12）‖ 5 血桌上每 10 局一张；
   *   关档同样装配是 **0 张/200 局**（这颗包自己从不打这张牌）⇒ 这一档不是"把概率挪一点"，是从 0 到有。
   *   价：§E276 页面口径配对差 **+0.08 ±0.09（3 血） ‖ +0.07 ±0.07pt（5 血）** = 噪声内。
   * ⚠ 为什么"默认开"对测量世界是**零影响**（与大雷那一档的关键区别）：钩子埋在 `epsMode === 'soft'` 且 `eps > 0` 的分支里，
   *   而训练 / 考卷 / 门禁一律 `eps=0` ⇒ 结构上走不到 ⇒ 既有读数逐字不变（大雷那档反过来：它是硬兑现，默认开就进了所有读数，所以要显式 `--shipbigt=0` 才拿得到出厂形状）。
   * ⇒ 回退 = 这个常数改成 0（其余一律不动）；**要关也要能显式关**：`--shipdrain=0`（评测）/ `EPIRUS_DRAIN_PUSH=0`（训练入口）/ `setDrainPush(0)`。 */
  let DRAIN_PUSH = 1;
  function setDrainPush(v) {
    const n = (v == null || v === '') ? 0 : Number(v);
    if (!(n === 0 || (Number.isInteger(n) && n >= 1 && n <= 12))) {
      throw new Error('setDrainPush: 只能是 0 或 1..12（0 = 关；N = 每 N 个窗口软提升一次；收到 `' + v + '`）');
    }
    DRAIN_PUSH = n;
  }
  function drainPushOn() { return DRAIN_PUSH; }
  /* 纯函数：**这一手该不该把摄魂并进探索集**。拆开是为了让门能喂合成表直读（记忆第十九条：
   * 排序键/名单式的门在 `band=1` 那种短夹具上是永绿装饰 ⇒ 必须能在一次调用里判形状）。 */
  function drainPushWants(state, pid) {
    if (!(DRAIN_PUSH >= 1)) return false;
    const me = (state && state.p && state.p[pid]) ? state.p[pid] : null;
    if (!me) return false;
    if (!(me.hp > 0 && me.hp <= 1)) return false;              // 用户裁定的窗口：**自己**残血（不是把牌的门槛改掉）
    return (drainPushSalt(state, pid) % DRAIN_PUSH) === 0;      // 剂量：与大雷同一族 avalanche 散列，不消耗 state.rng
  }
  function drainPushSalt(state, pid) {
    let h = ((((state && state.slotSalt) | 0)) ^ Math.imul((state && state.round) | 0, 0x5F356495) ^ Math.imul(pid | 0, 0x2E4B5C91)) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 0x9E3779B1) >>> 0;
    return (h ^ (h >>> 11)) >>> 0;
  }
  function bigTPushSalt(state, pid) {
    /* avalanche 三段（异或 → 奇数乘子 → 移位混淆）。⚠ 加法散列在本仓实测**打不开**（同一局内回合高度相关 ⇒ 剂量非单调，§E265 自我报告 #9）。 */
    let h = ((((state && state.slotSalt) | 0)) ^ Math.imul((state && state.round) | 0, 0x9E3779B1) ^ Math.imul(pid | 0, 0x85EBCA6B)) >>> 0;
    h = Math.imul(h ^ (h >>> 15), 0x2C1B3C6D) >>> 0;
    return (h ^ (h >>> 12)) >>> 0;
  }
  /* ===== v1.8.33（10-24 夜 · 千问 · **默认 0 = 关 ⇒ 出厂行为逐字不变**）：序列窗锁的"窄锁"档 =====
   * 病（§E712 实测，不是推论）：用户 10-13 裁过三条软注入（`evo.js:903-934` 的 ①②③），
   *   其中 ②「持珠/上手蓄能 ⇒ 把电磁炮、激光眼并进探索集」与 ③「有我方符咒/上手贴贴 ⇒ 并进天火、继续贴」
   *   的**触发条件**，与 10 天后加的序列窗锁 `seqLockedTurn`（`evo.js:510-521`：持珠 ‖ 上手 CHARGE ‖ 有我方符咒）
   *   是**同一批条件**；而 soft 分支的顺序是"锁上 ⇒ `pick = 贪心`"，后面那段并入代码在 `if (!pick)` 里 ⇒ **走不到**。
   *   量具直接量交集（250 局 × 5 席）：② 的窗口 100% 被锁、③ 的窗口 100% 被锁 ⇒ 这两条通道自 v1.5.149 起是死的，
   *   这解释了"天火在近乎全表的探索池（k=20）里仍然 0.000/局"（§E711 表）：不是 rank 问题，是**两裁定互相抵消**。
   * 这一档做的事：锁上时**不再作废探索**，而是把探索集**限制成链内键** ⇒
   *   v1.5.149 的原意（"不许在链中途撒手"）仍然成立（探索只许在链内的招里换），v1.5.142 的通道恢复；
   *   链内一张都可付都没有 ⇒ 回退贪心（绝不撒手到链外，也不凭空造非法动作）。
   * 默认 0：这是**新的线上（浏览器口径）行为**，要不要开是产品裁定 ⇒ 只搭台、量价，不动出厂。
   * ⚠ 与 `drainPush` 同一族纪律：钩子只挂在 `epsMode==='soft' && eps>0` 的分支里 ⇒ 训练/考卷/门禁（eps=0）**逐字不变**。 */
  /* 2026-10-25 00:4x（用户裁定，**覆盖上一班的开档**）：出厂回 **0**。
   *   上一班把"没有代价"当成了开的理由，用户一句话纠正：「注入显然是有效才开吧，没代价也没效果的注入也没必要开，
   *   你至少研究出有出现引爆再说开注入的问题」。而 §E730 的实测恰好是这一形状：
   *     代价 ≈ 0（强度最大 −0.30pt = 0.6 倍 SE，大雷/电磁炮/聚能环占比 ≤0.1pt）**且收益也只有"贴贴露脸"**
   *     （出手占比 0.00% → 0.3~0.4%），**天火 0.00%** ⇒ 引爆一次都没出现。
   *   ⇒ 判据变了：这两档要开，前提是先读到**场上真的走完一次引爆**（研究账见 §E738），不是先读"有没有代价"。
   *   ⚠ 图上的 `Hp/Hplong` 因此**不需要重测**（那两列是出厂开着档时才要动的口径）——同批重测已中止，见 §E738。 */
  let LOCK_NARROW = 0;
  const LOCK_NARROW_STAT = { windows: 0, narrowed: 0, greedyFallback: 0, picks: {} };
  function setLockNarrow(v) {
    const n = (v == null || v === '') ? 0 : Number(v);
    if (!(n === 0 || n === 1)) throw new Error('setLockNarrow: 只能是 0 或 1（0 = 出厂：锁上即作废本回合探索；1 = 锁上只许在链内键里探索）；收到 `' + v + '`');
    LOCK_NARROW = n; return LOCK_NARROW;
  }
  function lockNarrowOn() { return LOCK_NARROW; }
  function lockNarrowStat() { return { windows: LOCK_NARROW_STAT.windows, narrowed: LOCK_NARROW_STAT.narrowed, greedyFallback: LOCK_NARROW_STAT.greedyFallback, picks: LOCK_NARROW_STAT.picks }; }
  function resetLockNarrowStat() { LOCK_NARROW_STAT.windows = 0; LOCK_NARROW_STAT.narrowed = 0; LOCK_NARROW_STAT.greedyFallback = 0; LOCK_NARROW_STAT.picks = {}; }
  /* 纯函数：这一格的"链内键"。条件与 `seqLockedTurn` **同一批**（不另起一份判据 ⇒ 否则又是一个"两处各写一遍"）。 */
  function chainKeysOf(state, pid) {
    const out = [];
    const me = (state && state.p && state.p[pid]) ? state.p[pid] : null;
    if (!me) return out;
    if ((me.elec || 0) > 0 || (me.boom || 0) > 0 || me.lastSkill === R.SK.CHARGE) { out.push(R.SK.RAILGUN); out.push(R.SK.LASER_EYE); }
    let cursing = me.lastSkill === R.SK.CURSE;
    if (!cursing && state.p) {
      for (let zi = 0; zi < state.p.length && !cursing; zi++) {
        const zs = state.p[zi].stickers || [];
        for (let zj = 0; zj < zs.length; zj++) if (zs[zj] && zs[zj].owner === pid) { cursing = true; break; }
      }
    }
    if (cursing) { out.push(R.SK.FIRESTORM); out.push(R.SK.CURSE); }
    return out;
  }
  /* ===== v1.8.33（10-24 夜 · 用户点名「研究一下类似于摄魂的高 ep 下软注入方案，测一下会出现什么变化」）=====
   * 贴贴的**探索期软注入**：照 `setDrainPush` 那一族的形状 —— 只把牌**并进探索集**（不强落子、不改规则、不消耗 `state.rng`），
   * 窗口 = **自己 ep ≥ 3**（与 v1.5.142 裁定① 的 `HOLD_MIN_EP[CURSE]=3` 同一条线，不另立门槛），
   * 剂量 = 每 N 个窗口一次（avalanche 散列），钩子只挂在 `epsMode==='soft' && eps>0` 的分支 ⇒ 训练/考卷/门禁（eps=0）逐字不变。
   * 为什么需要它（§E711/§E712 实测）：现役包在产品口径 `k=5` 下贴贴 **0.000/局**（250 局 0 手），
   *   把 K 放到 12 才有 0.124/局 ⇒ 挡它的是"探索只看前 5 个键"；窄锁档能救"贴上之后的续手/天火"，
   *   但救不了"第一手都抽不到" ⇒ 这两档是**互补的两半**，所以要一起测（2×2）。
   * 默认 **0 = 关**：这是线上（浏览器口径）的新行为 ⇒ 只搭台量价，要不要开等用户裁。 */
  /* 2026-10-25 00:4x（用户裁定）：出厂回 **0**，与 `LOCK_NARROW` 同一刀。
   *   上一班按"没代价就开"把它设成 1，用户纠正的判据是「**有效**才开；没代价也没效果的注入没必要开，
   *   至少研究出场上真的出现引爆再说」。而 §E730 的读数正是"没代价、也没引爆"：
   *   三枚包 × 两 seed 上强度最大 −0.30pt（0.6SE）、贵卡占比不动、贴贴确实露脸（0.1~0.4% 出手占比），
   *   但**天火在所有臂上都是 0.00%** ⇒ 单靠顺位注入到不了引爆 ⇒ 这条线要动的是**引爆的前置件/定价**，不是注入剂量。
   *   研究账与下一步见 §E738。 */
  let CURSE_PUSH = 0;
  const CURSE_PUSH_EP = 3;                 // 与 HOLD_MIN_EP[CURSE] 同一条（v1.5.142 裁定①），不在这里重设门槛
  const CURSE_PUSH_STAT = { windows: 0, applied: 0 };
  function setCursePush(v) {
    const n = (v == null || v === '') ? 0 : Number(v);
    if (!(n === 0 || (Number.isInteger(n) && n >= 1 && n <= 12))) {
      throw new Error('setCursePush: 只能是 0 或 1..12（0 = 关；N = 每 N 个窗口软注入一次）；收到 `' + v + '`');
    }
    CURSE_PUSH = n; return CURSE_PUSH;
  }
  function cursePushOn() { return CURSE_PUSH; }
  function cursePushStat() { return { windows: CURSE_PUSH_STAT.windows, applied: CURSE_PUSH_STAT.applied }; }
  function resetCursePushStat() { CURSE_PUSH_STAT.windows = 0; CURSE_PUSH_STAT.applied = 0; }
  function cursePushWants(state, pid) {
    if (!(CURSE_PUSH >= 1)) return false;
    const me = (state && state.p && state.p[pid]) ? state.p[pid] : null;
    if (!me) return false;
    if ((me.ep | 0) < CURSE_PUSH_EP) return false;                // 用户 09-21 裁定①：低 ep 不许进探索集
    const want = (cursePushSalt(state, pid) % CURSE_PUSH) === 0;
    if (want) CURSE_PUSH_STAT.windows++;
    return want;
  }
  function cursePushSalt(state, pid) {
    /* 与 bigTPushSalt / drainPushSalt 同族：三段 avalanche，**不消耗 state.rng**（加法散列在本仓实测打不开，§E265 #9）。 */
    let h = ((((state && state.slotSalt) | 0)) ^ Math.imul((state && state.round) | 0, 0x49E07B55) ^ Math.imul(pid | 0, 0x1F83D9AB)) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 0x9E3779B1) >>> 0;
    return (h ^ (h >>> 11)) >>> 0;
  }
  /* 目标 = 威胁最大的人：**ep 最高**（下一手最能打出东西）⇒ 平手取**血少**的 ⇒ 再平手取**座位号小**的（不做随机 ⇒ §E215 那一族）。 */
  function bigTPushTarget(state, pid) {
    const opps = S.opponentsOf(state, pid);
    if (!opps || !opps.length) return null;
    const first = state.p[opps[0]] || {};
    let best = opps[0], bestEp = first.ep | 0, bestHp = (first.hp == null ? Infinity : first.hp);
    for (let i = 1; i < opps.length; i++) {
      const o = opps[i], pl = state.p[o] || {};
      const ep = pl.ep | 0, hp = (pl.hp == null ? Infinity : pl.hp);
      if (ep > bestEp || (ep === bestEp && hp < bestHp)) { best = o; bestEp = ep; bestHp = hp; }
    }
    return best;
  }
  function bigTPushPick(state, pid, cands) {
    const key = R.SK.BIG_T;
    let has = false;
    for (let i = 0; i < cands.length; i++) if (cands[i] && cands[i].key === key) { has = true; break; }
    if (!has) return null;                     /* 这张牌此刻打不出来 —— 价格/珠/封锁一律问候选枚举，不在这里抄第二份 */
    if ((bigTPushSalt(state, pid) % BIGT_PUSH) !== 0) return null;
    const t = bigTPushTarget(state, pid);
    if (t == null) return null;
    for (let i = 0; i < cands.length; i++) {
      if (cands[i] && cands[i].key === key && cands[i].target === t) return cands[i];   /* 优先用枚举里那一格（保留 bead/target2）*/
    }
    return { key: key, target: t, target2: null, bead: null };
  }

  /* ===== v1.6.3（用户 10-03 夜裁定：「接到风格 bot 席，默认难度也看得见」）：把上面那一档**包在任何 chooser 外面** =====
   * 为什么要这一层：`BIGT_PUSH` 的散列原本只路过 `policyChooserN` ⇒ 页面上**只有难度=「冠军（最强）」的席位**才用这颗包，
   *   其余五个具名难度走脚本启发式（`ui.js:512-513`），实测 **0 张 / 200 局**（§E281）⇒ 用户要的"看得见"在默认玩法里根本不发生。
   * ⚠ 三条形状纪律（都是本仓的老账）：
   *   ① **不许在这里抄第二份散列/目标/合法性判定** —— 全部复用 `bigTPushPick`（散列、档位、`null` 语义、挑目标一律走同一条路），
   *      否则"页面这档生效、考卷那档没生效"就是 §E274 的 G5 盲区换个位置复发（门不加载 `ui.js`，只能靠"实现只有一份"来保）。
   *   ② 传进去的"可选项"是脚本席手上的 `legal`（引擎已经按规则算过 `affordable` ⇒ 5 珠价与 3 回合封锁照旧由 `js/core` 判，这里不重算），
   *      它比冠军那条路少一层 `lockTarget`（"上一次被打断"的策略过滤）⇒ **作用面略宽，这是有意的**，且写死在下面门腿 ⑫f 的语义里。
   *   ③ **打不出来就原样返回 bot 自己的那一手**（`null` ⇒ 不动任何行为），并且**不消耗 `state.rng`**（散列是纯函数）
   *      ⇒ 关档时 `wrapBigTPush(f)` 与 `f` 必须逐字相同（门腿 ⑫c 钉这一条）。
   * 谁在用：只有 `js/ui/ui.js` 的**多人脚本席**调用 ⇒ 考卷/门禁里的脚本对手**一个字节都没变**（历史读数继续可比），
   *   2 人模式也不在这条路上（门腿 ⑫h 钉"2 人调用点不许包这一层"，因为用户裁定过"2p 不用大雷是正确情况"）。 */
  function wrapBigTPush(pickFn) {
    return function (state, pid, legal) {
      const aff = (legal || []).filter(function (l) { return l && l.affordable; });
      const hit = bigTPushPick(state, pid, aff);
      return hit || pickFn(state, pid, legal);
    };
  }

  function policyChooserN(params, temp, eps, epsK, epsMode) {
    params = normChampParams(params);
    const legacy = LEGACY(params);
    /* 实例级开关走 `__pendingBelief`（由 `policyChooserBelief` 在**构造期间**置位），不给这条签名加形参 ——
       理由见下面那条锚点警告。全局档（页面/训练）仍由 `BELIEF_SEARCH` 控。 */
    const bsMine = BELIEF_SEARCH === 1 || __pendingBelief === true;
    /* 信念搜索的开关：**模块级** `BELIEF_SEARCH`（页面/训练整档，用 `setBeliefSearch` 控）。
     * ⚠ 这一行**不许加第六个形参**：`tools/guard-cost-lib.mjs:94` 与 `tools/seq-reward-lib.mjs:81` 都把
     *   `  function policyChooserN(params, temp, eps, epsK, epsMode) {` 整行当**补丁锚点**（route ①：打进内部调用点），
     *   改签名就等于悄悄拆掉两道量具的锚 —— 门 D161 正是这么红给我看的（它抛"锚点没找到"而不是静默不补丁 = 设计意图）。
     *   要"一席开、一席关"（对撞/评测必需）请走 `policyChooserBelief`，它是**包一层**，不动这条签名。 */
    return function (state, pid, legal) {
      const aff = legal.filter(function (l) { return l.affordable; });
      const base = aff.length ? aff : [{ key: R.SK.JI, affordable: true }];
      if (legacy) {
        /* 旧包（v5/v6）：**完全按旧口径**（键 + ε + pickTargetN 目标）—— 否则历史基线不可比。 */
        const key = (eps && state.rng.next() < eps)
          ? base[Math.floor(state.rng.next() * base.length)].key
          : P.choose(state, pid, base, params, { temp: temp });
        const t1 = pickTargetN(state, pid, key);
        return { key: key, target: t1, target2: pickTarget2N(state, pid, key, t1), bead: null };
      }
      /* ===== v1.5.82（用户裁定）：**ep < 2 不蓄能**（只作用于 v7 口径；legacy 保持旧口径 => 历史基线可比）=====
       * 用户原话："ep=1 的时候本来就不应该蓄能，因为用到蓄能花费最低的激光眼也要额外一个 ep，
       * 至少要让他 ep>=2 才开始用，不然就是浪费。"
       * 规则依据（已核）：蓄能 cost=1，描述是"获得 1 枚能量珠……**只保留到下一回合**"；
       *   唯一的珠子消费卡是**电磁炮**（2 ジ + 1 电珠）；天火是引爆**符咒**，与珠子无关。
       * => 收入约 1 ジ/回合时，ep=1 蓄能**必然过期**。
       * 实测佐证（改前）：线上包 24/24 次蓄能决策都落在 ep=1；chargeProfile 得珠 23 颗、过期 23、**花掉 0**。
       * ⚠ 启发式而非定律：收入 >1/回合（聚能环第 3 次起 +3、避雷针 +4）时 ep=1 蓄能也可能成立。 */
      const v7base = econBase(state, pid, base);
      const cands = P.candidatesFor(state, pid, v7base, { lockTarget: lastCancelOther(state, pid) });
      /* ===== v1.5.332（用户 10-03 下午裁定）：大雷的"看得见"上线档 ⇒ **默认 0 = 关**，页面在 ui.js 显式开 8 =====
       * 用户的话：「最后大雷只要每四五局有一次就行了，亏损这一点没什么关系」⇒ 这一格从"要不要做"变成"那一档到底几赔"。
       * 机制：在"这张牌现在打得出来"（`cands` 里有它 = 引擎自己判过价格/珠/封锁）的窗口里，按 (每局盐, 回合, 座位)
       *   的确定性 avalanche 散列取 1/N ⇒ 命中就把这一手交给大雷，目标 = **ep 最高的对手**（平手取血少、再取座位号小）。
       * ⚠ 三条形状纪律：① **不消耗 `state.rng`**（散列是纯函数 ⇒ 不新增随机流；代价是这一手跳过了冠军自己的抽样，
       *    而"少抽一次"的后果已经包含在下面的实测价格里，因为量的就是这同一段代码）；
       *    ② **剂量不许按 1/N 换算**——窗口密度会随剂量自己漂（N=2 时 0.85 个/局 ‖ N=10 时 1.63 个/局，不打就一直攥着 5 珠）
       *    ⇒ "每几局一张"只有考卷说了算（§E270 就是这条的实测表）；
       *    ③ v1.5.333 起这一档**默认开着**（唯一来源 = 上面那个 `BIGT_PUSH` 常数）⇒ **训练/评测/门禁现在也带着它跑**；
       *       要拿"关掉档"当对照必须显式 `setBigTPush(0)`（评测侧 = `eval-5p --shipbigt=0`）⇒ "不设旗标"已经等于"开着"。
       *       ⇒ 本版之前那些"不设旗标 = 出厂形状"的历史读数，今后引用要么重跑、要么按 §E271 的价签（+0.52 ‖ +0.40pt）换算。
       * 实测价（产品考卷 24 局 × 2925 桌 · 与同树出厂卷逐桌配对 · §E270）：**N=8 ⇒ 3 血桌每 5.2 局一张、−0.52 ±0.16pt ‖ 5 血桌每 3.3 局一张、−0.40 ±0.13pt**；
       *   更猛的 N=6 是每 4.2 局一张、−0.85 ±0.19pt；更省的 N=10/12 在 5 血桌已到 −0.17/−0.22pt（贴着 0，没有再降的空间）。 */
      if (BIGT_PUSH >= 1) {
        const pushed = bigTPushPick(state, pid, cands);
        if (pushed) return pushed;
      }
      /* v1.5.30x：**默认关**的在线对手模型 + 1-ply 重放搜索（`setBeliefSearch(1)`）。
         关档时这一行短路都不进 ⇒ 现网行为逐字不变（门 D2xx 钉"默认值 / 关档逐字同结果 / 开档真的改变选择"三段）。 */
      /* ===== v1.5.139（用户 09-21 晨裁定：ε=0.25 全候选太糙，出现"贴贴不引爆/空爆"昏手，要"均匀但随机性小"）=====
       * 探索不再在**全体候选**上均匀采（那样会采到天火空爆、无意义贴贴这类网络几乎不给分的废着），
       * 而是：取网络打分前 K 的**不同技能键**（按各键最好候选的概率排序），在其中均匀采一个键、
       * 再取该键概率最高的候选。→ 既保证"多个不同技能"的对称破（2 席长程镜像从 ε=0 的 104 回合零决胜
       *   降到 ~30 回合、100% 决胜），又把昏手率压到近零（5 席空爆/局：全候选 0.77 → top5 键 0.07）。
       * `epsK` 默认 5；只在**浏览器运行时**（ui 传 eps>0）生效，训练/评测/门禁 eps=0 ⇒ 读数逐字不变。 */
      let pick;
      let chainOnly = null;   // v1.8.33 窄锁档：非 null = 本回合被锁且开了 LOCK_NARROW，探索集只许这些键
      const greedyOf = function () {
        /* v1.5.305：开档时**只有"贪心那一支"换成搜索**，探索支一字不动 ⇒ ε 的 rng 消耗与关档逐字相同。
           （门 D204⑧ 一开始就是为这条而红的：我先前把钩子挂在 ε 之前、又在搜索里自己抽了一次 ε ⇒
            `policyChooserBelief` 与 `policyChooserN` 的随机流错开一格，整局选择序列完全不同 ⇒ 同构漂移被抓现行。） */
        if (bsMine) { const bs = beliefSearchPick(state, pid, cands, params); if (bs) return bs; }
        return P.chooseCandidates(state, pid, cands, params, { temp: temp });
      };
      if (eps && state.rng.next() < eps && cands.length) {
        /* v1.5.141（#26 · 用户实机"防御偏多、丢了集火和滚环"）：`epsMode='soft'` 时探索**不得覆盖**
         * 贪心已经选定的"防御类型 / 聚能环"两型出手。理由不是审美，是算术：同一包同一装配下，均匀抽 top-K
         * 把防御出现率从贪心的 4.0% 抬到 26.4%，聚能环从 1.2% 抬到 **0.0%** —— 环是**连段**机制（第 3 次起 +3 ジ），
         * 40% 的随机打断等于把它从经济里删掉（量具：`tools/behavior-profile.mjs`）。
         * 默认不传 `epsMode` = v1.5.139 的原口径逐字不变 ⇒ 训练/评测/门禁读数不动。 */
        if (epsMode === 'soft') {
          /* v1.5.149-night 序列窗锁：**状态在链上（持珠/上手蓄能/有我方符咒）⇒ 本回合作废探索**，
           * 直接走贪心 —— 判据挂状态而非挂"贪心采样结果"（D115 首版证明采样后判锁会漏 (1−q)·ε）。
           * 与 v1.5.139-141 的"防御/环豁免"同族：那只管"这一手的类型"，这条管"这一手在不在序列上"。
           * ⚑ v1.8.33：`LOCK_NARROW=1` 时这一格改成"**窄锁**"——不作废探索，只把探索集限制成链内键（见 `chainKeysOf`）。 */
          if (seqLockedTurn(state, pid)) {
            if (LOCK_NARROW >= 1) { chainOnly = chainKeysOf(state, pid); LOCK_NARROW_STAT.windows++; }
            else pick = greedyOf();
          } else {
            const g = greedyOf();
            const gcat = R.byKey[g.key] && R.byKey[g.key].cat;
            if (g.key === R.SK.RING || gcat === R.CAT.DEFENSE) pick = g;
          }
        }
        if (!pick) {
          const f = P.forwardCands(state, pid, cands, params, { temp: 1 });
          const bestOf = {}, keys = [], keyIdx = {};
          for (let i = 0; i < cands.length; i++) {
            const k = cands[i].key;
            if (!(k in bestOf)) { bestOf[k] = f.probs[i]; keyIdx[k] = i; keys.push(k); }
            else if (f.probs[i] > bestOf[k]) { bestOf[k] = f.probs[i]; keyIdx[k] = i; }
          }
          /* `soft` 的第二半：探索集里**不放防御键** ⇒ 噪声只能"换一种打法"，不能"凭空摆一个架势"。
           * ===== v1.5.304（用户 09-29 下午委托 Qoder 裁定：把门槛从 ≥2 降到 ≥1）=====
           * 旧的那句括号（"只有防御键可选时不过滤——否则退化成一个确定性的ジ"）**是有意的取舍**（v1.5.141），
           * 但它把整条豁免留大了：第 1 回合非防御可付卡结构性地只剩 `ジ` 一张 ⇒ 剔除**整条不生效**。
           * 仪器直读（`tools/probe-round1-open.mjs --instrument=1`，现役包 · 3000 局，§E145）：
           *   ε 注入的防御占**全部防御出手**的 第 1 回合 100% ‖ 第 3 回合 58.56% ‖ 第 4+ 回合 74.73%
           *   ⇒ 页面上看到的防御**约四分之三是噪声**，09-21 那次"防御偏多"的裁定只治好了"非防御键 ≥2"的场面。
           * 买到（同探针两档对照）：各回合凭空防御清干净 —— 首手 0.00%；第 3 回合防御率 18.57%→8.26%、
           *   第 4+ 4.84%→1.29%（正好回落到"包自己的意图"基线）；5 人形 AI 夺冠 91.87%→92.47%（未配对 ⇒ 只当方向）。
           * 付出（如实记，别只看好处）：2 席同包 × 300 局的**长程镜像**平均 24.6→**31.3** 回合、僵死局 0/300→**2/300**。
           *   同档对照 ε=0 是 104.0 回合、僵死 **300/300** ⇒ 这道门仍留着破对称的能力，只是慢一拍。
           * ⇒ "退化成一个确定性的ジ"不再是 bug 而是**正确行为**：那一回合本来就只有 ジ 值得探索。
           * ⚠ 这是**软分支**：训练与门禁一律 eps=0 ⇒ 走不到这一行 ⇒ 所有既有臂产物读数逐字不变（整轮门禁就是这条的验证）。 */
          let pool = keys;
          if (epsMode === 'soft') {
            const nonDef = keys.filter(function (k) {
              const d = R.byKey[k];
              return !(d && d.cat === R.CAT.DEFENSE);
            });
            if (nonDef.length >= 1) pool = nonDef;
          }
          const top = pool.sort(function (a, b) { return bestOf[b] - bestOf[a]; }).slice(0, Math.max(2, epsK || 5));
          /* ===== v1.5.142（用户 09-21 裁定）：修"探索只付铺垫成本、永远拿不到收益" =====
           * 病（DS 实测，`docs/research/logs/RESEARCH-LOG-2026-09-21-ds.md` §10）：贴贴/蓄能**只在 ε>0 时出现**（ε=0 ⇒ 0.00/局；
           *   前台 ε.2 ⇒ 2.7/局），而**天火在两档都是 0.00/局** —— 因为探索只在"网络打分 top-K 键"里挑，
           *   天火从没被训练过、分低到进不了 top-K ⇒ **探索抽得到铺垫卡、结构性地抽不到收尾卡** ⇒
           *   每次探索出贴贴 = 净亏 1 ep 且必然不引爆。用户三条裁定（原话）：
           *   ① "把贴贴和蓄能的探索限制调到 3ep 才能使用"；
           *   ② "蓄能之后增加用电磁炮或激光眼的优先度"；
           *   ③ "贴贴之后增加继续贴以及天火的优先度"（理由："性价比最高的是贴三张然后引爆两次"）。
           * 只作用于 `epsMode==='soft'`（浏览器运行时口径）⇒ 缺省 epsMode 与 eps=0 的读数**逐字不变**。 */
          if (epsMode === 'soft') {
            const me = state.p && state.p[pid] ? state.p[pid] : {};
            const epN = Number(me.ep || 0);
            /* ① 铺垫型键的 ep 门槛：ep<3 时不进探索集（贴贴 1ep / 蓄能 1ep，低 ep 花掉必然过期或白贴）。 */
            const HOLD_MIN_EP = {};
            HOLD_MIN_EP[R.SK.CURSE] = 3;
            HOLD_MIN_EP[R.SK.CHARGE] = 3;
            let smart = top.filter(function (k) { return !(HOLD_MIN_EP[k] && epN < HOLD_MIN_EP[k]); });
            /* ② 蓄能之后：手上持电珠（或上一手是蓄能）⇒ 把珠子的出口**并进**探索集。 */
            const held = !!(me.elec || me.boom) || me.lastSkill === R.SK.CHARGE;
            /* ③ 贴贴之后：自己还有存活符咒（`stickers` 里 owner 是我）或上一手是贴贴 ⇒ 并入天火/继续贴。 */
            let cursing = me.lastSkill === R.SK.CURSE;
            if (!cursing && state.p) {
              for (let zi = 0; zi < state.p.length && !cursing; zi++) {
                const zs = state.p[zi].stickers || [];
                for (let zj = 0; zj < zs.length; zj++) if (zs[zj] && zs[zj].owner === pid) { cursing = true; break; }
              }
            }
            const forced = [];
            if (held) { forced.push(R.SK.RAILGUN); forced.push(R.SK.LASER_EYE); }
            if (cursing) { forced.push(R.SK.FIRESTORM); forced.push(R.SK.CURSE); }
            /* ===== §E275（v1.5.334）：摄魂指法的"残血软提升"（用户 10-03 晚：「你把摄魂的给做一下」+「HP=1 是仅调整
             * 探索时软提升的窗口，而不是调整实际规则」）=====
             * 走的正是上面那个 `forced` 口子（v1.5.142 给电磁炮/激光眼/天火开的那一个）⇒ **不强行落子**，只把它并进探索集；
             *   窗口与剂量都在 `drainPushWants` 里（自己 hp≤1 + avalanche % N），而"这张牌此刻可不可付"照旧由引擎判
             *   （下面那行要求 `keys.indexOf(...) >= 0` ⇒ 长程桌的 `drainHpMax=2` 一个字都没改）。 */
            if (drainPushWants(state, pid)) forced.push(R.SK.DRAIN);
            /* v1.8.33（§E711/§E712 · 默认关）：贴贴的高 ep 软注入 —— 走同一个 `forced` 口子（并集，不强落子）。 */
            if (cursePushWants(state, pid)) forced.push(R.SK.CURSE);
            for (let fi = 0; fi < forced.length; fi++) {
              /* 只在**可负担**（= 真在 keys 里）时并入；已在集里的不重复。 */
              if (keys.indexOf(forced[fi]) >= 0 && smart.indexOf(forced[fi]) < 0) {
                smart.push(forced[fi]);
                if (forced[fi] === R.SK.CURSE && CURSE_PUSH >= 1) CURSE_PUSH_STAT.applied++;
              }
            }
            if (smart.length) top.length = 0, Array.prototype.push.apply(top, smart);   // 兜底：绝不让集合变空
          }
          /* ===== v1.8.33 窄锁档（默认关 ⇒ 这一段整体不进）=====
           * 被锁的那一回合：探索只在**链内键 ∩ 可付**里换招（v1.5.149 的"不许撒手到链外"照旧成立）；
           * 链内一张都可付都没有 ⇒ 回退贪心（绝不落到链外，也绝不凭空造一个非法动作）。 */
          if (chainOnly) {
            const inChain = [];
            for (let ci = 0; ci < chainOnly.length; ci++)
              if (keys.indexOf(chainOnly[ci]) >= 0 && inChain.indexOf(chainOnly[ci]) < 0) inChain.push(chainOnly[ci]);
            if (!inChain.length) { LOCK_NARROW_STAT.greedyFallback++; pick = greedyOf(); }
            else { top.length = 0; Array.prototype.push.apply(top, inChain); LOCK_NARROW_STAT.narrowed++; }
          }
          if (!pick) pick = cands[keyIdx[top[Math.floor(state.rng.next() * top.length)]]];
        }
      } else {
        pick = greedyOf();
      }
      /* §E646（路线 B）：送盾目标的部署层先验。**挂在 pick 已经定完之后** ⇒ 不消耗 `state.rng`、
       *   不改"要不要打这张牌"、关档（默认）短路都不进 ⇒ 随机流与开档/关档逐字同（D204⑧ 那族"钩子挂错位置把随机流错开一格"的错，形状上防掉）。 */
      let shipTarget = pick.target;
      if (SUPPORT_PRIOR >= 1 && pick.key === R.SK.HOLO) {
        const t = supportPriorTarget(state, pid);
        if (t !== null) shipTarget = t;
        else if (SUPPORT_PRIOR === 2) {
          /* 挑不到 ⇒ 这一手不送：落回"攒"（`JI`，可付且合法时）；连攒都不合法就照旧送出（不许凭空造一个非法动作）。
           *   两档的差别不是洁癖：§E644 四 实测"少而准"里大半的强度收益来自**少送本身**（省下 1 费与回合节奏），
           *   而 §E643 二 被量过的那条 churn 臂正是"挑不到就不给盾（改攒）"这一形 ⇒ 档 2 复现它，档 1 只改给谁。 */
          /* v1.7.105：改攒**不是必然** —— 只有 hash 抽中 `SUPPORT_PRIOR_SKIP_P` 才改攒，否则照网络送出去。
           *   ⇒ 档 2 不再等价于「几乎取消送盾」，留了随机性（用户：「免得完全变成脚本工作」）。 */
          if (supportPriorRand(state, pid, 2) < SUPPORT_PRIOR_SKIP_P) {
            const ji = legal.find(function (l) { return l.key === R.SK.JI && l.affordable; });
            if (ji) return { key: R.SK.JI, target: null, target2: null, bead: null };
          }
        }
      }
      return { key: pick.key, target: shipTarget, target2: pickTarget2N(state, pid, pick.key, shipTarget), bead: pick.bead };
    };
  }
  /* ===== v1.5.30x（Qoder 09-30 夜 · **默认关**）· 在线对手模型 + 1-ply 引擎重放搜索 =====
   * 病名与价签（`docs/research/logs/RESEARCH-LOG-2026-09-28-qoder.md` §E152d/§E153 ‖ 仪器 `docs/artifacts/e152b-arms.mjs`）：
   *   ① 只在一局之内、按**席位身份**的在线频次表 + 搜索 ⇒ 打脚本桌 **+44.08pt [34.81,53.36]**（60 桌 × 20 局 · n=1200 局/臂）；
   *   ② 与现役包**同桌正面对撞** ⇒ **+66.00pt [59.46,72.54]**（同桌的包席从 33~37% 掉到 5.00%）；
   *   ③ 代价：一次决策 25.9 个候选 × 0.075 ms 重放 = **1.95 ms**，四席一回合约 8 ms（`docs/artifacts/e153-cost.mjs`）；
   *   ④ 对照：把行为统计塞进网络特征，每席只装得下 1~4 个量 ⇒ 只有 **+7.83 / +15.50pt**，却要付 `FEAT_S` 换代 + 规则指纹真的变。
   *   ⇒ 所以这条路**不碰 `policy.js`**、不动 `FEAT_S`、不动指纹；关档（`BELIEF_SEARCH === 0`）时下面这些函数一次都不进，
   *     现网行为逐字不变（门 D2xx 钉"关档 = 直接调 policyChooserN 的逐字同结果"）。
   * ⚠ 只用**公开信息**：条件量是"决策点上谁都能看见的"（该席 ep 档 / 是否富有 / 上一手），
   *   学习信号是 `state.events` 里**已经发生**的 `action` 事件（含人类那一手）⇒
   *   珠的**类型**、未出手的**目标**一概不读（v1.5.15 那条泄漏红线在这里同样成立）。
   * ⚠ 评估函数是"本回合结算后的血量优势"（**近视**）。把现役包 logit 当评估的混合版**已否证**：
   *   同批 200 局/臂，`hyb-none` 比现役包还差 **28.00pt**（§E153）⇒ 网络的 logit 是"同一状态内候选之间的偏好"，不是跨状态可比的价值。 */
  let BELIEF_SEARCH = 0;
  let BELIEF_PLY = 1;                           /* 评估往前推几回合（§E156b 的病：1-ply 看不见"蓄珠→下回合电磁炮""集火滚环"这类跨回合收益） */
  let BELIEF_TGT = 0;                           /* 目标函数档：0=减存活对手血量**均值**（已量过的那版）· 1=减**最强活着的那个** · 2=均值 + 每次淘汰定价（§E161b） */
  function setBeliefPly(v) { const n = Math.floor(Number(v)); BELIEF_PLY = (isFinite(n) && n >= 1) ? (n > 3 ? 3 : n) : 1; }
  function beliefPly() { return BELIEF_PLY; }
  function setBeliefTarget(v) { const n = Math.floor(Number(v)); BELIEF_TGT = (isFinite(n) && n >= 0) ? (n > 2 ? 2 : n) : 0; }
  function beliefTarget() { return BELIEF_TGT; }
  let BELIEF_TIE = 0;                           /* 平票怎么破：0=取枚举顺序第一个（§E154~§E161 已量过那版）· 1=由网络打分裁决（§E161c） */
  function setBeliefTie(v) { const n = Math.floor(Number(v)); BELIEF_TIE = (isFinite(n) && n >= 0) ? (n > 1 ? 1 : n) : 0; }
  function beliefTie() { return BELIEF_TIE; }
  /* §E169 · **第 4 剂药**：前三剂（深度 / 定价对象 / 平票规则）都没碰"**跨回合资源本身**"，
     而 §E168 之后立着的两条代价恰好就是它：**珠经济归零**与**滚环消失**。⇒ 直接给这两样东西一个血量价。
     `BELIEF_BEAD` = 一枚"带进下一回合的珠"值几血（`endTurn` 之后 `elec`/`boom` 只可能是**本回合新蓄**的那枚，R9'）；
     `BELIEF_RING` = "环链条还活着"值几血（`endTurn` 只在"本回合那手是有效聚能环"时不清零 `ringStreak`，R10 ⇒ 非零就意味着下一手的环**免费且给 `min(streak+1,3)` 能量**）。
     ⚠ **两个默认都是 0 ⇒ 出厂形状逐字不变**（`beliefValue` 里那两项是 `0 × 量`，整数加法无浮点残差）。
     ⚠ 这一档**故意只做成研究旋钮**：不接 `ui.js`、不接页面 `localStorage` ⇒ 线上只有 §E153/§E155 已量的 `beliefSearch` 那一层。 */
  let BELIEF_BEAD = 0;
  let BELIEF_RING = 0;
  function setBeliefBead(v) { const n = Math.floor(Number(v)); BELIEF_BEAD = (isFinite(n) && n > 0) ? (n > 12 ? 12 : n) : 0; }
  function beliefBead() { return BELIEF_BEAD; }
  function setBeliefRingPrice(v) { const n = Math.floor(Number(v)); BELIEF_RING = (isFinite(n) && n > 0) ? (n > 12 ? 12 : n) : 0; }
  function beliefRingPrice() { return BELIEF_RING; }
  let __pendingBelief = false;                  /* 只在 `policyChooserBelief` 的**构造期间**为真 ⇒ 实例级开关，不动 `policyChooserN` 的签名 */
  const BELIEF_BEAM = 48;                       /* 候选数上界（浏览器保护；现役包实测均值 25.9 ⇒ 正常不触发） */
  function setBeliefSearch(v) { BELIEF_SEARCH = (v && String(v) !== '0' && Number(v) !== 0) ? 1 : 0; }
  function beliefSearchOn() { return BELIEF_SEARCH; }
  /* 签名里**不放**"有无持珠"：§E152d 诊断列量到决策点上每一次持珠（四批累计 1902 次）其上一手都是 `蓄能`
   * ⇒ 那一维被"上一手"完全解释（机制上必然：珠只在蓄能的下一回合存在，`state.js:13` + `resolve.js:1264-1268`）。 */
  function beliefSigOf(tier, wealth, lastKey) { return [tier, wealth, lastKey || '-'].join('/'); }
  /* ===== 历史**只从 `state.events` 重建**，不存在 state 上（§E159 实测过才改成这样的，不是推论）=====
   * 页面把 AI 的决策喂的是 `preState = S.cloneState(B.state)`（`ui.js:286/542/613`），而 `cloneState` 走
   *   `JSON.parse(JSON.stringify(s))`（`state.js:236`）⇒ 任何私有槽**每一手都被丢掉**。我第一版把表挂在非枚举槽上，
   *   于是浏览器里每手从空表开始：**83.25% 塌成 28.25%**，与"空模型 + 同样的搜索"（27.00%）分不开
   *   （配对差 1.25pt [−4.01, 6.51]）⇒ 开了档跟没开一样。事件流是引擎的公开记录、随克隆一起带走，
   *   只有它能同时满足仪器形状与页面形状。
   * ep 反推保真度（§E158 · 25 局 × 每决策 5 席 = 800 个对账点）：**逐位相同 95.88%、钱档（`ep>>1` 截 5）相同 99.00%**
   *   ⇒ 条件量用的是"档"不是余额 ⇒ 这点误差进不了判据（要精确余额才得把返还/减免全表补进来）。 */
  function beliefObserve(state) {
    const N = state.p.length;
    const ep = new Array(N).fill(0);
    const last = new Array(N).fill(null);
    const tab = {};
    const evs = state.events || [];
    for (let i = 0; i < evs.length; i++) {
      const e = evs[i]; if (!e) continue;
      if (e.type === 'ep' && typeof e.delta === 'number' && e.pid != null) { ep[e.pid] += e.delta; continue; }
      if (e.type !== 'action' || e.pid == null || e.outcome === 'insufficient' || e.outcome === 'invalid') continue;
      const kk = e.pid + '@' + beliefSigOf(Math.min(5, ep[e.pid] >> 1), ep[e.pid] >= 5 ? 1 : 0, last[e.pid]);
      let m = tab[kk]; if (!m) { m = {}; tab[kk] = m; }
      m[e.key] = (m[e.key] || 0) + 1;
      last[e.pid] = e.key;
      const def = R.byKey[e.key];
      if (def && typeof def.cost === 'number') { ep[e.pid] -= def.cost; if (ep[e.pid] < 0) ep[e.pid] = 0; }
    }
    /* 预测那一格与训练时**同一套构造**（用走查出来的 `last`，不用 `p.lastSkill`）⇒ 否则"训练条件"与"预测条件"
       是两个不同的量，表再准也接不上（本仓"分子分母不同构"那一族）。 */
    const sig = [];
    for (let i = 0; i < N; i++) sig[i] = i + '@' + beliefSigOf(Math.min(5, ep[i] >> 1), ep[i] >= 5 ? 1 : 0, last[i]);
    return { tab: tab, sig: sig };
  }
  function beliefPredict(b, pid) {
    const m = b.tab[b.sig[pid]]; if (!m) return R.SK.JI;
    let best = R.SK.JI, bv = -1;
    for (const k in m) if (m[k] > bv) { bv = m[k]; best = k; }
    return best;
  }
  /* §E169 · 跨回合资源的**手写价**（两档默认 0 ⇒ 下面恒等于 0，出厂形状逐字不变）。
     珠按"枚"计（同类上限 1，`resolve.js:1261-1268` 的 R9' ⇒ 最多 `elec`+`boom` = 2）；环按"链条活着"计，不随档位放大。 */
  /* §E192 · **第 6 剂，但函数形式不同**：§E190 把珠价的病定位成"**同回合互斥**"——电磁炮要 `2 ep + 1 电珠`，
     而蓄能一手就花掉 1 ep ⇒ 产品桌上珠价臂**有珠的决策里 100%（两批 100.0/99.6）买不起炮**，
     且**把 `BELIEF_BEAD` 从 1 抬到 4 整条链一字不变** ⇒ 加钱治不了它（前 5 剂全是"给资源发补贴"这一族）。
     ⇒ 这一档不定价"珠"，定价"**可兑现的珠**"：只有 `手上有珠 且 ep≥2`（下一手真的开得出炮）才算钱。
     ⚠ 它仍然是一条手写加项，但**编码的是跨回合的可行性约束**，不是资源偏好 ⇒ 成了就说明方向对，
        败了就是把"必须有状态价值头"再钉实一次。**默认 0 ⇒ 出厂形状逐字不变**（`0 × 0/1` 整数，无浮点残差）。 */
  let BELIEF_BEAD_RD = 0;
  function setBeliefBeadRedeemable(v) { const n = Math.floor(Number(v)); BELIEF_BEAD_RD = (isFinite(n) && n > 0) ? (n > 12 ? 12 : n) : 0; }
  function beliefBeadRedeemable() { return BELIEF_BEAD_RD; }
  /* §E193 · **第 7 剂，函数形式又不同：这一枚定价的是"转移"，不是"状态"**。
     §E192 的读法是：近视尺 + 状态价 ⇒ "**手里有一颗可兑现的珠**"本身就成了被奖励的状态，而开炮恰好销毁它
     （珠没了、2 点蓄能没了、`ringStreak` 断）⇒ `买不起炮` 从 100% 治成 0%，`买得起却不开` 却涨到 98.9~99.1%。
     ⇒ 这一枚给"**这一手真的把珠花出去了**"（电磁炮 / 激光眼）发一份固定钱，与状态价同尺度可比。
     **接在哪儿**：`beliefSearchPick` 的候选循环里（那里 `pool[ci].key` 已知），**不穿进 `beliefValue/beadTerm`**
     ⇒ `np-test` D210①′/①″ 的两处钉（`beadTerm` 里的乘法形状 + 默认分支那一整行字符串）**一字未动**，门不必改。
     ⚠ 默认 0 ⇒ 出厂形状逐字不变；且这份钱是**加在动作上**的，双计是明确的取舍（炮的伤害在叶子状态里已经结算过一次）。 */
  let BELIEF_FIRE = 0;
  function setBeliefFireSpend(v) { const n = Math.floor(Number(v)); BELIEF_FIRE = (isFinite(n) && n > 0) ? (n > 12 ? 12 : n) : 0; }
  function beliefFireSpend() { return BELIEF_FIRE; }
  function beadTerm(me) {
    /* ⚠ 这里的写法**整体是被门钉住的**：`np-test` D210①′ 用正则 `BELIEF_BEAD \* \(\(me\.elec` /
       `BELIEF_RING \* \(me\.ringStreak` 断言"旋钮真的进了评估"，①″ 又**按字符串**钉死默认分支那一整行
       （`... + beadTerm(me);`）⇒ 不许把它改成带第二参数的形式，也不许提成变量，那会让门假红。
       ⇒ 所以"动作价"（§E193）**故意不写在这里**：引擎里没有"本手开过炮"的状态字段，而候选卡名在这一层拿不到；
       它接在调用方 `beliefSearchPick` 的循环里（`pool[ci].key` 就地可得），这样这两处钉一个字都不用动。 */
    const beads = (me.elec ? 1 : 0) + (me.boom ? 1 : 0);
    return BELIEF_BEAD * ((me.elec ? 1 : 0) + (me.boom ? 1 : 0)) + BELIEF_RING * (me.ringStreak > 0 ? 1 : 0)
      + BELIEF_BEAD_RD * (beads > 0 && me.ep >= 2 ? 1 : 0);
  }
  function beliefValue(st, pid) {
    const me = st.p[pid];
    let sum = 0, n = 0, hi = -1, dead = 0;
    for (let i = 0; i < st.p.length; i++) {
      if (i === pid) continue;
      if (st.p[i].hp > 0) { sum += st.p[i].hp; n++; if (st.p[i].hp > hi) hi = st.p[i].hp; } else dead++;
    }
    /* §E161b · 目标函数的三档（默认 0 = §E156b/§E161 已量过的那把尺，一字不变）：
       病在"减**均值**"这一项上 —— 均值把"滚掉一个残血"判成**亏**（他本来就在平均值以下，他一死分母里少一个低项 ⇒ 均值反而涨），
       而 5 人局的胜负是**比名次**：干掉一个人就是往上挪一格。⇒ 1 减"最强的那个活着的人"，2 给每次淘汰一个固定价。
       ⚠ 这三档都是**近视**尺（只看这一回合结算后），§E161 已证"多看一手"不会把它变成远视 ⇒ 要修的是**定价**不是**深度**。 */
    if (BELIEF_TGT === 1) return 20 * (me.hp > 0 ? 1 : 0) + me.hp - (hi >= 0 ? hi : 0) + beadTerm(me);
    if (BELIEF_TGT === 2) return 20 * (me.hp > 0 ? 1 : 0) + me.hp - (n ? sum / n : 0) + 6 * dead + beadTerm(me);
    return 20 * (me.hp > 0 ? 1 : 0) + me.hp - (n ? sum / n : 0) + beadTerm(me);
  }
  /* §E161 · 把评估往前多推一手：**我自己那一手交给包的贪心**（否则"下一回合我会不会用这颗珠"无从判断 ⇒ 投资仍然看不见），
     其余席仍走信念表预测。默认 `BELIEF_PLY = 1` ⇒ 这个函数一次都不进（关档/一档都不为它花一次 clone）。 */
  function beliefAdvance(q, myPid, params) {
    if (q.over) return;
    const X = global.EpirusResolve, N = q.p.length;
    const bb = beliefObserve(q);                        /* 从 q 的事件重建 ⇒ 与页面形状同源（§E159 那条教训） */
    const picks = new Array(N).fill(null);
    const lg = Play.legalActions(q, myPid).filter(function (l) { return l.affordable; });
    const bq = lg.length ? lg : [{ key: R.SK.JI, affordable: true }];
    const cq = P.candidatesFor(q, myPid, econBase(q, myPid, bq), { lockTarget: false });
    if (cq.length) {
      const gp = P.chooseCandidates(q, myPid, cq, params, { temp: 1 });
      if (gp) picks[myPid] = { key: gp.key, target: gp.target == null ? null : gp.target, target2: gp.target2, bead: gp.bead };
    }
    for (let i = 0; i < N; i++) {
      if (i === myPid || !q.p[i] || q.p[i].hp <= 0) continue;
      let k = beliefPredict(bb, i);
      const lg2 = Play.legalActions(q, i);
      let aff = false;
      for (let j = 0; j < lg2.length; j++) if (lg2[j].affordable && lg2[j].key === k) { aff = true; break; }
      if (!aff) k = R.SK.JI;
      picks[i] = { key: k, target: null, target2: null, bead: null };
    }
    for (let i = 0; i < N; i++) {
      if (!picks[i] || !q.p[i] || q.p[i].hp <= 0) continue;
      S.attemptAction(q, i, picks[i].key, { bead: picks[i].bead, target: picks[i].target, target2: picks[i].target2 });
    }
    X.resolveActions(q); X.endTurn(q);
  }
  function beliefSearchPick(state, pid, cands, params) {
    const b = beliefObserve(state); if (!b || !cands || !cands.length) return null;
    /* ⚠ 这里**不许抽 `state.rng`**：探索的 ε 由调用方（`greedyOf` 所在的那条支）抽，一次决策只该有一次抽取。
       多抽一次就让开/关两档的随机流错开一格 ⇒ 整局轨迹分叉（门 D204⑧ 就是这么抓到我的）。 */
    const N = state.p.length;
    const others = [];
    for (let i = 0; i < N; i++) {
      if (i === pid || state.p[i].hp <= 0) continue;
      let k = beliefPredict(b, i);
      const lg = Play.legalActions(state, i);
      const aff = {};
      for (let j = 0; j < lg.length; j++) if (lg[j].affordable) aff[lg[j].key] = 1;
      if (!aff[k]) k = R.SK.JI;                     /* 预测那张卡这回合他打不起 ⇒ 退回 1 ジ（公开可算） */
      others.push({ pid: i, key: k });
    }
    /* 候选过多时按网络打分留前 BELIEF_BEAM 个（浏览器上界保护；现役包实测均值 25.9 ⇒ 正常不触发）。
       `X` 在这里就地取，不放模块顶层：`evo.js` 原来不依赖 `EpirusResolve`，不想为了这一档改加载顺序假设。 */
    const X = global.EpirusResolve;
    let pool = cands;
    if (cands.length > BELIEF_BEAM) {
      const scored = [];
      for (let i = 0; i < cands.length; i++) scored.push({ c: cands[i], v: P.value(state, pid, cands[i].key, params, null, cands[i]) });
      scored.sort(function (a, x) { return x.v - a.v; });
      pool = scored.slice(0, BELIEF_BEAM).map(function (s) { return s.c; });
    }
    let best = null, bv = -1e18, bn = -1e18;
    for (let ci = 0; ci < pool.length; ci++) {
      const q = S.cloneState(state);
      q.rng = { next: mulberry32((((state.round | 0) + 1) * 2654435761 + pid * 7919 + ci * 104729) >>> 0) };
      S.attemptAction(q, pid, pool[ci].key, { bead: pool[ci].bead, target: pool[ci].target, target2: pool[ci].target2 });
      for (let o = 0; o < others.length; o++) S.attemptAction(q, others[o].pid, others[o].key, {});
      X.resolveActions(q); X.endTurn(q);
      for (let p2 = 1; p2 < BELIEF_PLY; p2++) beliefAdvance(q, pid, params);   /* 默认 1 层 ⇒ 这行永不执行 */
      /* §E193 · **动作价（第 7 枚）接在这一行外面，不穿进 `beliefValue`** —— 这里 `pool[ci].key` 就地可得，
         而 `beadTerm`/默认分支那两处是被门按字符串钉着的 ⇒ 门不必动。`BELIEF_FIRE` 默认 0 ⇒ 这一句恒等于原样。 */
      let v = beliefValue(q, pid);
      if (BELIEF_FIRE > 0 && (pool[ci].key === R.SK.RAILGUN || pool[ci].key === R.SK.LASER_EYE)) v += BELIEF_FIRE;
      /* §E161c · **并列怎么破**：`beliefValue` 是一把整数血量的尺 ⇒ 大量候选**精确并列**（这一回合什么都不改变的手太多了），
         而默认形状"`v > bv + 1e-9` ⇒ 取枚举顺序里第一个最优"意味着**并列由候选的枚举顺序裁决**，那不是偏好 ⇒
         等于把包自己那部分风格（珠经济、连段）在平票时扔掉了。§E156b 看到的"三列塌"里有一部分是这个，不全是目标近视。
         `BELIEF_TIE = 1` ⇒ 平票改由**网络自己的打分**裁决（`P.value` 只在**同一状态内**可比——§E153 否掉的是拿它跨状态当价值）。
         ⚠ 默认 0 ⇒ 下面那条 `else if` 永不进，`bn` 从不参与判决 ⇒ 已量过的 §E154~§E161 那一版逐字不变。 */
      if (v > bv + 1e-9) {
        bv = v; best = pool[ci];
        bn = BELIEF_TIE === 1 ? P.value(state, pid, pool[ci].key, params, null, pool[ci]) : -1e18;
      } else if (BELIEF_TIE === 1 && Math.abs(v - bv) <= 1e-9) {
        const nn = P.value(state, pid, pool[ci].key, params, null, pool[ci]);
        if (nn > bn + 1e-12) { bn = nn; best = pool[ci]; }
      }
    }
    if (!best) return null;
    return { key: best.key, target: best.target == null ? null : best.target, target2: best.target2 == null ? null : best.target2, bead: best.bead || null };
  }

  /* v7：页面/工具的统一入口（候选感知 + 旧包自动回退）。
   * 返回 {key,target,target2,bead} —— 调用方**整个交给引擎**（play.js 的 normPick 认这个形状）。 */
  function pickChampion(state, pid, legal, params, temp, eps, epsK, epsMode) {
    return policyChooserN(params, temp, eps, epsK, epsMode)(state, pid, legal);
  }
  /* 实例级的"开档"入口（对撞/评测用）：**只是给构造过程挂个标记**，候选枚举、ε 探索、退回路径全都还是 `policyChooserN` 那一份。
   * ⚠ 我第一版在这里自己重写了"affordable → econBase → candidatesFor"三行（本仓"两份同构实现必漂移"的第五次诱惑），
   *   门 D204⑧ 用"eps=1 必须与 `policyChooserN` 逐字相同"把它判红 ⇒ 现在的形状没有第二份实现可漂。 */
  function policyChooserBelief(params, temp, eps, epsK, epsMode) {
    __pendingBelief = true;
    try { return policyChooserN(params, temp, eps, epsK, epsMode); }
    finally { __pendingBelief = false; }
  }

  /* 脚本 chooser 包一层（补目标），供 N 人局使用 */
  function wrapBotN(sel) {
    return function (state, pid, legal) {
      const k = sel(state, pid, legal);
      const key = (typeof k === 'string') ? k : (k && k.key);
      if (key == null) return { key: R.SK.JI, target: null, target2: null };
      /* ⚠️ v1.3.55：脚本**自己选的目标必须保留**。
       * 此前这里无条件用 pickTargetN 重算，把返回 `{key,target}` 的脚本
       * （pickProtoMine / pickProtoTransfer / pickFocusFire / pickDeepSaver）的目标
       * 整个丢掉 —— 也就是"会还手"的脚本在 N 人局里被剥掉了瞄准。
       * 对现有训练口径零影响：OPP_NAMES 那 9 个脚本都只返回技能名。 */
      const obj = (typeof k === 'object' && k) ? k : null;
      const t1 = (obj && obj.target != null) ? obj.target : pickTargetN(state, pid, key);
      const t2 = (obj && obj.target2 != null) ? obj.target2 : pickTarget2N(state, pid, key, t1);
      return { key: key, target: t1, target2: t2 };
    };
  }

  /* N 人一局：chooser[pid] 逐座位 */
  /* ===== Q3 深经济探针（千问方案）=====
   * 为什么需要：冠军一直在**原生经济**下被选出（终局 evalN 跑无补贴局）
   * → 深经济能力在选择那一刻完全不可见。只靠回放切片让它"被看到"不够，
   * 必须让它**进选择**。
   * 口径（本人定义，已写入文档）：把冠军喂到 ep=5 并补珠，**只打分"是否用出贵技能"，不打分胜负**：
   *   0.6 * min(1, 落地的高费技能数 / 2) + 0.4 * min(1, 出手的高费技能数 / 3)
   * 其中"高费" = 费用 >= 3 ジ。 */
  function evalEconProbe(params, games, n, seedBase) {
    const N = (typeof n === 'number' && n > 2) ? n : 3;
    let casts = 0, landed = 0, gamesRun = 0;
    for (let g = 0; g < games; g++) {
      const seat = g % N;
      const inner = policyChooserN(params, 0.15, 0);
      const ch = [];
      const mk = function (pid) {
        return function (state, id, legal) {
          if (id === seat) {                       // 只给冠军补资源（不改规则，仅评测用）
            const pl = state.p[seat];
            pl.ep = Math.max(pl.ep, 5);
            pl.elec = Math.max(pl.elec, 1);
            pl.boom = Math.max(pl.boom, 1);
          }
          return inner(state, id, legal);
        };
      };
      for (let pid = 0; pid < N; pid++) ch.push(mk(pid));
      // 记录出手：包一层在 seat 的 chooser 上
      const rec = { keys: [] };
      const seatSel = ch[seat];
      ch[seat] = function (state, id, legal) {
        const a = seatSel(state, id, legal);
        const k = (typeof a === 'string') ? a : a.key;
        const c = S.computeCost(state, id, k);
        rec.keys.push((c && c.ok && c.ep >= 3) ? k : null);
        return a;
      };
      const r = oneGameN(ch, seedBase + g * 977, N, { mode: TRAIN_MODE });
      for (let i = 0; i < rec.keys.length; i++) if (rec.keys[i]) casts++;
      const heavyKeys = {};
      for (const k of rec.keys) if (k) heavyKeys[k] = 1;
      for (const e of r.state.events) {
        if (e.type !== 'damage' || e.via == null) continue;
        if (!heavyKeys[e.via]) continue;
        const c2 = costOfKey(e.via, N);
        if (c2 != null && c2 >= 3) landed++;
      }
      gamesRun++;
    }
    const castRate = gamesRun ? casts / gamesRun : 0;
    const landRate = gamesRun ? landed / gamesRun : 0;
    /* 修正 1（v1.3.18）：**只奖励"落地"**。上一版 `0.4*casts/3` 奖励的是"出手"本身，
     * 于是它靠狂放高费技能刷分——即使全被挡下（实测 castPerGame≥3 但 landPerGame=0），
     * 与历史上 deal/proact"奖励打伤害却打不赢"是同类过拟合。出手不再给分。 */
    const score = Math.min(1, landRate / 2);
    return { score: score, casts: casts, landed: landed, games: gamesRun, castPerGame: castRate, landPerGame: landRate };
  }

  /* ===== (c) 补贴局探针：门槛绑**胜负**，不绑"贵技能落地次数" =====
   * 千问的警告：双枪已真正读取 def.dmg，于是 >=3 ジ 层里出现了可落地的伤害技能——
   * 但强制出双枪是**净负**（实测 -27pt）。任何"奖励贵技能落地"的探针都会选出
   * "乱挥双枪"的冠军。故判据改为**补贴局里的夺 1 率**。
   * 与 evalEconProbe 的三点不同：
   *   1) 打分对象是名次（夺1率/前二率），不是出手或落地次数；
   *   2) 冠军被强制在承诺视界 h 下行动 → 深经济分支不再依赖"恰好被抽到"；
   *   3) 补贴是**开局一次性给资源**（startEp），不是每次决策补满 → 必须把资源
   *      **转换**成胜利才算数，"有钱"本身不给分。
   * 对手口径与 evalEconProbe 一致：同权重自对弈（确定性、无脚本表依赖）。 */
  function evalSubsidyProbe(params, games, n, seedBase, opts) {
    const N = (typeof n === 'number' && n > 2) ? n : 3;
    const O = opts || {};
    const H = (typeof O.h === 'number' && O.h > 0) ? (O.h | 0) : 3;
    const START_EP = (typeof O.startEp === 'number' && O.startEp > 0) ? O.startEp : 4;
    const REGEN = (typeof O.regen === 'number') ? O.regen : 0;
    let first = 0, top2 = 0, played = 0, deepCast = 0;
    const keys = {};
    for (let g = 0; g < games; g++) {
      const seat = g % N;
      const inner = policyChooserN(params, 0.15, 0);
      const seatSel = makeCommitChooser(params, 0.15, H);
      let granted = false;
      const ch = [];
      for (let pid = 0; pid < N; pid++) {
        if (pid === seat) {
          ch.push(function (state, id, legal) {
            if (!granted) {                     // 开局一次性补贴（不改规则，仅评测用）
              granted = true;
              const pl = state.p[seat];
              pl.ep = Math.max(pl.ep, START_EP);
              pl.elec = Math.max(pl.elec, 1);
              pl.boom = Math.max(pl.boom, 1);
              /* ⚠ 这一步不能省：play.js:50-53 在**调用 chooser 之前**就算好了
               * legal[i].affordable，并在 chooser 返回后用**那个**值把买不起的选择
               * 强制改回 ジ。所以只改 pl.ep 时，贵技能在本回合进不了采样集。
               * 实测口径见 tools/grant-mech-diag.mjs（affordable 序列 = 前 3 次 false、
               * 之后 true：**只对每局第 1 回合无效**，因为改的是真实 state，会留到下一回合）。
               * 也就是说 evalEconProbe 的历史结论**只有首回合是盲的，其余仍然有效**——
               * 不要把它当成"纯测量假象"（我一度这么以为，实测否定了）。
               * 这里重算 affordable 是为了消掉那一个回合的盲区，让"白给资源"当回合就成立。 */
              if (legal) {
                for (let i = 0; i < legal.length; i++) {
                  const cc = S.computeCost(state, id, legal[i].key);
                  legal[i].affordable = !!(cc && cc.ok && cc.ep <= pl.ep);
                }
              }
            }
            const a = seatSel(state, id, legal);
            const k = (typeof a === 'string') ? a : a.key;
            const c = S.computeCost(state, id, k);
            if (c && c.ok && c.ep >= 3) { deepCast++; keys[k] = 1; }
            return a;
          });
        } else {
          ch.push(function (state, id, legal) { return inner(state, id, legal); });
        }
      }
      const r = oneGameN(ch, seedBase + g * 977, N, { regen: REGEN, mode: TRAIN_MODE });
      const rank = rankOf(r.state, seat, seedBase + g * 977);
      if (rank === 1) first++;
      if (rank <= 2) top2++;
      played++;
    }
    const firstRate = played ? first / played : 0;
    const top2Rate = played ? top2 / played : 0;
    return {
      score: firstRate,                     // 门槛用的就是它：补贴局夺 1 率
      firstRate: firstRate,
      top2Rate: top2Rate,
      games: played,
      deepCastPerGame: played ? deepCast / played : 0,
      deepKinds: Object.keys(keys).length
    };
  }

  /* 某技能的真实费用（评测用） */
  function costOfKey(key, n) {
    const st = S.createState('multi', { next: mulberry32(7) }, (n > 2 ? n : 3));
    st.slotSalt = slotSaltFor(7);
    for (let i = 0; i < st.p.length; i++) { st.p[i].ep = 99; st.p[i].elec = 3; st.p[i].boom = 3; }
    const c = S.computeCost(st, 0, key);
    return (c && c.ok) ? c.ep : null;
  }

  function oneGameN(choosers, seed, n, opts) {
    /* v1.4.0：模式可传（默认 'multi'）—— 5 血长程模式的评测要在这里换考卷 */
    const st = S.createState((opts && opts.mode) || 'multi', { next: mulberry32(seed) }, n, opts);
    st.slotSalt = slotSaltFor(seed);
    Play.autoGameN(st, choosers, undefined, (opts && opts.onRoundStart) || undefined);
    const dmg = [];
    for (let i = 0; i < n; i++) dmg.push(0);
    for (const e of st.events) if (e.type === 'damage' && e.to != null) dmg[e.to] += e.amt;
    return { winner: st.winner, rounds: st.round, dmg: dmg, state: st };
  }

  /* 名次（1 = 第一）：按（存活/血量）降序 */
  /* Q2(i) 完整名次（千问方案，纯训练/评测侧，不动 checkOver）：
   * 原来并列最高 HP 就判"平局"，但实测镜像平局里 89~93.5% 的三家 HP 向量本身可分
   * → 等于白扔一半训练样本。这里改成完整排序打破平局：
   *   存活优先 → HP 降序 → 累计承伤升序。
   * ⚠️ 只在**原来判平的地方**分出 1/2/3 名，胜/平/负的分值一律不变——
   *    历史上 deal/proact"奖励打伤害"养出过"打伤害不赢"的过拟合，次级键绝不能拿来加分。 */
  /* 名次（v1.3.57 修座位效应与平局问题）
   *
   * 旧实现：`alive → hp 降 → taken 升`，**没有 pid** ⇒ 完全并列时落到 Array.prototype.sort
   * 的稳定性 = 插入顺序 = **pid 升序**。实测（tools/rank-diag.mjs, 800 局 5 人对称场）：
   *   89.9% 的玩家处在并列组里，各座位 1st 率 P0=61.9% … P4=7.5%（极差 54.4pt）；
   *   把末位平局换成种子随机后 → 18.0/21.5/20.8/19.6/20.1%（极差 3.5pt）。
   * ⇒ 那个梯度**完全是名次规则的产物**，不是引擎的。
   *
   * 修法两条：
   *   1) 加第 4 键 **dealt（累计造成伤害）降序**——`damage` 事件现已带 `source`
   *      （地雷伤害 source=null，按规则不归属任何人）。它比"挨打少"更接近"打得好"，
   *      且与 pid 无关（实测可拆开 13% 对称场 / 55% 真实场的并列组）。
   *   2) 仍完全并列者 → **用本局 rng 洗牌后再稳定排序**：给定对局种子是确定性的，
   *      但在座位上**无偏**。这样名次仍是严格排列（所有调用方与历史指标口径不变），
   *      而"低 pid 白拿并列第一"这个 artifact 消失。
   * ⚠️ 不要退回"并列按 pid 升序"：那等于给座位 0 送分。 */
  function rankOf(st, seat, seed) {
    const n = st.p.length;
    const taken = [], dealt = [];
    for (let i = 0; i < n; i++) { taken.push(0); dealt.push(0); }
    for (const e of st.events) {
      if (e.type !== 'damage') continue;
      if (e.to != null) taken[e.to] += (e.amt || 0);
      if (e.source != null) dealt[e.source] += (e.amt || 0);
    }
    const order = [];
    for (let i = 0; i < n; i++) {
      const hp = Math.max(0, st.p[i].hp);
      order.push({ i: i, alive: hp > 0 ? 1 : 0, hp: hp, taken: taken[i], dealt: dealt[i] });
    }
    /* 洗牌种子：**由调用方传入"本局种子"**（每个调用方手里都有）。
     * 三个都不能用：
     *   ✗ 消耗 st.rng —— 不幂等，同一局问多个座位会得到互相矛盾的名次；
     *   ✗ 用 (round, events.length) 派生 —— 对称场里大量对局取值相同 ⇒ 少数几个排列被
     *     反复使用，pid 偏置重新出现（实测极差 18.7pt，而每局种子只有 3.5pt）；
     *   ✗ 退回"并列按 pid 升序" —— 等于给座位 0 送分（实测极差 54.4pt）。
     * 未传 seed 时退化为"事件流哈希"（只取与 pid 无关的量），保证有熵、且仍确定。 */
    let sd;
    if (typeof seed === 'number' && isFinite(seed)) sd = (seed >>> 0) || 1;
    else {
      let h = (0x9e3779b9 ^ Math.imul(n, 2654435761) ^ Math.imul(st.round || 0, 40503)) >>> 0;
      for (let k = 0; k < st.events.length; k++) {
        const e = st.events[k];
        h = (Math.imul(h ^ ((e.type || '').length + 1), 16777619) ^ Math.imul(((e.amt || 0) + 1), 2246822519)) >>> 0;
      }
      sd = h || 1;
    }
    const prnd = mulberry32(sd);
    for (let k = order.length - 1; k > 0; k--) {
      const j = Math.floor(prnd() * (k + 1));
      const t = order[k]; order[k] = order[j]; order[j] = t;
    }
    order.sort(function (a, b) {
      if (a.alive !== b.alive) return b.alive - a.alive;
      if (Math.abs(b.hp - a.hp) > 1e-9) return b.hp - a.hp;
      if (a.taken !== b.taken) return a.taken - b.taken;
      return b.dealt - a.dealt;
    });
    for (let k = 0; k < order.length; k++) if (order[k].i === seat) return k + 1;
    return n;
  }

  /* 经济统计：本局"达到过的最高 ep"与"贵技能（ep ≥ 2）出手次数"。
   * 经济锁死的病根：AI 永远停在 ep≤1 的 ジ→枪 循环，2 ジ 以上技能永久不可负担。
   * 旧 fitness 的 proact/deal 奖励"立刻打伤害"，而攒钱必须先连出ジ（0 伤害）→
   * 旧口径实际上在惩罚攒钱，故加 save/conv 两项把梯度补上。 */
  /* v1.5.181（DS）：示范注入的**开火计数 + 未开火原因分解** ——
   * 动因（实测）：三种配置（只给钱 / 教师 heavyfire / 教师 pickBigTFocus）下"真正的落雷"使用率全是 0.00%，
   * 却**无法判断**是"从未轮到 / 教师无动作 / 买不起 / 被 only 过滤 / 注入了没被选择"。
   * `KILL_FIELD` 在 v1.5.160 补 `countKillSeats()` 之前也是这个处境（§N12：**横幅读回证明不了作用点发生**）。
   * 位置：`makeEconChooser` 里**唯一**的注入出口。 */
  const IMIT_STAT = { tries: 0, fired: 0, noTeacherAction: 0, unaffordable: 0, filteredByOnly: 0, seats: {}, keys: {} };
  function countImitInject() {
    return { tries: IMIT_STAT.tries, fired: IMIT_STAT.fired, noTeacherAction: IMIT_STAT.noTeacherAction,
      unaffordable: IMIT_STAT.unaffordable, filteredByOnly: IMIT_STAT.filteredByOnly,
      seats: Object.assign({}, IMIT_STAT.seats), keys: Object.assign({}, IMIT_STAT.keys) };
  }
  function resetImitStat() {
    IMIT_STAT.tries = 0; IMIT_STAT.fired = 0; IMIT_STAT.noTeacherAction = 0;
    IMIT_STAT.unaffordable = 0; IMIT_STAT.filteredByOnly = 0; IMIT_STAT.seats = {}; IMIT_STAT.keys = {};
    resetImitAttribution();
    return true;
  }
  /* ===== v1.5.189：把"教师替该席下的手"从"这个包自己的手"里**分出来** =====
   * 病（今天用一条单变量对照才抓到的）：`IMIT_OVERRIDE` 的注入是 `return ta` —— 事件流里**没有任何东西**
   * 说明这一手是谁选的 ⇒ 于是"示范族"的所有臂内读数（`bigUses` / 连带 / 链率…）都混着教师的手，
   * 而"这一项到底在评谁"这句话根本没有答案（`BIGT_CHAIN_W` 那条线就是这么被判死刑的：示范一关，链恒 0）。
   * 做法：局末拿本局的注入台账（`rec.imit`，按卡名计数）**按事件顺序**给该席的 `action` 事件补 `e.imit = true`。
   *   · 只加字段、只记账 ⇒ **不进 fit、不动 rng ⇒ 行为逐字不变**（默认关时连台账都不建）。
   *   · 同一张卡被同一席打多次时，"哪一次是注入的"这件事**顺序相关、可能错配**，但**条数一定对**
   *     ⇒ 所以对外只承诺计数（`imitAttribution()`），不承诺"这一条事件是教师的手"。
   *   · 台账有条数、事件里却不够 ⇒ 记进 `unmatched`（= 注入了但那一手没成为事件，例如当回合被淘汰）⇒ 必须看得见，不许静默。 */
  const IMIT_ATTR = { games: 0, tagged: 0, unmatched: 0, keys: {} };
  function tagImitActions(events, imitPend, seat, ctx) {
    const pend = Object.assign({}, imitPend || {});
    let tagged = 0;
    const perKey = {};
    /* v1.5.189：还要按**经济口径**分桶 —— 臂上开着 `REGEN_SLICE`/承诺局时，"窗口后还在打大雷"这句话
     * 可能只是"在白拿 ep 的那些局里打"。不分这一刀，就等于把补贴局的行为当成学会的行为（今天的读数正需要它）。 */
    const bucket = (ctx && ctx.subsidy) ? 'sub' : 'econ';
    for (const e of (events || [])) {
      if (!e || e.type !== 'action' || e.pid !== seat || !e.key) continue;
      const k = e.key;
      if (!perKey[k]) perKey[k] = { imit: 0, native: 0 };
      if (e.outcome !== 'ok') continue;                 // 失败/作废的一手不记进"出手"账（与 countBigCards 同口径）
      if ((pend[k] || 0) > 0) { e.imit = true; pend[k]--; tagged++; perKey[k].imit++; }
      else perKey[k].native++;
    }
    let left = 0;
    for (const k in pend) left += pend[k] || 0;
    IMIT_ATTR.games++; IMIT_ATTR.tagged += tagged; IMIT_ATTR.unmatched += left;
    for (const k in perKey) {
      if (!IMIT_ATTR.keys[k]) {
        IMIT_ATTR.keys[k] = { imit: 0, native: 0, imitSub: 0, nativeSub: 0, imitEcon: 0, nativeEcon: 0 };
      }
      const a = IMIT_ATTR.keys[k], o = perKey[k];
      a.imit += o.imit; a.native += o.native;
      if (bucket === 'sub') { a.imitSub += o.imit; a.nativeSub += o.native; }
      else { a.imitEcon += o.imit; a.nativeEcon += o.native; }
    }
    return { tagged: tagged, unmatched: left, keys: perKey };
  }
  function imitAttribution() {
    const keys = {};
    for (const k in IMIT_ATTR.keys) {
      const a = IMIT_ATTR.keys[k];
      keys[k] = { imit: a.imit, native: a.native, imitSub: a.imitSub, nativeSub: a.nativeSub, imitEcon: a.imitEcon, nativeEcon: a.nativeEcon };
    }
    return { games: IMIT_ATTR.games, tagged: IMIT_ATTR.tagged, unmatched: IMIT_ATTR.unmatched, keys: keys };
  }
  function resetImitAttribution() {
    IMIT_ATTR.games = 0; IMIT_ATTR.tagged = 0; IMIT_ATTR.unmatched = 0; IMIT_ATTR.keys = {};
    return true;
  }
  function makeEconChooser(inner, agg, teacherFn, imitB, onlyKey, subFlag) {
    /* v1.8.23：onlyKey 也可写成逗号列表（爆珠链要同时教 charge 与 laserEye）。 */
    const onlySet = onlyKey ? String(onlyKey).split(',').map(function (s) { return s.trim(); }).filter(Boolean) : null;
    const onlyOK = function (k) { return !onlySet || onlySet.indexOf(k) >= 0; };
    /* v1.5.189：`rec.imit` = 本局**教师替该席下过的手**（按卡名计数，懒创建 ⇒ 示范关时零开销）。
     * 为什么必须有：override 是直接 `return ta`，事件流里"教师那一手"与"包自己那一手"**长得一模一样**
     * ⇒ 一切"示范到底学会了什么"的读数都混着教师的手（今天靠"示范全关"的单变量对照才看出来）。
     * 只做记账，不参与任何 fit ⇒ 默认关/开都不改行为。 */
    const rec = { maxEp: 0, heavy: 0, hold: 0, heavy4: 0, imit: null };
    const fn = function (state, pid, legal) {
      const p = state.p[pid];
      if (p && p.ep > rec.maxEp) rec.maxEp = p.ep;
      /* ===== v1.5.96：**真示范**（override），而不是只奖励"与教师一致" =====
       * 现状（v1.5.31 起的 C 方案）：教师只用于 `_mt/_mm` 一致性计数，进 fit 的是 `imitB × 一致率`
       * ⇒ 策略**从来没有真的走过教师那条线**："环先付 3 ジ、之后每回合 +3"这种**跨回合后果**从未被体验
       * ⇒ 学不到"它值多少"（第九轮复核 §5-2 的**价值估计病**：可负担 59~98% / 候选表 100% / 转化 0.00%）。
       * 打开 `IMIT_OVERRIDE`：以 `imitB` 的概率**直接执行教师的动作**（退火期后自动失效，与一致性奖励同一条退火管道）；
       * 只在教师给的动作**确实可负担**时才覆盖（否则会白扔一回合，把示范教成"浪费"）。
       * **默认关 ⇒ 行为一字不变**（旧产物、旧读数仍可比）。 */
      /* v1.5.99：`IMIT_SUB_ONLY` —— "只教目标卡"的示范**只在补贴局里发生**。
       * 理由（v1.5.98 §3 的机制结论）：原生经济里示范"开环"≡ 对"攒"征税（逼它把攒的 ep 花掉）；
       * 补贴局里花的是**白来的 ep**（`regenForGame`/承诺局）⇒ 不构成对"攒"的惩罚。
       * 只对**设了 `onlyKey`** 的示范生效 ⇒ 段1（教攒、不设 only）**不受影响**。 */
      const subOK = (!IMIT_SUB_ONLY || !onlySet || !!subFlag);
      if (IMIT_OVERRIDE && teacherFn && imitB > 0 && subOK && state.rng && typeof state.rng.next === 'function') {
        if (state.rng.next() < imitB) {
          IMIT_STAT.tries++;                     // v1.5.181：轮到了（rng 过）
          const ta = teacherFull(teacherFn, state, pid, legal);
          const okL = ta && ta.key && legal.some(function (l) { return l.key === ta.key && l.affordable; });
          /* v1.5.98：`onlyKey` 未设 ⇒ 与旧版一致；设了 ⇒ **只覆盖教师真要教的那张卡**。
           * v1.5.181：这里同时记下**没开火的原因**，好把"没注入 / 没被选择"分开。 */
          if (!ta || !ta.key) { IMIT_STAT.noTeacherAction++; }
          else if (!okL) { IMIT_STAT.unaffordable++; }
          else if (!onlyOK(ta.key)) { IMIT_STAT.filteredByOnly++; }
          else {
            if (agg) { agg.use[ta.key] = (agg.use[ta.key] || 0) + 1; }
            IMIT_STAT.fired++;
            IMIT_STAT.seats[pid] = (IMIT_STAT.seats[pid] || 0) + 1;
            IMIT_STAT.keys[ta.key] = (IMIT_STAT.keys[ta.key] || 0) + 1;
            /* v1.5.189：本局台账（局末由 `tagImitActions` 拿去给事件打标记）。**不动 rng、不进 fit** ⇒ 行为逐字不变。 */
            if (!rec.imit) rec.imit = {};
            rec.imit[ta.key] = (rec.imit[ta.key] || 0) + 1;
            return ta;
          }
        }
      }
      const a = inner(state, pid, legal);
      // 真实费用必须走 computeCost（R.byKey[key].cost 是数字，不是对象）
      if (a) {
        if (agg) {
          agg.use[a.key] = (agg.use[a.key] || 0) + 1;
          if (!agg.aff) agg.aff = {};
          for (let ai = 0; ai < legal.length; ai++) if (legal[ai].affordable) agg.aff[legal[ai].key] = 1;
        }
        // C 方案：与脚本教师比对（只在退火期内计数）
        if (teacherFn && imitB > 0 && agg) {
          const tk = teacherAction(teacherFn, state, pid, legal);
          /* v1.5.98：`onlyKey` 过滤**也适用奖励计数** —— 只对"教师真要教的那张卡"计一致性；
           * 否则"与教师的 fallback（蓄能/ジ）一致"会白拿奖励，正是抹掉"攒"的那股力。
           * v1.5.99：`IMIT_SUB_ONLY` 同理也适用计数（否则奖励侧仍在原生局里推它花掉攒的 ep）。 */
          if (tk != null && onlyOK(tk) && subOK) {
            agg._mt = (agg._mt || 0) + 1; if (a.key === tk) agg._mm = (agg._mm || 0) + 1;
          }
        }
        const c = S.computeCost(state, pid, a.key);
        if (c && c.ok) {
          if (c.ep >= 2) rec.heavy++;
          /* v1.5.116：花在"会造成伤害"的卡上的 ep（`R.ATK_EFFECT` 是规则里声明的攻击向卡表）⇒
           * `CONV_OFFENSE` 用它做分子，专治"把兑现奖励刷成乱摁防御"这条 captured 路径。 */
          if (R.ATK_EFFECT.indexOf(a.key) >= 0) rec.offSpend = (rec.offSpend || 0) + (c.ep || 0);
          if (c.ep >= 4) rec.heavy4++;
          // 攒钱动作：手里有 ep 却选择不花钱。
          // 这是每一步都可得的稠密信号——否则 ep=1 时 99.8% 选枪，
          // "攒到 ep>=2" 这个事件几乎采样不到，奖励再大也拿不到梯度。
          if (c.ep === 0 && p && p.ep >= 1) rec.hold++;
        }
      }
      return a;
    };
    fn.rec = rec;
    return fn;
  }

  const DIV_BETA = 0.60;   // 技能覆盖熵权重
  /* 攒钱奖励上限（到 target 点满额）。v1.5.116：改成 let 并接入 econ-env 的覆盖通道
   * （env 名见 `server/econ-env.mjs` —— **这里不要写字面的 env 名**：D77 是全文扫描，
   * 注释里出现一个 `EPIRUS_*` 就会被判成"第二个读取点"而打红）。默认 0.05 ⇒ 出厂行为不变。 */
  let STOCK_BONUS = 0.05;
  const HOARD_PEN = 0.12;    // 囤积惩罚上限（到 cap×HOARD_CAP_MULT 满额）
  /* ===== v1.5.116（第十二轮复核 L2′）：把经济 shaping 的"阶梯"换回"斜率"，**默认全关 ⇒ 出厂行为一字不变** =====
   * 复核实测（docs/research/reviews/OPTIMIZATION-ep-cliff.md §3/§5）：
   *   · 惩罚挂在 `maxEp` ⇒ 对照（峰 ep 39.9·胜 8.3%）与环×8（峰 21.3·胜 27.1%）**同为 −0.070**，分不开好坏；
   *   · 2C 处 `min(1,·)` 夹住 ⇒ 环线的目标区间（ep 20~100）**整个在夹住之后**，攒 43 与攒 99 同一个分；
   *   · `conv` 只数到 2 次 cost≥2 ⇒ 实测各臂"累计出手"1.2 → 5.5 横跨 4 倍，奖励只体现在前 2 次。
   * 修法不是把权重调大（用户"奖惩不用给太多"的裁定继续成立），而是**换成不会被夹住的分母**。 */
  let HOARD_LEFTOVER = false;   // true ⇒ 惩罚自变量 maxEp → **终局余款**（攒钱奖励那一段不动）
  let CONV_RATIO = false;       // true ⇒ conv 第一改数从"次数/2 封顶" → **已花 ep / 已获得 ep**
  let CONV_OFFENSE = false;     // true ⇒ 上面那个"已花"**只算花在会造成伤害的卡上**（防"龟壳 captured"，见日志 00:41）
  let HOARD_CAP_MULT = 2;       // 饱和点 = C×mult；默认 2 ⇒ 与现状逐位相同

  /* ===== 经济 shaping 的门槛：按 (人数, 模式) 定（v1.5.6，用户裁定）=====
   * 用户回忆的"ep 奖励/惩罚"就是这个 stock 项；此前门槛**写死 4/10**、与人数和模式无关，于是
   * 5 血里 11 ep 就被当囤积。用户给的锚点：
   *   · 3 人局       → 奖励到 **3 ep**、惩罚 **>10 ep**
   *   · 5 人 · 5 血   → 奖励到 **5 ep**、惩罚 **>20 ep**
   * 取：奖励点 T = 3（≤3 人）/ 4（4 人）/ 5（5 人）；惩罚点 C = 10（3 血）/ 20（长程 5 血）。
   * 其余组合落在两端之间且单调 ⇒ 不再出现"5 血里 11 ep 就被罚"的错配。 */
  function economyTargets(n, mode) {
    return { target: (n <= 3 ? 3 : (n >= 5 ? 5 : 4)), cap: (mode === 'long' ? 20 : 10) };
  }
  let ECO_T = null, ECO_C = null;     // 显式覆盖（默认 null ⇒ 走 (n, mode) 推导）
  let DIV_W = 0.06;
  /* ===== v1.6.50（用户 10-10 裁定「B 也可以做」）：**把出厂闸的广度维度折进适应度**（默认关 ⇒ 行为逐字不变）=====
   * 病（§E445/§E446 四轮 47 臂）：训练分数是 21 个脚本对手的**加权平均**，被某个脚本打穿只扣约 5%；
   *   而出厂闸要的是**最坏情况**（G4/G5）、**人席**、**广度**（G）—— 全是训完才筛 ⇒
   *   实测"Hp 涨"的臂**全部**过不了闸、"过线"的臂 Hp 全是负的，**47 臂没有一臂跑赢自己的起点**。
   * 这一维怎么接（与闸**同源**，不是另造一把尺）：
   *   `spUse` 是"自对局里成功非ジ动作"的直方图（`:1866` 起），`mirrorHealth` 的 `keyCount` 与它**同口径**
   *   （`:3168` 的注释自己写着"累计成功非ジ动作，与 mirrorHealth 的 keyCount 同口径"）
   *   ⇒ `spG = exp(spH)` 与闸那条 `G 有效技能数 = tot ? Math.exp(H) : 0`（`:3144` 附近）是同一条量。
   * 形状：**只罚下界、线性**（`FIT_G_W × max(0, FLOOR − spG)`）——
   *   不奖励"比下界更宽"（那是把臂往"什么都用一点"推，本仓已量过"变宽但丢关键卡"这种骗法：
   *   G 4.15→6.55 的同时把唯一能穿反弹的激光眼用到 0 命中）。
   * ⚠️ 覆盖面要说清（别当成"B 全做完了"）：这一项用的是**本装配（multi）自对局**的 G，
   *   覆盖闸的 `G(multi)` 那一条；闸还有 `G(long)`（要 `mirrorHealth(..., 'long')` 或 `breadthProfile(..., 'long')`
   *   那一趟完整自对局，成本高一个数量级）⇒ **G(long) 不在本项里**，要它也折进来是下一步的独立裁定。
   * ⚠️ 默认 `FIT_G_W = 0` ⇒ 逐位不变；开档必须经过下面 `setEconomyReward` 的收口（三处名单齐才送得到）。 */
  let FIT_G_W = 0, FIT_G_FLOOR = 3;
  /* v1.5.124（复核 §28a）：**广度收益项**的权重与阈值（默认关 ⇒ 出厂行为一字不变）。
   * 形状：G 从 `WIDTH_FLOOR` 到 `WIDTH_TARGET` 线性给钱 ⇒ 与 `DIV_W` 那个"归一化熵"不同，**刷不动**。 */
  let WIDTH_W = 0, WIDTH_FLOOR = 3, WIDTH_TARGET = 7;
/* v1.7.90（DS · 10-17）：**按"落地"付的广度**（默认 0 ⇒ 逐位不变）。
 *   病：`WIDTH_W` 量的是 `countVariety`（事件流里**用过**几种），而验收的兑现腿量的是 `effSkillsLand`
 *   （只数**打上血**的真卡名）⇒ 奖励比验收早一步：抬 `WIDTH_W` 必然抬 `G`、必然掉兑现比（10-17 三批实测）。
 *   本项把**同一形状**（`FLOOR → TARGET` 线性、饱和）挂在**落地量**上 ⇒ 奖励与验收对齐。 */
let WIDTH_LAND_W = 0;
/* v1.7.91 自证：这一项到底有没有付过钱（`varietyMaxLanded ≤ FLOOR` ⇒ 永远 0 ⇒ "没效果"是恒零的必然）。 */
const WIDTH_LAND_STAT = { games: 0, max: 0, paid: 0, blk: 0, blkAttr: 0 };
  /* v1.8.39（DS · 10-27 早 · 用户裁「做一下 A」）：**破反弹墙**奖励 `WALL_BREAK_W`（默认 0 ⇒ 逐位不变）。
   * 病（10-27 早四臂）：`FIT_G_W=1.0` 把 F 做成 广 4.15/4.44 + 珍 0.99/0.833 + 珠闭环，但「反弹墙」仍 0.00/局、
   *   「只防御不还手」防席夺冠仍 51% —— 那两行是同一件事：**对不还手/摆架势的桌打不进去**。
   * 而现有 `PIERCE_W` 的形状是 `min(1, pierceHits/2)`，F 自对局里穿透命中 127 次（坦克 126）早已吃满成常数
   *   ⇒ 再加权重没有梯度。本项**只给穿反弹的那三张卡**（`pierce.reflect`：激光剑/狙击枪/电磁炮）的落地付钱，
   *   形状 `0 次 0 分、1 次吃满`（这一族在被动桌上极稀，用 /2 会恒 0）。
   * ⚠ 坦克**不算**：它穿防御、不穿反弹（rules.js 的 pierce 字段）—— 这正是本项与 PIERCE_W 的分工。 */
  let WALL_BREAK_W = 0;
  const WALL_BREAK_STAT = { games: 0, max: 0, paid: 0 };
  /* 11:5x（千问 · 用户「这几个都可以」· PREREG §二十六 条款 4）：**反射**奖励 `REFLECT_W`（默认 0 ⇒ 逐位不变）。
   * 病（§E805 的 `GB2`）：`3fc020` 的不动点只差 `G4`（long 只枪 84%）与珠两行；`BLOCK_W` 抬到 0.40 会连墙/G5/强一起卖
   *   （它同时给 `blocked` 与 `reflect` 付钱 ⇒ 奖励含混，会把包推向"挡起来"）；`BEAD_W` 抬档反而放大蓄能-花珠循环。
   * 本项**只给真反射出去的那一下**付钱：事件侧 `{type:'reflect', to, from, amt, via}`（`js/core/resolve.js` 已有），
   *   计数 `to === 本席` 的伤害量 ⇒ **纯训练侧可数，不动 `js/core/**`**。
   * 形状 `min(1, amt/2)`：与 `beadBonus`/`beadBoomBonus` 同尺度；反射一下 1~3 点，/2 才有梯度（同 WALL_BREAK 的 /4 理由）。 */
  let REFLECT_W = 0;
  const REFLECT_STAT = { games: 0, max: 0, paid: 0 };
  /* v1.8.42（A 案 · §E816）：打到"**本回合正在摆防御的目标**"身上的**落地伤害**单独付钱（默认 0 ⇒ 逐位不变）。
   * 动机（§E816 的否证）：自由混战里"打龟"的收益是**全桌共享**的 ⇒ 单席理性是不打（V5 甚至学成"自己也摆盾"）。
   * 本条把收益改成"**谁打谁拿**"：只数 damage 事件里 source===本席、to===X，且**同一回合** X 的 action ∈ GUARD_FAMILY。
   * 口径：只认 outcome==='ok' 的行动；只认**落地** damage（被挡/被弹都没有 damage 事件 ⇒ 天然排除）。
   * 形状 min(1, amt/2)：与 beadBonus/reflectBonus 同尺度。 */
  let GUARD_HIT_W = 0;
  const GUARD_HIT_STAT = { games: 0, max: 0, paid: 0 };
  /* 12:5x（千问 · PREREG §二十九）：**过期珠**惩罚 `BEAD_WASTE_W`（默认 0 ⇒ 逐位不变）。
   * 病（§E807）：`BEAD_W` 撤回默认能把珠买到线内（87%→23%），代价是 珍 0.38→0.045 —— 它买的是**量**不是**花法**。
   * 本项只惩罚**浪费本身**：事件 `{type:'beadExpire', pid, kind, n}`（js/core/resolve.js:1302 本来就在发），
   * 按事件条数 /4 封顶；**不碰花费侧的奖励** ⇒ 可以不卖密度地压浪费。 */
  let BEAD_WASTE_W = 0;
  const BEAD_WASTE_STAT = { games: 0, max: 0, paid: 0 };
  /* v1.5.126（用户洞察）：**贵卡**（cost≥3 或需珠）出手的奖励权重（默认关）。 */
  let BIGCARD_W = 0;
  /* v1.5.260（用户 GO"做 B+"）：**贵卡预算权重**（默认 0 ⇒ 行为逐字不变）。形状故意用**线性计数**，
   * 因为现役的 `bigcardW` 是 `min(1, bigUses/1)`（1 次即吃满）⇒ 对"已经出 3~8 次"的粒没有梯度（本班 §20 的读数）。 */
  let COSTLY_W = 0;
  /* v1.5.261（DS · §22.1 的剂量优先）：**开火计数** —— 本项在训练里到底非零过几次？
   * 动因：`costlyW` 0/0.05/0.2 三档跑出**逐字节相同**的结果（bestFit 也一致）⇒ 不是"压力不够大"，是**剂量恒 0**。
   * 形状同 `EPIRUS_TRAIN_EPS` 的开火计数（本仓既有规矩）：非零即 +1，随 `economyReward()` 一起回执。 */
  let COSTLY_HITS = 0;
  /* ===== v1.5.187（qoder 按 DS 交接 §2b 的"唯一待做"）：**大雷连带**收益项 `BIGT_CHAIN_W` =====
   * 为什么是这一项（DS 的结论链 + 我的独立复跑，见交接 §2 步 7/8 与 `RESEARCH-LOG-2026-09-23-qoder-night.md`）：
   *   现役产物在长程/多人里**大雷出手 0.000/局、连带 0.00/局**（我复跑：出手 0.00、连带 0.00 ⇒ 复现）；
   *   而把"会挑时机的大雷教师"当一个席位直接量，连带是真的：**multi 0.57/局、long 0.49/局**（DS 读 0.35/0.55，数量级一致、排序相反 ⇒ 场地相关）
   *   ⇒ 机制/时机/payoff 都在，缺的是**选择不给它付钱**。示范（哪怕时机对、量也足）活不过"选择"。
   * 归因入口 = 事件 `type:'bigTChain'` 的 **`from`**（施法者席），**不要用 `damage.reason`**：
   *   它只覆盖"吃到伤害的那半"，且 `voided` 事件**没有 `reason` 字段**（原因在 `by`）—— DS 自己踩过（门 L2 那句"筛错字段⇒把没发生当结论"）。
   * ⚠️ 一条我量出来但**没有擅自改判据**的事：连带事件与"连带作废"**不是一一对应**（实测 84%/86%；
   *   发射端 `if (!qIsDef && qa && qa.key !== MINI_T)` 本来就漏掉防御者与互雷）⇒ 本项付的是"Provoked 出交互"，
   *   约 15% 付在没真作废的那半上。要改成"按作废付"是判据选择，等用户/DS 裁（Q-14）。 */
  let BIGT_CHAIN_W = 0;
  /* ===== P2（qoder-research 0920 · RESEARCH-QUEUE P2 / RESEARCH-LOG §11-附-3）：**形状适应度**权重（默认关）=====
   * 三角跷跷板：{主动清场}↔{按住只枪}↔{防珠线}，教师课程怎么排都只能占两边（段与段互相覆盖）。
   * 这一项不示范动作，而是把"4 席家族压在外部压迫席身上的伤害"这一**后果**直接进 fit。
   * 评分器由宿主注入（`server/shape-scorer.mjs` 复用 `tools/v2v4-lib.mjs` 的 `duelAssembly` ⇒ D107 单一来源不破），
   * evo 只认 `global.__shapeScorer(params) → 0..1`。默认 0 ⇒ **严格不加项**（0*NaN 的教训：关着就一个字节都不碰）。 */
  let S4_W = 0;
  /* v1.5.86（附录 D6）：分母必须是**固定目标**，不能用"当时可负担的技能数" ——
   * 否则"把菜单变穷"就能把 divNorm 刷高（臂 A 实测：DIV_W×5 后产物 G=1.24/1.90，
   * 比默认臂被拒的 2.3~2.8 更低，全被健康门禁拦下、零产物）。
   * 现在固定成 K：只有把直方图铺开到 ~K 种非ジ技能才能拿满。可用 EPIRUS_DIV_K 调。 */
  let DIV_K = 6;
  /* ===== v1.5.93（用户裁定）：把"类间"那一层从 4 个 `cat` 换成**功能角色表** =====
   * 历史（v1.5.92）：`混 = (1−W)·S_flat_norm + W·S_cat_norm`，`S_cat_norm = H(cat 分布)/ln(K_CAT)`。
   * **实测否掉了它**（CHANGELOG v1.5.92 §4/§5）：`W=1` 时类间熵**没升**（0.181 vs 对照 0.194），
   * 2/3 产物塌成纯 attack；`W=0.5` 抬起来的 `S_cat` 只来自**个别 token 行为** ——
   * skill report 显示处理臂与对照臂的**逐卡分布几乎相同**（激光剑 25.0% vs 24.0%、狙击 6.1% vs 6.4%）。
   * 根因：`cat` 只有 4 类，而 `attack` 里混着三种**不同功能**（枪=廉价压制 / 激光剑=穿透反射 / 狙击=穿透防御）
   * ⇒ **几次出手就能把 4 类熵拉满**，它量到的不是能力。
   * ⇒ 换成 `roleOf(k)` 的 **8 个功能角色**，类间熵分母相应变成 `ln(K_ROLE)`。
   * 公式形状不变（只换那一层的分区）：`混 = (1−DIV_ROLE_W)·S_flat_norm + DIV_ROLE_W·S_role_norm`
   *   `S_flat_norm` = 现口径 `spH/ln(DIV_K)`（角色间 + 角色内）；`S_role_norm` = `H(role 分布)/ln(K_ROLE)`。
   * ⇒ `DIV_ROLE_W = 0`（默认）时**逐位等于旧行为** ⇒ 旧产物、旧读数仍可比（"默认不设即不变"的规矩）。
   * 命名：v1.5.92 的 env `EPIRUS_DIV_CATW` **仍可用**（旧名兜底、新名 `EPIRUS_DIV_ROLEW` 优先）。
   * 真源：本函数与 `tools/audit-lib.mjs` 的 `breadthProfile` **共用同一个**（tools 侧调 `T.roleOf`）。 */
  function roleOf(k) {
    /* 推导**只用 `rules.js` 已声明的字段**（`cat` / `pierce.{defense,reflect}` / `dmg.amt`），
     * **不写任何卡名清单** —— 手搓白名单是本仓库踩过三次的坑（D81 钉住"不得枚举卡名"）。
     * ⚠️ 与"按落地伤害加权"（用户 v1.5.91 否掉的）不是一回事：这里用 `dmg.amt` 只做**分类**、
     *    不做**权重**；每个角色内部对卡仍是**对称的熵**，没有给任何一张卡专属梯度。
     * ⚠️ 诚实的局限：`utility` 一个人吞了 11 张（规则没给更细的声明字段）⇒ 这一层对"控制类"仍不敏感；
     *    要再细就得动 `rules.js`（=指纹集，用户裁定"别动规则"）或手搓白名单（更糟）⇒ 到此为止并记录。 */
    if (k === R.SK.JI) return 'ji';
    const c = R.byKey[k];
    if (!c) return 'unknown';
    if (c.cat === 'energy') return 'economy';                 // 蓄能 / 聚能环
    if (c.cat === 'defense') return 'defense';                // 防御/反弹/八卦阵/无极变速/金刚盾/藤甲/原型制御/全息屏障
    const pi = c.pierce || {};
    if (pi.defense && pi.reflect) return 'pierceBoth';        // 狙击枪 / 电磁炮（同时穿防 + 穿反）
    if (pi.reflect) return 'pierceReflect';                   // 激光剑
    if (pi.defense) return 'pierceDefense';                   // 坦克
    if (c.dmg && Number(c.dmg.amt) >= 2) return 'burst';      // 真正的落雷
    if (c.dmg) return 'damage';                               // 枪 / 摄魂指法 / 双枪射手
    return 'utility';                                         // 11 张：地雷/挑衅/净化/镜面反射/天火…
  }
  const K_ROLE = (function () {
    const m = {};
    for (const k in R.byKey) { if (k !== R.SK.JI) m[roleOf(k)] = 1; }
    return Math.max(1, Object.keys(m).length);
  })();
  let DIV_ROLE_W = 0;
/* v1.5.88（用户裁定 甲）：退火强迫多样性的窗口代数（0=关）与破墙硬过滤开关。 */
let DIV_FORCE_GENS = 0;
let WALL_FILTER_ON = false;
let WALL_GAMES = 3;
  /* 单局"攒钱/囤积"分：0→T 线性升到满额 ⇒ T..C 不奖不罚 ⇒ 超过 C 按超出比例罚（2C 满额）。
   * 提成纯函数是为了能**直接单测门槛语义**（np-test D15），不必靠跑一遍训练去看数字。 */
  function economyStock(mEp, n, mode, leftEp) {
    const d = economyTargets(n, mode);
    const T = Math.max(1, ECO_T != null ? ECO_T : d.target);
    const C = Math.max(T, ECO_C != null ? ECO_C : d.cap);
    const M = Math.max(1, HOARD_CAP_MULT);
    /* L2′-①：把**罚分**的自变量从"本局最高"换成"终局余款" ⇒ "攒到 40 花光赢下来"不再和
     * "攥着 40 点被打死"同分。**奖励那一支不动**（`maxEp` 问的是"能不能跨过 T 这个门槛"，与余款无关；
     * 若让它也跟着余款走，就变成"结束时留点钱有奖"，那是反向激励）。 */
    if (HOARD_LEFTOVER && leftEp != null) {
      const bonus = mEp <= T ? STOCK_BONUS * (mEp / T) : STOCK_BONUS;
      return bonus - HOARD_PEN * Math.min(1, Math.max(0, leftEp - C) / (C * (M - 1)));
    }
    if (mEp <= T) return STOCK_BONUS * (mEp / T);
    if (mEp <= C) return STOCK_BONUS;
    return STOCK_BONUS - HOARD_PEN * Math.min(1, (mEp - C) / (C * (M - 1)));   // M=2 ⇒ 与旧式逐位相同
  }
  /* 技能覆盖熵奖励（v1.5.6：**用户要求恢复**；Q3 曾把它移出目标函数）。
   * Q3 的理由仍成立（熵与"见过那个状态"是两回事、光加熵会推向乱打），所以权重**给得很小**（DIV_W），
   * 只当"别把自己塔成一招"的弱先验 —— 与"奖惩不用给太多"的要求一致。 */
  /* v1.5.116 新增五个旋钮（L2′ 去阶梯化 + 攒/花两侧的斜率），全部**默认关闭/默认旧值** ⇒ 不设 env 时
   * 出厂行为逐位不变。三个提案的语义、实测依据与判据见 docs/research/reviews/OPTIMIZATION-ep-cliff.md §5 L2′。
   * ⚠ 这五个 `if (o.X != null)` 必须留在 setter 的**开头 1200 字符内** —— 门禁 D77 是用
   *   `setter.slice(i0, i0+1200).indexOf('o.'+key+' != null')` 查"econ-env 返回的键有没有被认"，
   *   写在后面会被判"未接受"（我第一版就栽在这里，注释把长度顶出了窗口）。
   * 不要再加别名键 —— setter 开头 1200 字符是硬预算，多一个键就挤掉 wallGames。
   * ⚠ 这五个 handler 写成**两条紧凑行**也是门禁逼的：D77 用 `slice(0,1200).indexOf('o.'+key+' != null')`
   *   查"econ-env 返回的键有没有被认"，而文件是 **CRLF** ⇒ 每个换行算 2 个字符，窗口比看起来小得多
   *   （实测：一行一个键时 `wallGames` 落在 1202 ⇒ 红；注释写进函数体里也会把窗口吃掉）。 */
  /* ===== 尾部聚合适应度（qoder 09-26 夜班 §E49 · 默认关 ⇒ 出厂行为逐位不变）=====
   * 病（档案级实测：863 个等价类 × 33 个环境块，见 RESEARCH-LOG-2026-09-26-qoder-night2 §E49）：
   *   `fitAvg` 是"跨环境求平均"，而**平均值看不见地板** —— τ(池内均值, 池外地板) = 0.380，
   *   换成 bottom-3 / mean−1·sd 这类尾部统计量给到 0.749 / 0.675。⇒ 目标函数每换一次人，
   *   几乎没换到"没见过的地形上的下限"，这才是"训了半天气也不会看环境打"的账。
   * 形状：`fit = (1−w)·mean + w·ES_q`，`ES_q` = 逐局 `gFit` 里最差 q 分的均值（预期 shortfall）。
   *   **混而不是替**，是为了保住标度：那条和式里 `base` 是 0~1 量级，纯 ES 会把整项系统性下移
   *   ⇒ 另外十几个 shaping 项的相对权重跟着变形（本项目反复撞到的"动态范围"病）。
   * 代价：零额外对局 —— 只用**已经跑完的那些局**的分布，不加局数、不加代。
   * `evo.js` 不在 `FINGERPRINT_FILES` 里 ⇒ 这根开关**不改引擎指纹**。 */
  let FIT_TAIL_W = 0, FIT_TAIL_Q = 0.25;

  /* ===== v1.5.279（qoder 0928 下午班 §E124）：**整桌同原型** `EPIRUS_OPP_BLOCK`（默认关）=====
   * 病（读代码读出来的，不是猜的）：主评分回路 `oi++` 让一局的 N−1 个对手席填**连续不同**的脚本
   *   ⇒ 训练分布里根本不存在"一局 = 一个环境"这个对象。后果有两层：
   *   ① 任何"跨环境极差/最差环境"的判据在训练里没有对应物；
   *   ② `ES_q`（尾部聚合）的下尾取的是"**哪 4 个脚本恰好撞在一起**"的抽样噪声，而不是最差环境
   *      ⇒ 这是 §E51/§E53 把尾部聚合判负（54 臂）的一个**候选成因**：分母错了，不是聚合错了。
   * 改法：开关打开时**局内不推进** `oi` ⇒ 整桌同一原型；原型仍按 `(gen*3+g)` 跨局轮换，
   *   所以**覆盖面、轮换节奏、common random numbers（同代同对手批）一字不动**，只改"一桌的纯度"。
   * 边界（三条，都是故意的）：
   *   ① 只作用于**训练评分**的两条路（主池 + 风格切片）；`evalN` 是**量具**，不受本开关影响
   *      （否则产品口径会跟着训练配方一起变 —— 那是 §E87 那族"口径决定结论"的事故）。
   *   ② `policy.js` 在规则指纹名单里（`rules-fingerprint.mjs:31`），它的"槽位每决策打乱"**一字未动**
   *      ⇒ 本开关不试图给网络喂"对手是谁"，只让**整桌行为混合**这个置换不变的量变得有预测力。
   *   ③ 默认关 ⇒ `oppSeatIndex(...,block=false)` 与旧公式 `((gen*3+g)%len + k)%len` 逐位同，由门 **D187** 钉。 */
  let OPP_BLOCK = false;
  const OPP_BLOCK_STAT = { fitGames: 0, blockedGames: 0, styleGames: 0, styleBlocked: 0 };
  /* 纯函数：第 k 个对手席在该用池子的第几条。关 ⇒ 与旧代码逐字同；开 ⇒ 局内恒等（整桌同原型）。 */
  function oppSeatIndex(gen, g, k, oppsLen, block) {
    return (gen * 3 + g + (block ? 0 : k)) % oppsLen;
  }
  function setOppTable(o) {
    if (!o) return oppTable();
    if (o.reset) { OPP_BLOCK = false; OPP_BLOCK_STAT.fitGames = 0; OPP_BLOCK_STAT.blockedGames = 0; OPP_BLOCK_STAT.styleGames = 0; OPP_BLOCK_STAT.styleBlocked = 0; }
    if (o.block != null) OPP_BLOCK = !!o.block;
    return oppTable();
  }
  function oppTable() {
    return { block: OPP_BLOCK, fitGames: OPP_BLOCK_STAT.fitGames, blockedGames: OPP_BLOCK_STAT.blockedGames,
      styleGames: OPP_BLOCK_STAT.styleGames, styleBlocked: OPP_BLOCK_STAT.styleBlocked };
  }
  /* v1.5.265（qoder §E65b）：**出厂值快照**，给 `reset` 用。
   * 动因（09-28 实测，名单驱动的全键审计）：`setEconomyReward({reset:true})` 的名单是**手写**的，
   * 于是 `divW/divK/divRoleW(=divCatW)/divForceGens/costlyW` 五个键**从来没被抹掉过** ⇒
   * 同一进程里"下达哨兵 → reset"之后，后续所有 `scoreMemberN` 都活在脏值世界里
   * （与本文件 :1228 那条 `wallFilter` 既存泄漏同形，也是 D77 反复补哨兵却补不全的根因）。
   * 这里刻意**不抄字面量**：第一次非 reset 的下达之前抓一次出厂值 ⇒ 加新键不需要再记得改 reset 名单，
   * 名单驱动的检查由门钉（D175：reset 后逐键必须等于抓到的出厂值）。 */
  let ECON_DEFAULTS = null;
  function setEconomyReward(o) {
    o = o || {};
    if (!ECON_DEFAULTS && !o.reset) {
      /* v1.5.299（DS）：**这份快照是字面量列表**（注释里说"不抄字面量"其实不成立）⇒ 加新键必须同时补这里，
       * 否则 `setEconomyReward({reset:true})` 抹不掉它 —— 我的 `fitCal` 就是这么被 D175 抓到的（门是对的）。 */
      ECON_DEFAULTS = { divW: DIV_W, divK: DIV_K, divRoleW: DIV_ROLE_W, divForceGens: DIV_FORCE_GENS, costlyW: COSTLY_W, fitCal: FIT_CAL_EXCESS, fitGW: FIT_G_W, fitGF: FIT_G_FLOOR, voidW: VOID_W, voidIdealW: VOID_IDEAL_W, beadSeed: BEAD_SEED, beadSeedKind: BEAD_SEED_KIND, subBeadKind: SUB_BEAD_KIND, beadBoomW: BEAD_BOOM_W };
    }
    /* v1.8.29（用户裁定 10-23「失效技能应该都要给奖励」）：`voidW` / `voidIdealW` 走 econ-env 单一来源
     *   （不设 ⇒ null ⇒ 两个 W 原样 0 ⇒ 严格不加项、逐位不变）。
     * ⚠ 放在函数**开头**不是排版洁癖：接线检查按前 1200 字符扫 `if (o.<键> != null)`（:3094 记着实测踩过的坑）。 */
    if (o.voidW != null) setVoidReward(o.voidW);
    if (o.voidIdealW != null) setVoidIdealReward(o.voidIdealW);
    /* qoder-research 0920（RESEARCH-LOG §5b）：环奖励权重接进 econ-env 单一来源（默认不设 ⇒ RING_W 原样 0.10）。
     * setRingReward 自带 `isFinite && >=0` 校验；调用发生在模块求值之后 ⇒ 无 TDZ 问题（RING_W 声明在 :1955）。 */
    if (o.ringW != null) setRingReward(o.ringW);
    /* v1.5.141（DS 研究）：**珠奖励标度**走同一条 econ-env 单一来源（默认不设 ⇒ BEAD_W 原样 0.05）。
     * setBeadReward 自带 `isFinite && >=0` 校验（同 setRingReward）；用途见 RESEARCH-LOG-2026-09-21-ds.md §7。 */
    if (o.beadW != null) setBeadReward(o.beadW);
    /* P2（qoder-research 0920）：形状适应度权重走 econ-env 单一来源（默认不设 ⇒ 0 ⇒ 严格不加项）。 */
    if (o.s4W != null) S4_W = Math.max(0, Number(o.s4W) || 0);
    /* 尾部聚合（09-26 夜班 §E49）：非数值就当没设，不许 clamp 成 0 再谎称"开过了"。 */
    if (o.fitTailW != null && isFinite(Number(o.fitTailW))) FIT_TAIL_W = Math.min(1, Math.max(0, Number(o.fitTailW)));
    if (o.fitTailQ != null && isFinite(Number(o.fitTailQ))) FIT_TAIL_Q = Math.min(1, Math.max(0.05, Number(o.fitTailQ)));
    if (o.divRoleW != null) DIV_ROLE_W = Number(o.divRoleW) || 0;
    else if (o.divCatW != null) DIV_ROLE_W = Number(o.divCatW) || 0;
    if (o.divForceGens != null) DIV_FORCE_GENS = Math.max(0, Number(o.divForceGens));
    if (o.bigcardW != null) BIGCARD_W = Math.max(0, Number(o.bigcardW)); if (o.widthLandW != null) WIDTH_LAND_W = Math.max(0, Number(o.widthLandW) || 0); if (o.wallBreakW != null) WALL_BREAK_W = Math.max(0, Number(o.wallBreakW) || 0); if (o.reflectW != null) REFLECT_W = Math.max(0, Number(o.reflectW) || 0); if (o.guardHitW != null) GUARD_HIT_W = Math.max(0, Number(o.guardHitW) || 0); if (o.beadWasteW != null) BEAD_WASTE_W = Math.max(0, Number(o.beadWasteW) || 0); if (o.costlyW != null) COSTLY_W = Math.max(0, Number(o.costlyW)); if (o.bigtChainW != null) BIGT_CHAIN_W = Math.max(0, Number(o.bigtChainW)); if (o.widthW != null) WIDTH_W = Math.max(0, Number(o.widthW)); if (o.blockW != null) BLOCK_W = Math.max(0, Number(o.blockW));
    if (o.hoardOnLeftover != null) HOARD_LEFTOVER = !!o.hoardOnLeftover; if (o.convRatio != null) CONV_RATIO = !!o.convRatio; if (o.convOffense != null) CONV_OFFENSE = !!o.convOffense;
    if (o.fitCal != null) FIT_CAL_EXCESS = !!(o.fitCal && String(o.fitCal) !== '0' && o.fitCal !== 0);
    /* v1.6.50（用户裁定 B）：把闸的广度折进适应度。两个键一起收口（只给 W 不给下界 ⇒ 用默认下界 3，与闸同线）。 */
    if (o.fitGW != null) FIT_G_W = Math.max(0, Number(o.fitGW) || 0);
    if (o.fitGF != null) FIT_G_FLOOR = Math.max(0, Number(o.fitGF) || 0);
    /* v1.8.36（夜班 #58）：开局珠塑形 `BEAD_SEED` 走 econ-env 单一来源（不设 ⇒ null ⇒ 原样 0 ⇒ 逐位不变）。
     *   ⚑ v1.8.37 更正一笔：本注释与 `server/econ-env.mjs` 的头注原先都把这键写成"**爆珠**塑形"——
     *   钩子给的一直是**电珠**（v1.5.143 原义，为电磁炮）；爆珠档要到下面这行 `beadSeedKind` 才存在。
     *   为什么现在才接：这个键自 v1.5.143 就在引擎里（`setBeadSeed`/`beadSeedOn`），但**从没进过任何投递名单**
     *   ⇒ 臂上设 `EPIRUS_BEAD_SEED` 会撞黑键闸（train-3p `exit 6`），绕过去手设则只有服务进程那份生效 ——
     *   正是本仓附录 D 臂 K 那种"A/B 其实跑成 A/A"的形状。放在开头同样不是排版洁癖（上面那条 1200 字符纪律）。 */
    if (o.beadSeed != null) setBeadSeed(Number(o.beadSeed));
    /* v1.8.37（10-25 ZCode · 激光眼移植批 §二十一）：`BEAD_SEED` 的**珠种档**（'elec' 缺省 = v1.5.143 原义 ⇒ 逐字不变；
     * 'boom' = 同一钩子改发爆珠）。动机：§E744/§E759 已钉死"激光眼缺的是分母与时机"，而 §E734 否证的
     *   BEAD_SEED=0.5 那根给的是**电珠**——爆珠档从未被试过。电磁炮先例（v1.5.143 电珠塑形 → v1.5.144 首个成牌）
     *   的镜像移植。走同一单一来源 ⇒ 16 个 worker 同步生效。 */
    if (o.beadSeedKind != null) setBeadSeedKind(o.beadSeedKind);
    /* v1.8.37 夜班续（千问 §E763）：**补贴局的珠种**与**按珠种拆开的珠奖励**。
     *   `subBeadKind` 是枚举键（与 `beadSeedKind` 同一族 ⇒ 非法值由 setter 响亮拒）；
     *   `beadBoomW` 缺省 0 ⇒ 不开臂时 fit 逐字不变（这条是本仓新杠杆的出厂不变量，D175 探针往返盯着它）。 */
    if (o.subBeadKind != null) setSubBeadKind(o.subBeadKind);
    if (o.beadBoomW != null) setBeadBoomW(o.beadBoomW);
    if (o.hoardCapMult != null) HOARD_CAP_MULT = Number(o.hoardCapMult) || 1; if (o.stockBonus != null) STOCK_BONUS = Number(o.stockBonus) || 0;
    if (o.target != null) ECO_T = Math.max(1, Number(o.target));
    if (o.cap != null) ECO_C = Math.max(1, Number(o.cap));
    if (o.divW != null) DIV_W = Math.max(0, Number(o.divW));
    if (o.divK != null) DIV_K = Math.max(2, Number(o.divK));
    if (o.wallFilter != null) WALL_FILTER_ON = !!o.wallFilter;
    if (o.wallGames != null) WALL_GAMES = Math.max(1, Number(o.wallGames));
    if (o.reset) {
      ECO_T = null; ECO_C = null;
      HOARD_LEFTOVER = false; CONV_RATIO = false; CONV_OFFENSE = false; HOARD_CAP_MULT = 2; STOCK_BONUS = 0.05; BLOCK_W = 0; WIDTH_W = 0; WIDTH_LAND_W = 0; BIGCARD_W = 0; BIGT_CHAIN_W = 0; WALL_BREAK_W = 0;   /* v1.8.42（DS · 10-27 晚）：WIDTH_LAND_W 是 train-selftest ① 抓出来的漏网（reset 后 0.5 泄漏） */ REFLECT_W = 0; GUARD_HIT_W = 0; BEAD_WASTE_W = 0;
      /* qoder-research 0920：D77 的运行时往返会喂**每个键**的哨兵再 reset —— ringW/s4W 是后加的键，
       * 漏在这里会把 0.5 的哨兵泄漏给后续门（s4W 泄漏 = 后续 scoreMemberN 直接抛错）。
       * ⚠️ D109 第一次跑红还顺带抓出一个**既存泄漏**：`wallFilter` 的哨兵 true 从没被 reset 抹掉
       *   （D77 的 finally 只补了 divRoleW）⇒ 后续任何 scoreMemberN 都活在"破墙硬过滤开着"的假世界里。
       *   一并收进 reset。 */
      S4_W = 0; setRingReward(0.10); setBeadReward(0.05); WALL_FILTER_ON = false; WALL_GAMES = 3;
      FIT_TAIL_W = 0; FIT_TAIL_Q = 0.25;   // 09-26 夜班 §E49：D77 往返的哨兵必须在这里抹掉，否则 0.5 泄漏给后续门
      setBeadSeedKind('elec');             // v1.8.37：D77 会喂 'boom' 哨兵，reset 必须能抹回电珠档
      setSubBeadKind('elec');              // v1.8.37 夜班续（§E763）：同上，补贴局的珠种也要抹得回
      BEAD_BOOM_W = 0;                     // v1.8.37 夜班续：新杠杆的哨兵 0.5 不许泄漏给后续门
      /* v1.5.265（§E65b）：这五个键以前**不在** reset 名单里（手写名单漏的）。走出厂值快照，不抄字面量。 */
      if (ECON_DEFAULTS) {
        DIV_W = ECON_DEFAULTS.divW; DIV_K = ECON_DEFAULTS.divK; DIV_ROLE_W = ECON_DEFAULTS.divRoleW;
        DIV_FORCE_GENS = ECON_DEFAULTS.divForceGens; COSTLY_W = ECON_DEFAULTS.costlyW;
        if (ECON_DEFAULTS.fitCal != null) FIT_CAL_EXCESS = !!ECON_DEFAULTS.fitCal;   // v1.5.299：新键也要能复位
        if (ECON_DEFAULTS.fitGW != null) FIT_G_W = ECON_DEFAULTS.fitGW;              // v1.6.50：B 的两个键同样要能复位
        /* v1.8.29：D77 的运行时往返会喂**每个键**的哨兵再 reset ⇒ 新键漏在这里 = 哨兵泄漏给后续门
         *   （`s4W` 那次泄漏的直接后果是"后续任何 scoreMemberN 都活在假世界里"）。走快照，不抄字面量。 */
        if (ECON_DEFAULTS.voidW != null) VOID_W = ECON_DEFAULTS.voidW;
        if (ECON_DEFAULTS.voidIdealW != null) VOID_IDEAL_W = ECON_DEFAULTS.voidIdealW;
        if (ECON_DEFAULTS.fitGF != null) FIT_G_FLOOR = ECON_DEFAULTS.fitGF;
        if (ECON_DEFAULTS.beadSeed != null) setBeadSeed(ECON_DEFAULTS.beadSeed);   // v1.8.36：D77 的哨兵喂完 0.5 要能抹回去
        if (ECON_DEFAULTS.beadSeedKind != null) setBeadSeedKind(ECON_DEFAULTS.beadSeedKind);   // v1.8.37：同上
        if (ECON_DEFAULTS.subBeadKind != null) setSubBeadKind(ECON_DEFAULTS.subBeadKind);       // v1.8.37 夜班续：走快照
        if (ECON_DEFAULTS.beadBoomW != null) BEAD_BOOM_W = ECON_DEFAULTS.beadBoomW;             // v1.8.37 夜班续：同上
      }
    }
    return economyReward();
  }
  function economyReward() {
    return { targetOverride: ECO_T, capOverride: ECO_C, divW: DIV_W, divK: DIV_K, divRoleW: DIV_ROLE_W, divCatW: DIV_ROLE_W, K_role: K_ROLE,
      fitGW: FIT_G_W, fitGF: FIT_G_FLOOR, beadSeed: BEAD_SEED, beadSeedKind: BEAD_SEED_KIND,
      subBeadKind: SUB_BEAD_KIND,   // v1.8.37 夜班续：D77 往返要求 ECON_REWARD_KEYS 每个键都"设得进、读得回"
      beadBoomW: BEAD_BOOM_W,       // 同上（按珠种拆开的那半笔珠奖励）
      divForceGens: DIV_FORCE_GENS, wallFilter: WALL_FILTER_ON,
      stockBonus: STOCK_BONUS, hoardPen: HOARD_PEN,
      hoardOnLeftover: HOARD_LEFTOVER, convRatio: CONV_RATIO, convOffense: CONV_OFFENSE, hoardCapMult: HOARD_CAP_MULT,
      blockW: BLOCK_W, widthW: WIDTH_W, widthLandW: WIDTH_LAND_W, widthLandStat: { games: WIDTH_LAND_STAT.games, max: WIDTH_LAND_STAT.max, paid: WIDTH_LAND_STAT.paid, blk: WIDTH_LAND_STAT.blk, blkAttr: WIDTH_LAND_STAT.blkAttr }, wallBreakW: WALL_BREAK_W, wallBreakStat: { games: WALL_BREAK_STAT.games, max: WALL_BREAK_STAT.max, paid: WALL_BREAK_STAT.paid }, reflectW: REFLECT_W, reflectStat: { games: REFLECT_STAT.games, max: REFLECT_STAT.max, paid: REFLECT_STAT.paid }, guardHitW: GUARD_HIT_W, guardHitStat: { games: GUARD_HIT_STAT.games, max: GUARD_HIT_STAT.max, paid: GUARD_HIT_STAT.paid }, beadWasteW: BEAD_WASTE_W, beadWasteStat: { games: BEAD_WASTE_STAT.games, max: BEAD_WASTE_STAT.max, paid: BEAD_WASTE_STAT.paid }, bigcardW: BIGCARD_W, costlyW: COSTLY_W, costlyHits: COSTLY_HITS, fitCal: FIT_CAL_EXCESS, bigtChainW: BIGT_CHAIN_W, wallGames: WALL_GAMES, ringW: RING_W, s4W: S4_W,
      fitTailW: FIT_TAIL_W, fitTailQ: FIT_TAIL_Q,   // 09-26 §E49：ECON_REWARD_KEYS 里每个键都要"设得进、读得回"（D77 往返）
      /* v1.5.141（DS）：`beadW` 必须能从读回接口看到 —— D77 的运行时往返要求 `ECON_REWARD_KEYS` 的
       * 每个键都"设得进、读得回"（np-test.mjs:3289 的 `f in back`）；只接 setter 不接读回 ⇒ 门红。 */
      beadW: BEAD_W,
      /* v1.8.29：同一条 D77 契约 —— `ECON_REWARD_KEYS` 里每个键都要"设得进、读得回"。 */
      voidW: VOID_W, voidIdealW: VOID_IDEAL_W,
      at3: economyTargets(3, 'multi'), at5long: economyTargets(5, 'long') };
  }

  /* ===== 反摆烂：哨声惩罚 + 出手权重（v1.5.8）=====
   * 为什么必须加：多人局的胜利条件允许"**熬到回合上限比血量**"，而考卷（1st 率）**看不出**
   * "熬"与"打"的区别。实测（`tools/champ-audit.mjs`，5 座全是同一个冠军的自对局）：
   *   long-33（v1.5.7 我曾换上线）→ 考卷 **45.3%**，但自对局 **20/20 局零伤害、60 回合全平局**；
   *   long-34                        → 考卷 32.9%，自对局 **19.7 伤害/局**（全是 cost≥3 重击）、28.7 回合。
   * ⇒ 光看考卷会把"摆烂"当成强度（千问体检 §5-4 早就点过："能量出'赢'还是'熬'"）。
   * 这里给"熬出来的胜利"打折：终局时**还有 ≥2 人活着**（没人被淘汰）⇒ 判为哨声局。
   * 反证（np-test D18）：把 rankCredit 里的哨声判断删掉，D18 立刻红。 */
  let WHISTLE_PEN = 0;      // 0 = 关（默认）；数字 = 显式覆盖（v1.5.12 起不再有"长程自动 0.5"）
  /* v1.5.299（DS · 用户裁定「fit 可以按你的意思做」）：**胜率项的口径对齐**（默认关 · `EPIRUS_FIT_CAL=1`）。
   * 病：`rankCredit` 的绝对刻度（1 名 1.0 / 2 名 0.3）**与桌子人数无关**，而随机基线 = rank/N
   *   （3 人桌 1 名 33%、5 人桌 20%）⇒ 同一个 1.0 在不同桌上含义不同；产品考卷是 5P，
   *   而本仓已实测「N=3 排序外推到产品口径会翻号」（§E137 那批 −1.9pt）。
   * 对齐形状：改成**相对随机基线的超额** `(奖励 − rank/N) / (1 − rank/N)`（clamp ≥0）⇒
   *   ① N 无关（5 人桌 1 名回到 1.0）；② 2 名在两种桌上都低于基线 ⇒ 归 0（"只有赢才算"）。
   * 默认关 ⇒ 与旧行为**逐位相同**（v1.5.300 起由**门 D201** 钉：默认值 / 公式形状 / 复位 / 调用点真传人数）。
   * ⚠ 这里原本写"门 D191 钉 A/A"——**引用落空**（D191 是 kept/ 别名检测、D200 是 5P 环境量具的门，
   *   两条都不是这个旋钮的凭据；见 np-test D201 的头注与 CHANGELOG v1.5.300）。 */
  let FIT_CAL_EXCESS = false;
  let DEAL_W = 0.01;        // 出手奖励权重（原值写死 0.01）
  /* v1.5.14（用户裁定 **选项 A**：训练侧加"先手/首次伤害"激励）：**默认关**，靠
   * `EPIRUS_FIGHT_DEAL` / `EPIRUS_FIGHT_FIRST` 打开 —— 沿用 v1.5.12 的教训：不猜默认值，
   * 先用对照臂证明它有效，再由用户决定是否改成默认。
   * 动机（REVIEW §12）：多人局里 `防御/反弹/八卦阵` **费用都是 0** ⇒ 摆架势是免费的免伤，
   * 而进攻要花 1~2 ep 还把自己变成靶子 ⇒ 学出"互戒均衡"（人类不出手时 AI 架势率 75~96%）。
   * 适应度现有两项都不足以破局：`deal` 只有 0.01；`proact` 是**相对全场均值**的，
   * 全场 0 伤害时它恒等于 0 ⇒ 对称局面下没有梯度去当先出手的人。
   * 关键区别：**首伤奖励是"区分名次"的项**（每局只有一个席位拿到），而统一加在所有人身上的项
   * （如哨声惩罚）在对称局面里不改变排序 ⇒ 这是它可能有效的原因。 */
  let FIRST_W = 0;          // 0 = 关；>0 = 本局第一个造成伤害的席位拿这么多
  /* v1.5.12 回滚 v1.5.11 的"长程默认 0.5"——**实测证明它在长程是空操作**。
   * 证据（`lngC` = 长程·自动 0.5 vs `lngD` = 长程·显式 0，其余全同，6 seed；见 REVIEW §11.8）：
   * 两份产物**逐字节相同**，而 meta 分别正确记着 `whistlePen:0.5/override:null` 与 `0/override:0`
   * ⇒ 接线没问题，是**这条规则在长程从不触发**：终局收缩 + 5 血 ⇒ 长程局几乎总以"有人被淘汰"结束，
   * `aliveEnd >= 2` 的哨兵局 ≈ 0%。
   * 惩罚真正有用的是**多人 3 血**（上限 60、收缩不触发 ⇒ 哨兵局常见，v1.5.9 实测有效）——
   * 那个场景用 `EPIRUS_FIGHT_WHISTLE` 显式开即可，不要用"按模式猜"的默认值。 */
  function whistlePenNow() { return WHISTLE_PEN; }
  function rankCredit(rank, aliveEnd, nSeats) {
    let base = rank === 1 ? 1.0 : (rank === 2 ? 0.3 : 0.0);
    if (FIT_CAL_EXCESS) {
      const NS = Number(nSeats) > 1 ? Number(nSeats) : 3;   // 缺省按现役 3 人桌（只在开了对齐时才用到）
      const bl = Math.min(0.99, rank / NS);                  // 随机基线：rank/N
      base = Math.max(0, (base - bl) / (1 - bl));
    }
    const pen = whistlePenNow();
    return (pen > 0 && aliveEnd >= 2) ? base * (1 - pen) : base;
  }
  function setFightReward(o) {
    o = o || {};
    if (o.whistlePen != null) WHISTLE_PEN = Math.max(0, Math.min(1, Number(o.whistlePen)));
    if (o.dealW != null) DEAL_W = Math.max(0, Number(o.dealW));
    if (o.firstW != null) FIRST_W = Math.max(0, Number(o.firstW));
    if (o.reset) { WHISTLE_PEN = 0; DEAL_W = 0.01; FIRST_W = 0; }
    return fightReward();
  }
  function fightReward() { return { whistlePen: whistlePenNow(), override: WHISTLE_PEN, dealW: DEAL_W, firstW: FIRST_W }; }
  /* v1.5.14：本局**第一个造成伤害**的席位（= 先手方）。只看带 source 的 damage 事件 ——
   * 终局收缩的伤害是 source:null（场地效果），不算任何人的先手。抽成纯函数是为了能钉语义（np-test D21）。 */
  function firstBloodSeat(evs) {
    if (!evs) return null;
    for (let i = 0; i < evs.length; i++) {
      const e = evs[i];
      if (e.type === 'damage' && e.source != null) return e.source;
    }
    return null;
  }

  /* ===== 技能覆盖熵（v1.5.8：**只统计非ジ动作**，用户裁定）=====
   * 为什么要排除ジ：熵是按**动作分布**算的，而"攒钱/等待"就是反复出ジ ⇒ 攒钱会把熵压到极低
   * ⇒ 熵奖励其实在**惩罚攒钱**，与 ep 攒钱奖励（stock 项）互相打架。
   * 实测（v1.5.7 的奖励 A/B，同一引擎、只差奖励设置）把熵奖励从 0 提到 0.06：
   *   **最高 ep 44.8→12.8、ep≥3 决策占比 34.3%→5.8%**（出手种类 13.7→14.8 确实变广）。
   * ジ 是"这一回合不做事"的基线动作，把它算进"广度"是在量错东西。
   * 归一化分母也要**排除ジ**（否则分母里那个ジ会让熵永远到不了 1）。
   * 反证（np-test D17）：把 `k === R.SK.JI` 的排除去掉，D17 立刻红。 */
  function coverageEntropy(use, affKeys, capDiv) {
    let tot = 0, ji = 0, distinct = 0;
    for (const k in use) {
      if (k === R.SK.JI) { ji += use[k]; continue; }
      if (use[k] > 0) distinct++;
      tot += use[k];
    }
    if (tot <= 0) return { divNorm: 0, H: 0, nonJi: 0, ji: ji, distinct: 0, effSkills: 0, hill05: 0 };
    let H = 0;
    for (const k in use) {
      if (k === R.SK.JI) continue;
      const pr = use[k] / tot;
      H -= pr * Math.log(pr);
    }
    /* ===== v1.5.147（xfer44 反例：0.005 的 divNorm 差杀死了"种类 5 vs 种类 2"）=====
     * 加 Hill 数家族两列（D_q = (Σp^q)^(1/(1-q))，q=1 极限 = exp(H)）：
     *  · `effSkills = exp(H)` —— 与门禁/体检的 `mirrorHealth.effSkills` **同一量纲**（择优第一次和上线判据同语言）；
     *  · `hill05 = (Σ√p)²` —— q=0.5 的 Rényi 有效技能数：长尾按 √p 计权，"真用出第五张卡"比"两张卡打花"贵
     *    （用户/gemini 裁定：游戏的技能分布本就不该均匀，平衡熵奖励的是时序噪声不是广度）。
     * ⚠️ q<1 对稀有卡敏感 ⇒ 60 局样本下偶发一手会抬 hill05 —— 这正是"广度"想要的方向，
     *    但排序主键仍是它、divNorm 退居末级（历史臂 div 里没有这两列 ⇒ 取 0，行为退旧口径，可比性保）。 */
    let sq = 0;
    for (const k in use) {
      if (k === R.SK.JI) continue;
      if (use[k] > 0) sq += Math.sqrt(use[k] / tot);
    }
    let div;
    if (capDiv != null) div = Math.max(2, capDiv);
    else { let aff = 0; for (const k in (affKeys || {})) if (k !== R.SK.JI) aff++; div = Math.max(2, aff); }
    return { divNorm: H / Math.log(div), H: H, nonJi: tot, ji: ji, distinct: distinct,
             effSkills: Math.exp(H), hill05: sq * sq };
  }

  /* N 人适应度（N19）：名次基础分（1/0.6/0.2）+ 轻量 shaped 项 */
  /* 从一局的事件流里数"我打断开环者"的次数（**纯函数**，便于守门单测）：
   *   ① 对手在开环的判据 = 他有一次 `ep` 事件 `delta ≥ 2`（环第 2 次起 +2/+3；ジ 只 +1）；
   *   ② 记一次打断 = 同一局里**我**（source===seat）对他造成了伤害，
   *      或我这一局用了小雷（miniT）而他被作废（`voided`）。
   * 只报事实、不判断"该不该打" —— 那是网络要学的。 */
  function countRingBreaks(events, seat) {
    let breaks = 0;
    let ringers = {};
    let miniT = 0, anyRinger = false;
    const pending = [];
    for (const e of events) {
      if (e.type === 'action' && e.pid === seat && e.outcome === 'ok' && e.key === R.SK.MINI_T) miniT++;
      /* v1.5.37（复核 §5-3/反例 E）：判据改成**"该座真的施放了聚能环"这条动作事件** ——
       * 旧判据 `ep delta >= 2` 有两处错：① 漏掉环的**第一次**（delta 是 1 然后 2）⇒ 越早打断越没分；
       * ② 会把"被避雷针回馈 +4 ジ"这种非环的大额 ep 当开环。动作事件判据同时治好这两处。 */
      if (e.type === 'action' && e.pid !== seat && e.outcome === 'ok' && e.key === R.SK.RING) { ringers[e.pid] = true; anyRinger = true; }
      if (e.type === 'damage' && e.source === seat && ringers[e.to]) { breaks++; ringers[e.to] = false; }
      /* v1.5.37（复核 §5-1）：作废必须**由我造成**（byPid === 我）才算我打断的 ——
       * 此前只要求"我出过小雷"，于是"别人作废、我恰好放过小雷"会与我真打断**同分**（反例 A vs B）。 */
      if (e.type === 'voided' && ringers[e.pid] && e.byPid === seat) pending.push(e.pid);
    }
    /* v1.5.29（用户实测逼出来的关键修正）：**先把信号做密**。
     * 实测：所有历史冠军的小雷次数都是 **0** ⇒ "小雷作废开环者"这条奖励**永远触发不了**，
     * 而"不能 bootstrap 一个从未发生的动作"是奖励设计的经典死穴（环墙 85.5% 其实靠熬赢，不是打断）。
     * 于是分层给分：
     *   ① 有人开环（对手 ep 单次 ≥2）时我出了小雷 —— **0.5/次**（这个动作本身先被奖出来）；
     *   ② 小雷真的让开环者被作废 —— 每次 **+1**；
     *   ③ 我打中开环者 —— 每次 **+1**（原有）。
     * 上层小项（环惩罚/破墙/惩罚被动）仍各自 min(1, x/2) 封顶，不会让任何一项压倒胜负。 */
    /* v1.5.30（用户选 A）：密集分**每局至多一次**（原来是每次 +0.5）。
     * 起因（实测）：每次都给 ⇒ **刷小雷成了得分最高的策略**，而刷小雷的个体过不了健康门槛
     * ⇒ 每一次提升都被拒 ⇒ 6 个 seed 全部冻结在热启动种子上（v7both 臂零提升）。
     * 现在只保留"让这个动作被发现"的最小推力，不给刷分空间。 */
    if (anyRinger && miniT > 0) breaks += 0.5;
    /* 归因：作废加分必须由**我出小雷**引起（否则"别人作废了开环者"会记到我头上）。 */
    if (miniT > 0) breaks += pending.length;
    return breaks;
  }
  function scoreMemberN(params, opps, games, n, gen, idx, hGeneIn) {
    let fit = 0, first = 0, second = 0, dealt = 0, rounds = 0, played = 0, ringBreaks = 0, pressRounds = 0, pierceHits = 0, beadSpent = 0, beadBoomSpent = 0, threatHits = 0, laserHits = 0, clears = 0, blocks = 0, varietyMax = 0, varietyMaxLanded = 0, bigUses = 0, chains = 0, bigTCasts = 0, wallBreakHits = 0, wallBreakDmg = 0, reflectAmt = 0, guardHitAmt = 0, beadExpired = 0;
    let maxEpSum = 0, heavySum = 0, holdSum = 0, deepSum = 0, econGames = 0, epGain = 0, ringCasts = 0, stockSum = 0;
    /* v1.8.29：失效成功 / 理想情况（激光眼破防且同回合别人打中）——两个计数一起攒，见 voidScan。 */
    let voidWins = 0, voidIdeal = 0;
    /* v1.6.50（用户裁定 B）：广度惩罚项**不是每局项** —— 它要的是"这一员的动作分布有多宽"，
     * 而 `spUse` 要打完全部局才攒齐 ⇒ 只能在跨局聚合那一层加（`fitAgg`）。
     * ⚠️ 我第一版把它塞进每局的 `gFit` 求和里，当场被 D175 的探针抓住：
     *   `ReferenceError: Cannot access 'gBonus' before initialization`（TDZ）—— 门是对的，我是错的。 */
    let gBonus = 0;
    let leftEpSum = 0, spentEpSum = 0, gainEpSum = 0;   // v1.5.116 L2′：余款/已花/已获得（每局）
    let imitSum = 0, imitGames = 0;
    /* ===== v1.5.272（qoder 09-28 §E83）：**行为计数剂的门槛从"各自的 W"换成"这一族有没有任何 W 被下达"** =====
     * 病（`bigUses` 那次的同族，见 :1649 的说明）：下面 8 个计数原本各自包在 `if (X_W > 0)` 里，
     * 而它们的剂量**从不单独返回** ⇒ 只要某个 W 为 0，那个计数就恒 0 ⇒
     * "这个杠杆没作用"与"这个个体真的没做出该行为"在臂上长得一模一样，**假零结果无法否证**。
     * 修法不是"永远算"（默认臂全都白扫一遍事件、纯付算力），而是：
     *   **这一族里只要有一个 W 非零，就把 8 个计数全部算出来** ⇒ 被下达的那根能看到剂量，
     *   没被下达的兄弟也能当**对照组**读；全 0 时没有任何杠杆需要否证 ⇒ 直接不算、逐位不变、零成本。
     * 收益项（`pressBonus` 等，:1553~:1582）**仍各自按自己的 W 门控** ⇒ `fit` 一字不变。 */
    const DOSE_ON = PRESS_W > 0 || PIERCE_W > 0 || BEAD_W > 0 || BEAD_BOOM_W > 0 || TGT_W > 0 || CLEAR_W > 0 ||
      BLOCK_W > 0 || WIDTH_W > 0 || WIDTH_LAND_W > 0 || WALL_BREAK_W > 0 || REFLECT_W > 0 || GUARD_HIT_W > 0 || BEAD_WASTE_W > 0 || BIGCARD_W > 0 || COSTLY_W > 0 || BIGT_CHAIN_W > 0 || ringWeightAt(gen) > 0 ||
      /* v1.8.29：失效定价的两个 W 也必须进这一族 —— 漏了它，`gen≤125`（`ringWeightAt` 为 0）且其余杠杆全关时
       * 计数器根本不算 ⇒ 臂上读到"void 成功 0 次"与"这根杠杆没生效"同形（§E83 那条病）。 */
      VOID_W > 0 || VOID_IDEAL_W > 0;
    /* (c) 承诺级储蓄视界 h 是**个体基因**。
     * 此前它是每局随机抽的噪声（30% 的局抽 h∈1..4）：个体不携带它 ⇒ 选择压力
     * 作用不到它 ⇒ "走通连续攒钱长轨迹"的能力没有任何机制被保留下来。
     * 现在：h=k 的个体每 3 局有 1 局跑承诺口径（ep < 1+k 只准出 ジ）+ 补贴经济。
     * 这些**承诺局一分都不进 fit**——fit 必须仍代表线上原生强度，否则又要把冠军
     * 推向"只在补贴下成立"的策略（历史上 min(pairSc, probeSc) 跨量纲就是这么塌的）。 */
    const hGene = (typeof hGeneIn === 'number' && hGeneIn > 0) ? (hGeneIn | 0) : 0;
    let fitGames = 0, commitFirst = 0, commitTop2 = 0, commitGames = 0, commitMaxEp = 0;
    /* 尾部聚合开着才逐局记账（关着 ⇒ 连数组都不建 ⇒ 热路径与旧口径逐字相同）。 */
    const gFits = FIT_TAIL_W > 0 ? [] : null;
    const agg = { use: {}, aff: {} };
    /* v1.5.87（用户裁定 A）：自对局里**成功**的非ジ动作直方图 —— 与门禁同口径。 */
    const spUse = {};   // 该个体的动作直方图（跨局汇总：脚本对手局 + **自对局**）
    let mirrorRan = 0;                  // v1.5.19：本个体实际跑了多少局自对局（可观测）
    for (let g = 0; g < games; g++) {
      const seat = g % n;                                   // 座位轮换
      const seed = seedOfGen(gen, idx, 'n') + g * 7919;
      const choosers = [];
      /* v1.4.1 修正（我 v1.3.60 改错了）：轮换**必须与个体下标无关**。
       * v1.3.60 我用 `(g*5 + idx) % opps.length` 去解决"池子大于窗口时尾部对手轮不到"，
       * 但那个改法把**同代所有个体面对同一批对手**这个配对评估（common random numbers）拆了
       * ⇒ 个体之间的适值不可比、选择噪声变大。实测代价：同 seed 同预算下两臂（9/12 对手）
       * 考卷只到 **21.8% / 23.1%**，而按旧口径训出的 v1.3.58 是 **38.4%**。
       * 正确做法：轮换只跟**代数**走 —— 同代内所有个体仍面对同一批对手（保持配对），
       * 跨代旋转即可覆盖任意大的池子（池子 > games+3 时尾部队手也不会被漏掉）。 */
      let ok = 0;   // v1.5.279：局内第几个对手席（取代旧的 `oi` 累加器）；索引式见 `oppSeatIndex`
      const imitB = imitBetaForGen(gen);   // C 方案：脚本教师模仿奖励（退火，后期为 0）
      const commitGame = isCommitGame(g, gen, hGene);   // (c) 承诺局：每 3 局 1 局，h 来自基因（v1.5.186：相位按代旋转，判据单一来源）
      const killSeatPid = killSeatFor(g, gen, seat, n, hGene);   // v1.5.160：本局注收割席在第几席（-1=不注）
      /* v1.5.99：本局是否"补贴局"（补贴 = 白来的 ep）—— 给"只教目标卡"的示范当门槛（见 makeEconChooser）。 */
      const regenThisGame = commitGame ? 2 : regenForGame(g, games, gen);
      const subThisGame = regenThisGame > 0;
      /* §E798：本局的家族席（默认关 ⇒ null ⇒ 下面那支一行都不跑） */
      const famSet = FAMILY_FIELD > 0 ? familySeatSet(g, gen, n, seat, FAMILY_FIELD) : null;
      if (famSet && famSet.size) FAM_STAT.games++;
      let econ = null;
      for (let pid = 0; pid < n; pid++) {
        if (pid === seat) {
          // (c) 承诺级 ε：h 取自**个体基因**，不再是每局随机抽的噪声
          const h = commitGame ? hGene : 0;
          let baseSel = h > 0 ? makeCommitChooser(params, 0.35, h) : fitChooser(params);
          /* v1.5.88（甲）：退火窗内**计分对局**也走强迫（这样被强迫的行为才会被真实评分、进而被选择）。 */
          if (DIV_FORCE_GENS > 0 && gen < DIV_FORCE_GENS) baseSel = makeDiversityForce(baseSel, gen);
          econ = makeEconChooser(baseSel, agg, imitB > 0 ? (imitTeacherForGen(gen) || BOT_PICKS['heavyfire']) : null, imitB, imitOnlyForGen(gen), subThisGame);
          /* v1.5.39：定向 ε-强迫（只影响"有滚环者且我付得起小雷"这一格；其余原样返回学习到的动作）。 */
          choosers.push(function (state, pid2, legal) {
            const _fe = ringForceEpsAt(gen);
            IN_EXPLORE = _fe > 0;   // 探索期（强迫窗口内）
            if (_fe > 0 && Math.random() < _fe) {
              const tg = ringForceTarget(state, pid2, legal);
              if (tg >= 0) return { key: R.SK.MINI_T, target: tg };
            }
            return econ(state, pid2, legal);
          });
        }
        else if (killSeatPid >= 0 && pid === killSeatPid && killSeatBot()) {
          /* v1.5.160：这一局的第 killSeatPid 席换成**会抢收割**的对手 ⇒ 逼受评席"该收就收"。
           * （v1.5.65 那条"4 席全被动"注入于 v1.5.163 删除 —— 它查 `BOT_PICKS` 里不存在的键，一局没开过火。） */
          const kb = killSeatBot();
          choosers.push(wrapBotN(kb));
          KILL_STAT.fired++;
          KILL_STAT.seats[seat] = (KILL_STAT.seats[seat] || 0) + 1;
          const kbName = botRegisteredName(kb);
          KILL_STAT.names[kbName] = (KILL_STAT.names[kbName] || 0) + 1;
        } else if (famSet && famSet.has(pid)) {
          /* §E798 家族副本席：同一个 `params` 走适应度用的那个 chooser（不吃补贴/强迫/模仿 ⇒ 它是"副本"不是"另一个被喂的个体"）。
           *   ⚠ 不消耗 `ok` 索引 ⇒ 脚本对手的轮换序列与不开本旋钮时逐字相同（否则等于偷偷改了对手份额，读数就说不清是谁施压）。 */
          choosers.push(fitChooser(params));
          FAM_STAT.seats++; FAM_STAT.bySeat[pid] = (FAM_STAT.bySeat[pid] || 0) + 1;
        } else { choosers.push(wrapBotN(opps[oppSeatIndex(gen, g, ok++, opps.length, OPP_BLOCK)].sel)); }
      }
      OPP_BLOCK_STAT.fitGames++; if (OPP_BLOCK) OPP_BLOCK_STAT.blockedGames++;
      // 每回合回 ep 的对局权重（可选设施，默认 0 = 与线上规则一致）。
      // 实测结论：regen=1 不能解锁聚能环（+1/回合只够每回合放一个 1 ジ技能，
      // 锁死在另一个不动点）；regen=2 确实能让 AI 学会聚能环（连用到 16），
      // 但环是严格支配策略（免费 +3/回合永续）→ 学会后反而更窄。
      // 故默认关闭，等规则/平衡决策后再开。
      /* 承诺局的"主场"是补贴经济：原生经济下 ep 根本涨不起来，"连攒 3 回合"只是一条
       * 更慢的输法，学不到任何东西。原生局仍走 Q1(d) 的永久回放切片（每 12 局 1 局带补贴），
       * 两条通道互不干扰，故 fit 的口径不被污染。 */
      const regen = regenThisGame;   // v1.5.99：上面已算好（同一口径，避免两处各算一遍）
      /* v1.5.141（DS）：补贴局里给**受评席**每回合补一颗珠 ⇒ "电磁炮"随时可负担（见 setSubBead 处的长注释）。
       * 只补受评席（`seat`）；`regen=0` 的原生局完全不走这条 ⇒ 真实强度读数量不到差别。 */
      const subBeadHook = (SUB_BEAD && regen > 0) ? function (state) {
        const me = state.p[seat];
        /* v1.8.37 夜班续（§E763）：珠种档。缺省 elec ⇒ 这一行与 v1.5.141 逐字相同；
         * boom ⇒ 补的是爆珠 ⇒ "激光眼随时可负担"进入补贴局那条评分路径。 */
        if (me && me.hp > 0 && !me.elec && !me.boom) { if (SUB_BEAD_KIND === 'boom') me.boom = 1; else me.elec = 1; }
      } : undefined;
      /* v1.5.143：状态分布塑形（**只在非补贴局**、**只在开局那一回合**、**全席对称**）—— 见 setBeadSeed 的长注释。
       * 抛硬币用**本局自己的 rng**（不是 Math.random）⇒ 同一 seed 序列可复现；`BEAD_SEED=0` 时短路 ⇒ 不消耗随机数、逐字不变。 */
      const beadSeedHook = (!subBeadHook && BEAD_SEED > 0)
        ? function (state) {
          if (state.round !== 1) return;
          if (state.rng.next() >= BEAD_SEED) return;
          for (let i = 0; i < state.p.length; i++) {
            const q = state.p[i];
            if (!q || q.hp <= 0) continue;
            if (!q.elec && !q.boom) { if (BEAD_SEED_KIND === 'boom') q.boom = 1; else q.elec = 1; }   // v1.8.37：珠种档（默认 elec = v1.5.143 原义）
            if (q.ep < 2) q.ep = 2;
          }
        }
        : undefined;
      const r = oneGameN(choosers, seed, n, { regen: regen, mode: TRAIN_MODE, onRoundStart: subBeadHook || beadSeedHook });
      /* v1.5.189：局末把"教师替受评席下的手"标记出来（**只记账，不改 fit、不改 rng**）
       * ⇒ 示范开着时，`bigUses`/链率这类臂内读数第一次能拆开"是包自己会，还是教师替它打的"。
       * ⚠️ **每一局都要过一遍**（不能只在"本局有注入"时过）：退火窗口之后注入恒 0，而那正是"学没学会"要看的段落
       *   —— 第一版我把这条挂在 `econ.rec.imit` 非空上 ⇒ 窗口后整段没有读数，量具自己把要测的那半砍掉了。 */
      if (econ && IMIT_OVERRIDE) tagImitActions(r.state.events, (econ.rec && econ.rec.imit) || {}, seat, { subsidy: subThisGame });
      const rank = rankOf(r.state, seat, seed);
      /* v1.5.8：终局还活着的人数 ⇒ 判断"这局是打出来的还是熬出来的"（≥2 人活着 = 哨声局） */
      const aliveEnd = r.state.p.filter(function (q) { return q.hp > 0; }).length;
      const base = rankCredit(rank, aliveEnd, r.state.p.length);   // N19：3 人局里第二名也算输；v1.5.8 起哨声局打折（v1.5.299 起带上人数：口径对齐要用它）
      const others = r.dmg.reduce(function (a, b) { return a + b; }, 0) - r.dmg[seat];
      const diff = r.dmg[seat] - others / Math.max(1, n - 1);
      // "立刻出手"的权重下调（原来在惩罚攒钱）；腾出的权重给经济两项
      const proact = 0.02 * Math.max(-1, Math.min(1, diff / 6));
      const deal = DEAL_W * Math.min(1, r.dmg[seat] / 4);
      /* v1.5.14：**先手激励** —— 本局第一个造成伤害的席位拿 FIRST_W（默认 0 = 关）。 */
      const firstBonus = (FIRST_W > 0 && firstBloodSeat(r.state.events) === seat) ? FIRST_W : 0;
      const slow = 0.03 * Math.min(1, r.rounds / R.MAX_ROUNDS);
      // 攒得住：本局达到过的最高 ep（0/1/2/3 → 0/0.33/0.67/1）
      /* 分段 shaping（用户设计）：
       *   0~4 ep  → 攒钱奖励（鼓励手上有货，才能放 2~5 ジ 技能）
       *   5~10 ep → 不奖不罚（中间区交给它自己权衡）
       *   11+ ep  → 囤积惩罚（资源积着不转化成胜势 = 浪费）
       * 旧的 engine（按“获得的 ep 量”发钱）已撤：聚能环 +3/回合 vs ジ +1 →
       * 等于给刷环发三倍工资，" 永动刷环" 是奖励被 hack 的产物。
       * 标准经济下 ep 最高只有 1~2 → stock 项很小，不影响已有冠军口径。 */
      // C：模仿率（与脚本教师 heavyfire 的一致程度）
      const imit = (imitB > 0 && agg._mt) ? (agg._mm || 0) / agg._mt : 0;
      if (imitB > 0) { imitSum += imit; imitGames++; }
      const mEp = econ ? econ.rec.maxEp : 0;
      /* ===== v1.5.116（L2′）：本局这一席的 ep 账本恒等式：已获得 = 已花 + 被抢 + 终局余款 =====
       * 用恒等式而不是新加事件类型：`computeCost` 的扣费本来就**不发事件**（state.js:180 只有掉血/掉珠发），
       * 所以"已花"只能这么回收；三条都在同一份 events + 终局 p.ep 里，不引入第二口径。 */
      let gGain = 0, gLost = 0;
      for (let ei = 0; ei < r.state.events.length; ei++) {
        const e = r.state.events[ei];
        if (e.type !== 'ep' || e.pid !== seat) continue;
        if (e.delta > 0) gGain += e.delta; else gLost += -e.delta;
      }
      const gLeft = r.state && r.state.p && r.state.p[seat] ? (r.state.p[seat].ep || 0) : 0;
      const gSpent = Math.max(0, gGain - gLost - gLeft);
      leftEpSum += gLeft; spentEpSum += gSpent; gainEpSum += gGain;
      const stock = economyStock(mEp, n, TRAIN_MODE, gLeft);   // 门槛按 (人数, 模式)：3 人→3/10、5 人 5 血→5/20
      stockSum += stock;
      deepSum += econ ? econ.rec.heavy4 : 0;

      // 花得出：把攒的 ep 换成贵技能（2 次封顶）——只有 save 没有 conv 就是 farmer，故两项并重
      // 经济分档：贵的技能更值钱（不再指向某个特定循环）
      /* L2′-②：`CONV_RATIO` ⇒ 第一改数换成**比率**（0~1 天然有界、任何规模都有梯度、不奖励刷次数）；
       * 第二改数（cost≥4 的"大件至少来一次"）**保持封顶** —— 它问的是"到没到过那一档"，本来就该是台阶。 */
      /* `CONV_OFFENSE` 把分子从"花掉的钱"收窄成"花在进攻卡上的钱"（默认关 ⇒ 逐位不变） */
      const spentTerm = CONV_OFFENSE ? ((econ && econ.rec.offSpend) || 0) : gSpent;
      const conv = (CONV_RATIO ? 0.08 * Math.min(1, spentTerm / Math.max(1, gGain))
                               : 0.08 * Math.min(1, (econ ? econ.rec.heavy : 0) / 2))
                 + 0.08 * Math.min(1, (econ ? econ.rec.heavy4 : 0) / 1);
      /* 打断开环者：窄条件（真的有人开环）+ 可归因（是我打中的）⇒ 小额加分，两次封顶。 */
      const ringBonus = ringWeightAt(gen) * Math.min(1, ringBreaks / 2);
      /* v1.5.25：惩罚被动 —— 只奖"打中了且这一回合没挨打"的回合（三次封顶）。 */
      const pressBonus = PRESS_W * Math.min(1, pressRounds / 3);
      /* v1.5.29：破墙奖励 —— 只有用能穿反弹/穿防御的卡打中才记分（两次封顶）。 */
      const pierceBonus = PIERCE_W * Math.min(1, pierceHits / 2);
      /* v1.8.39：**破反弹墙**（只认穿反弹的三张卡的落地；坦克不算）。0 次 0 分、1 次吃满 ⇒ 稀事件也有梯度。 */
      const wallBreakBonus = WALL_BREAK_W > 0 ? (WALL_BREAK_W * Math.min(1, wallBreakDmg / 4)) : 0;
      /* 11:5x（PREREG §二十六 条款 4）：只给**真反射出去**的那一下付钱（amt = 被弹回去的伤害）。 */
      const reflectBonus = REFLECT_W > 0 ? (REFLECT_W * Math.min(1, reflectAmt / 2)) : 0;
      if (REFLECT_W > 0) { REFLECT_STAT.games++; if (reflectAmt > REFLECT_STAT.max) REFLECT_STAT.max = reflectAmt; if (reflectBonus > 0) REFLECT_STAT.paid++; }
      /* v1.8.42（A 案）：打在**正在摆防御的目标**身上的落地伤害（谁打谁拿）。 */
      const guardHitBonus = GUARD_HIT_W > 0 ? (GUARD_HIT_W * Math.min(1, guardHitAmt / 2)) : 0;
      if (GUARD_HIT_W > 0) { GUARD_HIT_STAT.games++; if (guardHitAmt > GUARD_HIT_STAT.max) GUARD_HIT_STAT.max = guardHitAmt; if (guardHitBonus > 0) GUARD_HIT_STAT.paid++; }
      /* 过期珠 = 纯损失：给负分（形状 min(1, 事件数/4)，与其它窄项同尺度）。 */
      const beadWastePenalty = BEAD_WASTE_W > 0 ? (BEAD_WASTE_W * Math.min(1, beadExpired / 4)) : 0;
      if (BEAD_WASTE_W > 0) { BEAD_WASTE_STAT.games++; if (beadExpired > BEAD_WASTE_STAT.max) BEAD_WASTE_STAT.max = beadExpired; if (beadWastePenalty > 0) BEAD_WASTE_STAT.paid++; }
      if (WALL_BREAK_W > 0) { WALL_BREAK_STAT.games++; if (wallBreakDmg > WALL_BREAK_STAT.max) WALL_BREAK_STAT.max = wallBreakDmg; if (wallBreakBonus > 0) WALL_BREAK_STAT.paid++; }
      /* v1.5.76（P1）：珠子闭环 —— 只奖**花掉**（囤着/过期一律不计，两次封顶）。
       * 动机：用户实测线上包 `chargeProfile` 浪费率 100%（得珠 0.30/局、花掉 0.00），
       * 而珠子消费卡（电磁炮/天火）都要 2 ジ ⇒ 蓄能常发生在 ep=1 ⇒ 下回合必然凑不出。
       * 既没有信号、也没有经济余量 ⇒ 闭环学不出来。这里补**信号**那半边。 */
      const beadBonus = BEAD_W * Math.min(1, beadSpent / 2);
      /* v1.8.37 夜班续（§E763）：**只给花掉的爆珠**定价的那一半（两次封顶，与 beadBonus 同尺度）。
       * 缺省 BEAD_BOOM_W=0 ⇒ 这一项恒 0 ⇒ `gFit` 逐字不变（出厂不变量，D175 探针的往返盯着它）。 */
      const beadBoomBonus = BEAD_BOOM_W * Math.min(1, beadBoomSpent / 2);
      /* v1.5.79（第七轮复核 §15-1）：**优先打威胁**（反狙击/反环）。两次封顶，与其它窄奖励同尺度。 */
      const tgtBonus = TGT_W * Math.min(1, threatHits / 1);
      const laserBonus = LASER_W * Math.min(1, laserHits / 1);
      /* v1.8.29（用户 10-23 两条裁定）：
       *   ① 「失效技能应该都要给奖励」⇒ 每一次**可归因的失效成功**（破防/破转移/废掉非 ジ 的卡）付 `VOID_W`；
       *   ② 「激光眼打中防御同时刚好有另一个人攻击……给比一般命中更高的奖励」⇒ 理想情况在①之上**再加**
       *     `VOID_IDEAL_W`（不是替换），所以它必然比一次普通失效付得多，而一次普通失效仍有钱。
       * 标度沿用 v1.5.79 那条"0 次得 0、1 次吃满"（这两个事件比穿防更稀，用 /2 会几乎恒为 0）。 */
      const voidBonus = VOID_W * Math.min(1, voidWins / 1);
      const voidIdealBonus = VOID_IDEAL_W * Math.min(1, voidIdeal / 1);
      /* v1.5.103（v1.5.100 §20）：**清场计数**奖励 —— 补上第二个"门禁在量、选择看不见"的量。
       * 门禁要 `场B 清场 ≥ 0.3/局`（**收缩开始前真把对手打死**，不是胜率），而训练侧 `fit` 里
       * **一项都没有** ⇒ 新规则下"打 1 点就能在全灭判胜里赢"⇒ 演化没有理由去长这个能力
       * （实测：`DIV_W=0.3` + 真示范那批 6 个里 4 个场B 清场 = 0.00，在位包 0.63）。
       * 封顶 /1，与 `tgtBonus` 同尺度（标度按 v1.5.79 的教训取"0 次得 0、1 次吃满"）。 */
      const clearBonus = CLEAR_W * Math.min(1, clears / 1);
      /* v1.5.121（E4）：**挡下一次伤害** —— 与"清场"互补的那把尺子（清场 = 打死人；这个是扛住）。
       * 封顶 /1（**量出来的标度**：线上包自对局实测每席每局只有 **0.10** 次挡下、最大 0.40 ⇒
       * 用 /2 会几乎恒为 0、奖励退化成常数微扰；改用 v1.5.79 那条"0 次得 0、1 次即吃满"的规矩）。 */
      const blockBonus = BLOCK_W * Math.min(1, blocks / 1);
      /* ===== v1.5.124（复核 §28a 的处方 (ii)）：**把"广度"从门槛升格为收益项** =====
       * 病：出厂 `DIV_W=0.06` 在胜率项（量级 ~1.0）前**没有梯度**；而 `G≥3` 只是**事后砍窄包**
       * （无筛选种群 G 中位 **2.4**、12 个 seed 只有 2 个过门槛）⇒ 门槛不生产宽包。
       * ⚠️ 为什么不直接给 `divBonus` 加权：它是**归一化**熵（可行集合越穷越高 ⇒ 可被"把菜单变穷"刷高，
       * 见 v1.5.92 的注释）；这里改用**绝对**的"用过的招数种类数"（`countVariety` 去重计数），
       * 并挂在阈值之上：`≤ WIDTH_FLOOR(3)` 不给钱 · `≥ WIDTH_TARGET(7)` 给满 ⇒ 刷不动、有 0→1 梯度。
       * ⚠️ 关掉时必须是**严格 0**（`0 * NaN = NaN` 会把整个 fit 打成 NaN —— 我第一版就这么踩的）。 */
      /* v1.7.90：**落地广度**项 —— 形状与下面 `widthBonus` 逐字同形，只把度量换成 `varietyMaxLanded`
       *   （`countVarietyLanded`：`damage.via` 里的真卡名，与验收的 `effSkillsLand` 同源）。
       *   为什么另起一项而不是改 `widthBonus` 的度量：默认 0 ⇒ **逐位不变**，不逼在册臂重基线；
       *   要对齐验收时显式开这一项即可（`EPIRUS_WIDTH_LAND_W`）。 */
      const widthLandBonus = WIDTH_LAND_W > 0
        ? (WIDTH_LAND_W * Math.min(1, Math.max(0, varietyMaxLanded - WIDTH_FLOOR) / Math.max(1, WIDTH_TARGET - WIDTH_FLOOR)))
        : 0;
      if (WIDTH_LAND_W > 0) { WIDTH_LAND_STAT.games++; if (varietyMaxLanded > WIDTH_LAND_STAT.max) WIDTH_LAND_STAT.max = varietyMaxLanded; if (widthLandBonus > 0) WIDTH_LAND_STAT.paid++; }
      const widthBonus = WIDTH_W > 0
        ? (WIDTH_W * Math.min(1, Math.max(0, varietyMax - WIDTH_FLOOR) / Math.max(1, WIDTH_TARGET - WIDTH_FLOOR)))
        : 0;
      /* v1.5.126（用户洞察）：**贵卡出手**奖励 —— "贵卡"由**声明字段推导**（`cost ≥ 3` 或 `energyNeeds`），
       * 不写卡名清单（D81/D72 的规矩）。这一族正是"用不上就没必要攒 ep"的那几张（大雷/地雷/净化/电磁炮/摄魂/激光眼）。
       * 标度同 v1.5.79 的规矩：**0 次得 0、1 次即吃满**（现状是 0% ⇒ 先给"从不会到会"这一步的梯度）。 */
      const bigBonus = BIGCARD_W > 0 ? (BIGCARD_W * Math.min(1, bigUses / 1)) : 0;
      /* v1.5.260（用户 GO"做 B+"）：**贵卡预算权重**（默认 0 ⇒ 逐字不变）。
       * 病（§20.1/§20.2）：大雷/贵卡是"抽到就得留住"的瞬态（21 粒只 1 粒学会、续训三臂全掉回 ~0）；
       *   而 `bigBonus` 的形状 `min(1, bigUses/1)` **1 次就吃满** ⇒ 对"已经出 3~8 次"的粒**没有梯度**。
       * 本项用**线性计数**：0 次 0 分、每多一次多一份 ⇒ 选择压力第一次**朝向**它。
       * ⚠️ 默认 0 ⇒ 与旧行为逐字相同（门钉 A/A）；开不开属用户裁定，本版只接线。 */
      const costlyBonus = COSTLY_W > 0 ? (COSTLY_W * bigUses) : 0;
      if (costlyBonus > 0) COSTLY_HITS++;   // 剂量表：只记'这项真的非零过'，不改任何判定
      /* v1.5.188（用户裁 Q-14 选项 ②）：**按"率"付，不按"绝对计数"付** —— 形状改为
      *     `W × min(1, 该席连带数 / 该席大雷出手数)`（0 出手 ⇒ 0 分，**不做 0/0**）。
      * 为什么换（v1.5.187 的失败读数）：`min(1, 链数/1)` 是"一发幸运链 = 吃满 W" ⇒ 想看见梯度必须把 W 抬到 ~1.5，
      * 而那量级已经把名次适应度（0~1）整个盖掉 ⇒ 选出的是**又窄又低分**的包（考卷 35.4%→23.5%、净落地 3.29→1.24）。
      * 率形同时改掉了**激励方向**（这才是用户口径的原话）："追的是打出连导，不是使用率" ——
      *   计数形付的是"搅动了几次"（多出手就多机会抽中），率形付的是"**你用它的时候是不是真的赚了**"（挑时机）。
      * ⚠️ 分母 `bigTCasts` 与分子 `chains` **都不受权重门控**（同 v1.5.187 那条教训：读数跟着开关关 ⇒ "死作用点"与"真没链"分不开）。
      * 分母不写常数、写"率"本身：0~1 天然就是完整梯度，不需要再凑一个目标值（历史臂 `chainw15` 用的是旧形状，已在 CHANGELOG 注明作废）。 */
      const chainBonus = BIGT_CHAIN_W > 0
        ? (BIGT_CHAIN_W * Math.min(1, bigTCasts > 0 ? chains / bigTCasts : 0))
        : 0;
      /* ⚠ 标度是**量出来的**（v1.5.79 修正）：威胁命中的真实频率只有 0.30 次/局（线上包实测），
       * 用 /2 封顶时几乎每局都落在 0~0.15 ⇒ 奖励退化成常数级微扰、没有梯度。
       * 改成 /1：0 次得 0、1 次即吃满 ⇒ 约三成的局吃满，**方差大 = 真的有梯度**。 */
      const gFit = Math.max(-0.3, Math.min(1.8, base + proact + deal + firstBonus + stock + conv - slow + imitB * imit + ringBonus + pressBonus + pierceBonus + beadBonus + beadBoomBonus + tgtBonus + laserBonus + voidBonus + voidIdealBonus + clearBonus + blockBonus + widthBonus + widthLandBonus + wallBreakBonus + reflectBonus + guardHitBonus - beadWastePenalty + bigBonus + costlyBonus + chainBonus));
      if (commitGame) {
        /* 承诺局只记账，不进 fit：它们是 h 基因的存活依据 + 终局门槛的输入。 */
        if (rank === 1) commitFirst++;
        if (rank <= 2) commitTop2++;
        commitGames++;
        if (mEp > commitMaxEp) commitMaxEp = mEp;
      } else {
        fit += gFit; fitGames++;
        if (gFits) gFits.push(gFit);   // 尾部聚合的原料 = **这些已经跑完的局**，不多花一局
        if (econ) { maxEpSum += econ.rec.maxEp; heavySum += econ.rec.heavy; holdSum += econ.rec.hold; econGames++; }
        // 经济引擎质量：本局获得的 ep 总量。聚能环第 3 次起每回合 +3（ジ 只 +1），
        // 直接在这个量上体现 → 不用为“环”单独写奖励，避免又指向特定循环。
        // v1.5.116（L2′）：同一件事在上面已经随 `gGain` 扫过一遍 ⇒ 这里只做累计，不再重扫 events。
        epGain += gGain;
        if (rank === 1) first++;
        else if (rank === 2) second++;
        dealt += r.dmg[seat];
        rounds += r.rounds;
        played++;
        /* v1.5.23/24：打断开环者（只用事件重建，不动引擎）；权重按**退火曲线**（前期 0）。 */
        /* ⚠ v1.5.272（§E83）：下面 8 行的门从"各自的 W"换成 `DOSE_ON`（见 :1407 的说明）——
         *   **计数按族一起算、收益项仍各自按 W 付钱** ⇒ `fit` 逐位不变，但剂量表在任何一根被下达时都全族可见。 */
        if (DOSE_ON) ringBreaks += countRingBreaks(r.state.events, seat);
        if (DOSE_ON) pressRounds += countPressRounds(r.state.events, seat);
        if (DOSE_ON) pierceHits += countPierceHits(r.state.events, seat);
        /* v1.8.39：同一趟事件里另数「穿反弹卡落地」（DOSE 族：开了才扫）。 */
        if (DOSE_ON) wallBreakHits += countWallBreakHits(r.state.events, seat);
        if (DOSE_ON && REFLECT_W > 0) reflectAmt += countReflectAmt(r.state.events, seat);
        if (DOSE_ON && GUARD_HIT_W > 0) guardHitAmt += countGuardHits(r.state.events, seat).amt;
        if (DOSE_ON && BEAD_WASTE_W > 0) beadExpired += countBeadExpiredEvents(r.state.events, seat);
        if (DOSE_ON) wallBreakDmg += wallBreakDamage(r.state.events, seat);
        /* v1.5.76（P1，用户实测"蓄能 100% 浪费"逼出来的）：**珠子闭环**奖励。 */
        if (DOSE_ON) beadSpent += countBeadSpent(r.state.events, seat);
        /* v1.8.37 夜班续（§E763）：同一趟事件里另数"花掉的**爆珠**"（只在开了那根杠杆时扫，关着零成本）。 */
        if (DOSE_ON && BEAD_BOOM_W > 0) beadBoomSpent += countBeadSpent(r.state.events, seat, 'boom');
        /* v1.5.79（复核 §15-1）：把"优先打威胁者"当能力奖（默认关，实验臂用 EPIRUS_TGT_W 打开）。 */
        if (DOSE_ON) threatHits += countThreatHits(r.state.events, seat);
        if (DOSE_ON) laserHits += countLaserHits(r.state.events, seat);
        /* v1.8.29（用户裁定 10-23「失效技能应该都要给奖励」）：一次扫描出两个数（失效成功 / 其中理想情况），
         * 与上面同族 ⇒ 也走 `DOSE_ON`（收益项仍各自按自己的 W 付钱 ⇒ 关着时 `fit` 逐位不变）。 */
        if (DOSE_ON) { const vsc = voidScan(r.state.events, seat); voidWins += vsc.wins; voidIdeal += vsc.ideal; }
        /* v1.5.103（v1.5.100 §20）：**清场**（收缩开始前把对手打死）—— 与门禁 `场B 清场` 同口径。 */
        if (DOSE_ON) clears += countClears(r.state.events, seat);
        /* v1.5.121（第十三轮复核 §23 的 **E4**）：**挡下伤害**（真的挡掉/弹走，**不认摆架势**）。
         * 论点：防御族**费用 0 ep** ⇒ 与"ep 深度"不同，它不需要多回合计划 ⇒
         * 是"shaping 只在 0.0X 尺度、买不动多回合计划"这条限制**唯一**还可能绕过的方向。 */
        if (DOSE_ON) blocks += countBlocks(r.state.events, seat);
        /* v1.5.124（§28a）：**广度**的绝对量 —— 该快照里"用过的招数种类数"（去重）。
         * 取 `max` 而不是累加：要的是"这个策略的招式面有多宽"，不是"出手多少次"。 */
        if (DOSE_ON) varietyMax = Math.max(varietyMax, countVariety(r.state.events, seat));
/* v1.7.90：**落地广度**的绝对量（与 `effSkillsLand` 同源：只数 `damage.via` 里**真卡名**）。 */
if (DOSE_ON) varietyMaxLanded = Math.max(varietyMaxLanded, countVarietyLanded(r.state.events, seat));
        /* v1.5.126：**贵卡**（声明费用 ≥3 或需珠）的出手 —— 用户指出"这个包不会用电磁炮/大雷、也丢了地雷/净化
         * ⇒ 它当然没必要攒 ep" ⇒ 直接给这一族付钱（它们不可刷：真的用出来才给钱）。 */
        /* v1.5.265（qoder §E65）：**累加移出权重门** —— 这一行原本包在 `if (BIGCARD_W > 0)` 里，
         * 于是"只开 `costlyW`、不开 `bigcardW`"的臂**剂量恒 0**（`costlyBonus = COSTLY_W × bigUses`），
         * 而这件事在臂的读数上完全看不出来 ⇒ 09-27 那次"三档产出逐字节相同"被当成了
         * "`bigUses` 在评分局里恒为 0 ⇒ 这条杠杆结构性惰性"（**假零结果**，本仓 §24 根因的同族第二例：
         * 线没接通 ≠ 信号不存在）。`bigBonus` / `costlyBonus` **仍各按自己的权重门控**（:1572/:1578）⇒ 两个 W 都为 0 时逐字不变。
         * 规矩与本文件 :1639 的 `chains`/`bigTCasts` 一致：**计数不设门槛，只有付钱的那一项设门槛**。 */
        bigUses += countBigCards(r.state.events, seat, R);
        /* v1.5.187（DS 交接 §2b 的唯一待做）：**连带**才是要付钱的东西（用户口径："追的是打出连导，不是使用率"）
         * ⇒ 这一项与 `BIGCARD_W` 分开是有意的：那个数"用了贵卡"，这个数"用了大雷并且真的搅动了全场"。
         * ⚠️ **计数不设门槛**（只有 `chainBonus` 受 `BIGT_CHAIN_W` 门控）⇒ 这样 `W=0` 的臂也能白拿"连带/局"这个读数，
         *   门才能拿它判"权重到没到作用点"（否则 W=0 时链数永远是 0，`fit` 不动到底是"死作用点"还是"真没链"就分不开 —— 这次就卡在这一步过）。
         * v1.5.188：分母（该席**真正打出的大雷**次数）同样**不设门槛** ⇒ 率形要能算，也要能在 W=0 的臂上被量出来。 */
        chains += countBigTChain(r.state.events, seat, R);
        bigTCasts += countBigTCasts(r.state.events, seat, R);
      }
    }
    /* ===== v1.5.19（方向 A）：自对局折进多样性 =====
     * 每局都是"n 座同一策略"⇒ 动作直方图并进 agg（只并直方图；first/played/dealt 一概不动）。 */
    /* ===== v1.5.69：**独立座位探针**（供下面的阈值式座位惩罚）=====
     * 5 席同一策略 × SEAT_GAMES 局 ⇒ 各座胜场 ⇒ 极差。独立取样（不蹭 MIRROR_GAMES=2 的局），
     * 否则样本不足 ⇒ 惩罚静默失效（v1.5.68 的实际教训）。 */
    const seatWinsProbe = new Array(n).fill(0);
    let seatDec = 0;
    if (SEAT_GAMES > 0) {
      for (let g = 0; g < SEAT_GAMES; g++) {
        const st = S.createState(TRAIN_MODE === 'long' ? 'long' : 'multi', { next: mulberry32(31000 + gen * 131 + idx * 17 + g) }, n);
        st.slotSalt = slotSaltFor(31000 + gen * 131 + idx * 17 + g);
        const chs2 = [];
        for (let pid = 0; pid < n; pid++) chs2.push(makeEconChooser(fitChooser(params), agg, null, 0));
        Play.autoGameN(st, chs2);
        if (st.winner !== 'draw' && st.winner != null) { seatWinsProbe[st.winner]++; seatDec++; }
        /* v1.5.87：累计"成功非ジ动作"，与 mirrorHealth 的 keyCount **同口径** ——
         * 老的 agg.use 收的是 chooser 返回的每一个动作（含探索 ε、econ 覆盖、作废/失败）⇒
         * 加大熵权重优化的是那个量，门禁的 G 不涨甚至下降（这就是用户问到的现象）。 */
        for (const e of (st.events || [])) {
          if (e.type === 'action' && e.outcome === 'ok' && e.key && e.key !== R.SK.JI) spUse[e.key] = (spUse[e.key] || 0) + 1;
        }
      }
    }
    const mirSeatWins = seatWinsProbe;
    const mirDec = seatDec;
    if (MIRROR_GAMES > 0) {
      for (let g = 0; g < MIRROR_GAMES; g++) {
        const seed = seedOfGen(gen, idx, 'mir') + g * 6151;
        const chs = [];
        for (let pid = 0; pid < n; pid++) chs.push(makeEconChooser(fitChooser(params), agg, null, 0));
        const rm = oneGameN(chs, seed, n, { regen: 0, mode: TRAIN_MODE });
        void rm;   // v1.5.69：座位统计已改走独立探针，这里不再重复计数
        mirrorRan++;
      }
    }
    /* 技能覆盖熵：目标函数里唯一不指向某个循环的广度信号。
     * 策略是"动作价值 softmax + 低温"的贪心取值，而目标里只有胜负时必然塔到一招；
     * 实测给到无限经济也只从激光剑换成狙击枪（有效技能数 1.88→2.06）。
     * 归一化用 ln(28) 作为上限：6 种均匀 → H/ln28 ≈ 0.54。 */
    let H = 0, uTot = 0;
    for (const k in agg.use) uTot += agg.use[k];
    if (uTot > 0) {
      for (const k in agg.use) { const pr = agg.use[k] / uTot; H -= pr * Math.log(pr); }
    }
    // 归一化只按"当时可负担的动作数"（千问：拿 28 归一化是在量一个恒为 0 的量）
    const affN = Math.max(2, Object.keys(agg.aff || {}).length || (R.skills || []).length);
    /* v1.5.8：改走 coverageEntropy —— **只统计非ジ动作**（用户裁定），否则攒钱会把熵压到极低、
     * 反过来惩罚攒钱。旧的 H/uTot/affN 三行保留只为下方日志口径连续（H 已不参与 fit）。 */
    const cov = coverageEntropy(agg.use, agg.aff, DIV_K);   // 保留：仅作历史口径的对照量（不再进 fit）
    const divNorm = cov.divNorm;
    /* v1.5.87（用户裁定 A）：进 fit 的熵改用**自对局·成功非ジ动作**（与门禁 G 同源），固定分母 ln(DIV_K)。 */
    let spTot = 0;
    for (const k in spUse) spTot += spUse[k];
    let spH = 0;
    if (spTot > 0) for (const k in spUse) { const pr = spUse[k] / spTot; spH -= pr * Math.log(pr); }
    /* v1.6.50（用户裁定 B）：与闸同源的有效技能数 G = exp(熵)（`mirrorHealth` 的 `effSkills` 同一算式），
     * 并按 FIT_G_W 只罚下界。`FIT_G_W = 0` ⇒ gBonus 恒 0 ⇒ fit 逐位不变（默认关的形状照 D173 那族）。 */
    const spG = spTot > 0 ? Math.exp(spH) : 0;
    /* 2026-10-24（ZCode · 用户点名）：符号修复 —— 修前是 `FIT_G_W × max(0, FLOOR − spG)` **加进** fit，
     * 即"越塌缩加分越多"，与 v1.6.50 裁定「只罚下界」正好相反（证据链见
     * docs/research/reviews/REVIEW-2026-10-24-fitg-sign-coldstart-zcode.md §三；
     * 恒等式门 train-table/train-evo 用的是返回值本身 ⇒ 取负后自动保持）。
     * ⚠ 方向腿（spG < FLOOR ⇒ gBonus ≤ 0）尚未进门体，留给下一班。 */
    gBonus = FIT_G_W > 0 ? (-FIT_G_W * Math.max(0, FIT_G_FLOOR - spG)) : 0;   /* 赋值（非声明）⇒ 给最终 fit 用 */
    const spDivNorm = spTot > 0 ? (spH / Math.log(DIV_K)) : 0;
    /* v1.5.93（用户裁定）：类间广度 —— 同一份 `spUse`，只按 `roleOf` 再聚合一层（8 个功能角色）。
     * 分层熵恒等式 `S = S_role + S_within` ⇒ 这里只需单独算 `S_role`，角色内由减法得到，不必重算。 */
    const roleUse = {};
    for (const k in spUse) {
      const r2 = roleOf(k);
      roleUse[r2] = (roleUse[r2] || 0) + spUse[k];
    }
    let spRoleH = 0;
    if (spTot > 0) for (const r2 in roleUse) { const pr = roleUse[r2] / spTot; spRoleH -= pr * Math.log(pr); }
    const spRoleNorm = spTot > 0 ? (spRoleH / Math.log(K_ROLE)) : 0;
    const spMixNorm = (1 - DIV_ROLE_W) * spDivNorm + DIV_ROLE_W * spRoleNorm;
    /* v1.5.6：按用户裁定**恢复**技能熵奖励（Q3 曾把它移出目标函数）。
     * 权重给得小（DIV_W=0.06，满额 +0.06），与 stock（+0.05 / −0.12）同量级 ⇒ 两项加起来仍远小于
     * 胜负项（base 1.0/0.3），符合"奖惩也不用给太多"。 */
    const divBonus = DIV_W * spMixNorm;   // v1.5.92：DIV_CAT_W=0 时**逐位等于** v1.5.87 的口径（自对局·成功非ジ动作）
    /* v1.5.124（§28a）：广度收益项在 `gFit` 之前算（用 `agg.use`）—— 见那一处的说明。 */
    /* v1.5.88（甲·步 2）：破墙硬过滤（默认关，EPIRUS_WALL_FILTER=1 打开）。 */
    const wallDmg = WALL_FILTER_ON ? wallProbe(params, WALL_GAMES, n) : null;
    const wallReject = (wallDmg != null && wallDmg < 0.5);
    /* ===== v1.5.68（第五轮复核 §4 的 ④ 落地）：**阈值式座位惩罚**（约束处理，不是奖励权重）=====
     * 病：训练从不评估"5 席同策略"这一配置 ⇒ 固定目标偏好的策略在机器人池上能赢、在 5 席测量里却某座通吃，
     * 演化永远惩罚不到它（v9~v15 五批 30+ 候选全是这个形状）。
     * 做法：用**已经在打的 mirror 局**（零额外成本）统计各座胜场；极差**超过阈值才扣分**，
     * 低于阈值一分不扣 ⇒ 不改变"好个体之间的相对次序"，只在偏置真的大时把它压下去。
     * 为什么不加奖励：先手激励 -14pt、破墙奖励让混合场 40%→17% —— 加权奖励已被两次实验证伪。 */
    /* v1.5.69 标定：6 局样本下"极差"的**噪声地板**就有 40~60pt（对称假设下 multinomial(6,1/5) 的
     * 期望极差 ≈50pt）⇒ 用"极差 > 35pt"当触发条件等于**按噪声随机扣分** ✗。
     * 改成只在**明显通吃**时触发：某座占 ≥70% 的分胜负局（对称假设下概率约 0.2%，不是噪声）。
     * 权重量级：100% 通吃 ⇒ 扣 0.30（相对成员 fit 0.2~0.5 是重罚），70% ⇒ 一分不扣。 */
    const SEAT_PEN_MAXPCT = 70, SEAT_PEN_W = 1.0;
    let seatPen = 0, seatSpreadMir = null, seatMaxPct = null;
    if (mirDec >= 4) {
      const pcts = mirSeatWins.map(function (w) { return 100 * w / mirDec; });
      seatSpreadMir = Math.max.apply(null, pcts) - Math.min.apply(null, pcts);
      seatMaxPct = Math.max.apply(null, pcts);
      if (seatMaxPct >= SEAT_PEN_MAXPCT) seatPen = SEAT_PEN_W * ((seatMaxPct - SEAT_PEN_MAXPCT) / 100);
    }
    /* ===== 风格表现切片（v1.5.2，见模块头部 setStyleSlice 的说明）=====
     * 追加在池子预算之外 ⇒ 不摊薄原有练习量；原生规则（regen=0）⇒ 量的是真实强度。 */
    let styleGames = 0, styleFirst = 0;
    if (STYLE_OPPS && STYLE_OPPS.length && STYLE_GAMES > 0 && STYLE_W > 0) {
      for (let g = 0; g < STYLE_GAMES; g++) {
        const seat = g % n;
        const choosers = [];
        let ok = 0;   // v1.5.279：风格切片同样受 `EPIRUS_OPP_BLOCK` 管（两条训练路要同形，否则"环境"只在一半训练里存在）
        /* §E798：风格切片同一形 —— 家族副本席按同一规则注入，否则桌形只在一半训练里存在（上面那条教训的原话） */
        const famSet = FAMILY_FIELD > 0 ? familySeatSet(g, gen, n, seat, FAMILY_FIELD) : null;
        if (famSet && famSet.size) FAM_STAT.games++;
        for (let pid = 0; pid < n; pid++) {
          if (pid === seat) choosers.push(trainChooser(params));
          else if (famSet && famSet.has(pid)) {
            choosers.push(trainChooser(params));
            FAM_STAT.seats++; FAM_STAT.bySeat[pid] = (FAM_STAT.bySeat[pid] || 0) + 1;
          }
          else { choosers.push(wrapBotN(STYLE_OPPS[oppSeatIndex(gen, g, ok++, STYLE_OPPS.length, OPP_BLOCK)].sel)); }
        }
        OPP_BLOCK_STAT.styleGames++; if (OPP_BLOCK) OPP_BLOCK_STAT.styleBlocked++;
        const sd = seedOfGen(gen, idx, 'style') + g * 7919;
        const r = oneGameN(choosers, sd, n, { regen: 0, mode: TRAIN_MODE });
        styleGames++;
        if (rankOf(r.state, seat, sd) === 1) styleFirst++;
      }
    }
    const styleRate = styleGames ? styleFirst / styleGames : 0;
    const fitAvg = fitGames ? fit / fitGames : 0;
    /* 尾部聚合（§E49）：`w=0` ⇒ 整段是恒等操作，`fitAgg` 与 `fitAvg` 逐位相同 ⇒ 出厂行为不变。
     * 少于 4 局不算尾部：q=0.25 时 4 局才够一个样本，再少就是拿单局噪声当分布。 */
    let fitAgg = fitAvg;
    if (FIT_TAIL_W > 0 && gFits && gFits.length >= 4) {
      const srt = gFits.slice().sort(function (a, b) { return a - b; });
      const kk = Math.max(1, Math.floor(srt.length * FIT_TAIL_Q));
      let es = 0;
      for (let i = 0; i < kk; i++) es += srt[i];
      fitAgg = (1 - FIT_TAIL_W) * fitAvg + FIT_TAIL_W * (es / kk);
    }
    /* P2（qoder-research 0920）：形状项 = S4_W × 宿主评分器(0..1)。评分器抛错**不吞**（与教师计划同规矩：
     * 静默退回默认 = 又一次 A/A 事故的形状）。`S4_W=0` 时连评分器都不调用 ⇒ 出厂行为逐字不变。 */
    const shapeBonus = (S4_W > 0 && !wallReject)
      ? (typeof global.__shapeScorer === 'function' ? S4_W * Math.max(0, Math.min(1, global.__shapeScorer(params)))
        : (() => { throw new Error('[shape] S4_W>0 但宿主未注入 __shapeScorer（worker/server 接线断了 ⇒ 不许静默跑）'); })())
      : 0;
    /* v1.5.272（§E83）：行为剂量表的分母 —— 与 `costlyPerGame` 同口径（优先计分局，退回已完成局）。 */
    const doseG = fitGames || played;
    /* ⚠ `DOSE_ON` 为假时这些字段必须是 **null（未量）**而不是 0 —— 0 会被读成"这个个体真没做出该行为"，
     * 而那正是本条要消灭的混淆（同 D138「没测到必须单独成类」的规矩）。 */
    const doseEv = function (v) { return DOSE_ON ? v : null; };
    const dosePer = function (v) { return DOSE_ON ? (doseG ? v / doseG : 0) : null; };
    return {
      fit: (wallReject ? (-5.0) : (fitAgg + divBonus + STYLE_W * styleRate - seatPen + shapeBonus + gBonus)),
      wallDmg: wallDmg,
      wallReject: wallReject,
      fitNoDiv: fitAgg,
      /* §E49 读数：开关关着时 `fitMean === fitNoDiv − 加项` 的旧均值；开着时两者之差就是尾部罚的分量
       * ⇒ 臂上/终评能分开"它本来分低"与"它被地板拖下来"。 */
      fitMean: fitAvg,
      /* v1.5.187：连带读数**始终**随评分返回（不受权重门控）⇒ 臂上/门都能看"这一粒到底搅动了几次"，
       * 也才分得开"权重没生效"与"根本没打出链"。
       * v1.5.188：加上**分母**（`chainCasts` = 该席真正打出的大雷数）与**率**（`chainRate`）⇒
       * 换形状之后必须还能看见"率是几、分母是几"，否则又一次只能事后量（而且 `0/0` 这条路要显式走 0）。 */
      chainEvents: chains, chainPerGame: (fitGames || played) ? chains / (fitGames || played) : 0,
      chainCasts: bigTCasts, chainRate: bigTCasts > 0 ? chains / bigTCasts : 0,
      /* v1.5.265（§E65）：贵卡剂量**始终**随评分返回（同 `chainEvents` 的规矩）⇒
       * 否则"这项没生效"与"这一粒真没打贵卡"在臂上长得一模一样（09-27 那次假零结果的直接成因）。 */
      costlyUses: bigUses, costlyPerGame: (fitGames || played) ? bigUses / (fitGames || played) : 0,
      /* v1.5.272（§E83）：**整族行为剂量**随评分返回（门见 :1407 的 `DOSE_ON`）——
       * 这 8 根杠杆（环打断/压制/穿防/珠闭环/瞄威胁/清场/挡下/广度）原本"计数与收益项同门"，
       * 于是 W=0 时读数恒 0 ⇒ "这根杠杆没作用"永远无法被否证（`bigUses` 那次假零结果的同族）。
       * 现在同一族的兄弟互为对照组：只有 `fit` 里的收益项仍各自按 W 门控。 */
      ringBreakEv: doseEv(ringBreaks), ringBreakPerGame: dosePer(ringBreaks),
      pressEv: doseEv(pressRounds), pressPerGame: dosePer(pressRounds),
      pierceEv: doseEv(pierceHits), piercePerGame: dosePer(pierceHits),
      beadEv: doseEv(beadSpent), beadPerGame: dosePer(beadSpent),
      beadBoomEv: doseEv(beadBoomSpent), beadBoomPerGame: dosePer(beadBoomSpent),   // v1.8.37 夜班续：花掉的爆珠单独可读
      threatEv: doseEv(threatHits), threatPerGame: dosePer(threatHits),
      clearEv: doseEv(clears), clearPerGame: dosePer(clears),
      blockEv: doseEv(blocks), blockPerGame: dosePer(blocks),
      /* v1.8.29：失效定价这一族的两格读数（同 §E83 的规矩 —— 未量必须 `null`，不许与"真没做到"同形）。
       * 顺带补 `laserEv`：v1.8.23 那根激光眼杠杆的计数一直在算，却**没随评分返回** ⇒
       * 臂上分不清"LASER_W 没生效"与"这一粒真没打中"，正是本族要消灭的那个混淆。 */
      laserEv: doseEv(laserHits), laserPerGame: dosePer(laserHits),
      voidEv: doseEv(voidWins), voidPerGame: dosePer(voidWins),
      voidIdealEv: doseEv(voidIdeal), voidIdealPerGame: dosePer(voidIdeal),
      varietyMaxEv: doseEv(varietyMax), doseOn: DOSE_ON,
      styleGames: styleGames, styleFirst: styleFirst, styleRate: styleRate, styleWeight: STYLE_W,
      divNorm: divNorm,
      spDivNorm: spDivNorm,
      spRoleNorm: spRoleNorm, spRoleH: spRoleH, spMixNorm: spMixNorm, divRoleW: DIV_ROLE_W,
      spH: spH,
      spG: spG, gBonus: gBonus, fitGW: FIT_G_W, fitGF: FIT_G_FLOOR,   // v1.6.50（B）：这一维的读数栏（开档才非零）
      /* §E659（10-20 夜班）：`fit` 的**六项**里只剩 `shapeBonus` 没随评分返回，而 D13/D15 那两条恒等式断言的
       *   契约是"fit = 报告出来的各加项之和"（见 train-table.mjs 里 v1.5.71 那段：漏 seatPen 时"5 次里 1 次随机红"）。
       *   补上它，契约才真的闭合 ⇒ 任何一项都能被审计，门不必靠"猜这档是关着的"来写恒等式。 */
      shapeBonus: shapeBonus, s4W: S4_W,
      divBonus: divBonus,
      seatPen: seatPen, seatSpreadMirror: seatSpreadMir, seatMaxPct: seatMaxPct, mirrorDecisive: mirDec,
      divW: DIV_W,
      mirrorGames: mirrorRan,
      avgStock: econGames ? stockSum / econGames : 0,
      distinct: Object.keys(agg.use).length,
      distinctNonJi: cov.distinct, nonJiShare: uTot ? cov.nonJi / uTot : 0,
      first: first, second: second, games: played,
      firstRate: played ? first / played : 0,
      top2Rate: played ? (first + second) / played : 0,
      avgDealt: played ? dealt / played : 0,
      avgRounds: played ? rounds / played : 0,
      avgMaxEp: econGames ? maxEpSum / econGames : 0,
      avgLeftEp: econGames ? leftEpSum / econGames : 0, avgSpentEp: econGames ? spentEpSum / econGames : 0,
      avgGainEp: econGames ? gainEpSum / econGames : 0,
      avgHeavy: econGames ? heavySum / econGames : 0,
      avgHold: econGames ? holdSum / econGames : 0,
      avgDeep: econGames ? deepSum / econGames : 0,
      avgImit: imitGames ? imitSum / imitGames : 0,
      /* (c) 承诺局记账 */
      hGene: hGene,
      fitGames: fitGames,
      commitGames: commitGames,
      commitFirstRate: commitGames ? commitFirst / commitGames : 0,
      commitTop2Rate: commitGames ? commitTop2 / commitGames : 0,
      commitMaxEp: commitMaxEp
    };
  }

  /* 多人实战评测：冠军在每个座位都打一遍，报 1st/2nd/3rd 率 */
  function evalN(params, oppPairs, gamesPerPair, n, seedBase) {
    let first = 0, second = 0, third = 0, total = 0;
    for (const pair of oppPairs) {
      for (let g = 0; g < gamesPerPair; g++) {
        const seat = g % n;
        const choosers = [];
        let oi = 0;
        for (let pid = 0; pid < n; pid++) {
          if (pid === seat) choosers.push(trainChooser(params));
          else { choosers.push(wrapBotN(pair[oi % pair.length])); oi++; }
        }
        const r = oneGameN(choosers, seedBase + g * 977 + total, n, { mode: TRAIN_MODE });
        const rank = rankOf(r.state, seat, seedBase + g * 977 + total);
        if (rank === 1) first++; else if (rank === 2) second++; else third++;
        total++;
      }
    }
    return {
      first: first, second: second, third: third, games: total,
      firstRate: total ? first / total : 0,
      top2Rate: total ? (first + second) / total : 0
    };
  }

  function evaluatePopulation(t, championSnap) {
    const opps = buildOpps(championSnap, 0.05);
    for (let i = 0; i < t.pop.length; i++) {
      const m = t.pop[i];
      const r = scoreMember(m.params, opps, t.gamesPerOpp, t.gen, i);
      m.attackGames = r.attackGames;
      m.attackChoices = r.attackChoices;
      m.totalChoices = r.totalChoices;
      m.attackRate = r.attackRate;
      m.attackShare = r.attackShare;
      m.score = r.score;
    }
  }

  function breed(t) {
    const sorted = t.pop.slice().sort(function (a, b) { return b.score - a.score; });
    const next = [];
    for (let i = 0; i < t.elite; i++) {
      next.push({ params: P.mutatePolicy(sorted[i].params, t.sigma * 0.5), score: 0, attackGames: 0, attackRate: 0 });
    }
    while (next.length < t.popSize) {
      const a = sorted[Math.floor(Math.random() * Math.min(6, sorted.length))].params;
      const b = sorted[Math.floor(Math.random() * Math.min(6, sorted.length))].params;
      const base = Math.random() < 0.7 ? P.crossover(a, b) : a;
      next.push({ params: P.mutatePolicy(base, t.sigma), score: 0, attackGames: 0, attackRate: 0 });
    }
    t.pop = next;
  }

  /* 冠军 vs 固定脚本基线（报告/图表用） */
  function champVsBaseline(t, games, seedBase) {
    /* v1.5.19：冠军位可能为空（健康门槛拒掉第一次提升）⇒ 依次退到 bestChamp / 种群首个体；
     * 三个都没有才返回 null（旧写法直接把 null 喂给 policyChooser ⇒ TypeError）。 */
    const cp = t.champion || t.bestChamp || (t.pop && t.pop[0] && t.pop[0].params);
    if (!cp) return null;
    const champ = policyChooser(cp, 0.05);
    let total = 0, n = 0;
    for (const nm of Object.keys(BOT_PICKS)) {
      const r = correctedWinRate(champ, BOT_PICKS[nm], games, seedBase + n * 131);
      total += r.wr; n++;
    }
    return n ? total / n : 0;
  }

  /* 一代评估完成后：排序、更新冠军、变异衰减、繁殖。返回摘要记录。 */
  function finishStep(t) {
    const sorted = t.pop.slice().sort(function (a, b) { return b.score - a.score; });
    const bestScore = sorted[0].score;
    // 冠军 = 真实胜分最高的个体（先求强）。"让人看到它进攻"由困难难度的 45% 进攻覆盖层负责。
    const cand = sorted[0];
    // 跨代保留全局最佳（并带进攻率门槛），避免最后一代抽样随机决定冠军性格。
    const better = !t.bestChamp || cand.score > t.bestChampScore + 0.001;
    /* v7（v1.5.19）：**提升冠军前先过自对局体检**。
     * 为什么必须在这里而不是只放在收尾择优：产物的冠军是**这条**语句决定的（t.champion = t.bestChamp），
     * `pickChampionByWinRate` 只管跨 seed 收尾 —— 第一版只加了后者，12 个 seed 的数字与没加时**逐个相同**，
     * 等于门槛是空操作（教训：门槛要加在"决定产物的那一行"上，见 docs/METHODOLOGY.md 第 21 条）。
     * 成本：只在真的出现"更高分候选"时才跑 promoteGames 局（默认 8），不是每代都跑。 */
    let healthReject = null;
    /* v1.5.42：**探索期内不惩罚探索** —— 被强迫的个体暂时不健康，但它们承载着"动作被采样过"的信息；
     * 若在窗口内就用健康门槛拒掉，整条提升链会被堵死（实测逃逸率 1/6）。窗口外照旧。 */
    if (better && HEALTH.on && !IN_EXPLORE) {
      const mh = mirrorHealth(cand.params, HEALTH.promoteGames, HEALTH.n, TRAIN_MODE);
      const hf = healthFails(mh);
      if (hf.length) healthReject = hf;
    }
    if (better && !healthReject) {
      t.bestChamp = cand.params;
      t.bestChampScore = cand.score;
      t.bestChampAttack = cand.attackShare || cand.attackRate;
    }
    if (healthReject) t.healthRejects = (t.healthRejects || 0) + 1;
    /* 兜底：门槛把第一次提升也拒了 ⇒ 冠军位仍是空的。用**热启动种子**顶上（而不是被拒的候选），
     * 否则 champVsBaseline 会拿到 null 崩掉整条训练线。只在"确实没有冠军"时做一次。 */
    if (!t.bestChamp) {
      /* 依次退：热启动种子 → 当前种群最高分个体。没有这层兜底，`t.champion` 会一直是 null，
       * 调用方（champVsBaseline / evalChamp / 落盘）全线崩（实测 train-best 崩在 t.champion.slice）。
       * 兜底进来的冠军会被打上 `healthFallback` 标记 ⇒ 产物侧的门槛（train-server 落盘处）仍会拦它。 */
      const fb = t.seedParams || ((t.pop && t.pop.length) ? t.pop.slice().sort(function (a, b) { return b.score - a.score; })[0].params : null);
      if (fb) { t.bestChamp = fb; t.bestChampScore = -1e9; t.healthFallback = true; }
    }
    const champPrev = t.champion;
    const champChanged = t.bestChamp !== champPrev;
    if (champChanged) { t.champion = t.bestChamp; t.championAge = 0; }
    else t.championAge++;
    t.bestParams = t.bestChamp;
    // 记录最近一代强候选 params，供收尾按真实胜率择优（避免 shaped fitness 过拟合到"打伤害不赢"的激进型）
    t.lastTop = sorted.slice(0, 3).map(function (m) { return m.params; });
    const rec = { gen: t.gen, best: bestScore, champChanged: champChanged, champAge: t.championAge, sigma: t.sigma, healthRejects: t.healthRejects || 0 };
    if (t.gen % t.baselineEvery === 0) rec.baseline = champVsBaseline(t, 6, t.gen * 99991);
    t.history.push(rec);
    t.gen++;
    // 慢速衰减变异幅度（避免过早平台期）；并每隔40代注入2个随机新个体保持多样性
    t.sigma = Math.max(0.10, t.sigma * 0.999);   // 较高sigma地板+缓衰减：种群别坍缩，才能持续探索、突破退化盆地（否则冠军蝉联且续训退化）
    if (t.gen % 40 === 0) {
      for (let j = 0; j < 2 && t.pop.length; j++) {
        const idx = Math.floor(Math.random() * t.pop.length);
        t.pop[idx] = { params: P.makePolicy(0.3), score: 0, attackGames: 0, attackRate: 0, attackChoices: 0, totalChoices: 0, attackShare: 0 };
      }
    }
    breed(t);
    return rec;
  }

  /* 同步执行一代：串行评估 + finishStep。浏览器 / 自测使用。 */
  function step(t) {
    const championSnap = t.champion.slice();
    evaluatePopulation(t, championSnap);
    return finishStep(t);
  }

  /* 从已有冠军热启动种群（持续训练：围绕冠军变异，而不是全部随机重开） */
  function seedChampion(t, params) {
    if (!params) return;
    t.seedParams = params.slice();   // v1.5.19：兜底用（健康门槛可能拒掉第一次提升 ⇒ champion 会短暂为空）
    const mk = function (p, sigma) {
      return { params: p, score: 0, attackGames: 0, attackRate: 0, attackChoices: 0, totalChoices: 0, attackShare: 0 };
    };
    t.pop[0] = mk(params.slice(), 0);
    for (let i = 1; i < t.popSize; i++) {
      const sig = i < t.elite ? t.sigma * 0.6 : t.sigma;
      t.pop[i] = mk(P.mutatePolicy(params, sig), sig);
    }
  }

  /* 收尾择优：从 [当前冠军 + 最近一代强候选] 中，按 vs 全部脚本基准的真实平均胜率挑选最强的作冠军。
   * 解决"shaped fitness 把打伤害但不赢的激进型捧成冠军"的过拟合。 */
  /* 覆盖熵：候选冠军动作分布的多样性 H/ln(#技能)。
   * 为什么必须有：择优若只做 argmax(胜率)，必然挑中最强也最窄的个体。
   * 实测同一份 fitness 下，按胜率择优得有效技能 2.52、按适应度分选得 3.25。 */
  function champEntropy(params, temp, games, seedBase, n) {
    const N = (typeof n === 'number' && n > 2) ? n : 2;
    const use = {}; let dec = 0;
    const inner = (N > 2) ? policyChooserN(params, temp) : policyChooser(params, temp);
    const sel = function (state, pid, legal) {
      const raw = inner(state, pid, legal);
      const k = (typeof raw === 'string') ? raw : raw.key;
      if (pid === 0) { use[k] = (use[k] || 0) + 1; dec++; }
      return raw;
    };
    for (let g = 0; g < games; g++) {
      if (N > 2) { const ch = []; for (let i = 0; i < N; i++) ch.push(sel); oneGameN(ch, seedBase + g * 977, N, { mode: TRAIN_MODE }); }
      else oneGame(sel, sel, seedBase + g * 977);
    }
    let H = 0;
    for (const k in use) { const pr = use[k] / dec; H -= pr * Math.log(pr); }
    /* v1.5.8：与 fit 里那条同源 —— **只统计非ジ动作**（否则"多出ジ"会被当成"打法更广"） */
    const cov = coverageEntropy(use, null, Math.max(2, (R.skills || []).length - 1));
    return { divNorm: dec ? cov.divNorm : 0, distinct: cov.distinct, effSkills: cov.effSkills, hill05: cov.hill05 };
  }

  /* 多目标择优：在「胜率分不低于最高分 - WR_TOL」的候选里，取覆盖熵最高者。
   * 这样胜率损失有界（容差内），但不再被 argmax 逼向窄解。 */
  /* ===== 课程式经济补贴（千问方案，纯训练侧，不动 shipped 规则）=====
   * 洞见：2P 能攒钱而 3P 不能，不是规则更严，而是 3P 没人替它把"攒到 3"这条路走通过一次。
   * 用法：训练前段开富经济让它**看见** ep=3/5 与聚能环/大雷的回报，再退火到线上口径。 */
  /* Q1(d) 永久回放切片（千问方案）——比"课程退火"更根本：
   * 实测：只加变异不加选择时，深经济能力在 **15~20 代**内掉 26~40pt（σ=0.06 的噪声自由游走就抹掉了）。
   * 我上一版"前 30% 补贴 + 后 50% 退火"的退火窗口有 150 代 ≫ 衰减尺度 20 代 → 必然失败。
   * 正确做法不是靠时间安排躲漂移，而是**给这条分支一条永久的评价通道**。
   * 这里用最便宜的形式：每代评估里固定留 REGEN_SLICE 比例的局带补贴，永不退火。 */
  /* ===== C 方案：脚本教师模仿（千问/用户方向）=====
   * 动机：全随机初始化 + 纯胜负奖励时，网络探索不到"连续攒钱"这类**长轨迹**行为。
   * 做法：训练早期让个体额外模仿一个**有逻辑的脚本教师**（默认 heavyfire = 贵技能专精，
   *   正是"会攒钱"的脚本化身），模仿率给一个**退火到 0** 的奖励；后期完全交给真实胜负。
   * 与"改规则"无关，纯训练侧；也不会固化——退火后教师影响消失，个体必须靠真实胜负站住。 */
  let IMIT_BETA = 0.12;              // 初始模仿奖励权重
  /* ===== v1.5.31（用户选"课程/示范"）：**可配置教师 + 反环教师** =====
   * 实测教训：环奖励三版（常开/退火/密集）要么把训练冻死、要么不触发 —— 根因是
   * "小雷作废开环者"这个动作**历史上从未被出过**（探针实测所有冠军小雷次数 = 0），
   * 而**奖励无法 bootstrap 一个从未发生的动作**。课程法：前 N 代让种群**模仿一个会出小雷的教师**，
   * 把动作先"示范"出来，再交给奖励强化。复用现成的 setImitUntil/imitBetaForGen 退火管道。 */
  /* ===== v1.5.39（用户选 ①）：**定向强制探索** =====
   * 前五次实测（奖励/池子/示范/暴露度/可归因信号）都拿不到"自然小雷" ⇒ 该动作从未被采样到。
   * 这里只在**唯一那一格**做 ε-强迫：**有对手在滚环（ringStreak ≥ 1）且我付得起小雷** ⇒ 强制砸他。
   * 关键：其余任何情形都返回 null（交回**学习到的**策略）—— 不能用教师槽做常开 ε，
   * 那会顺带用 heavyfire 扰动全局（教师退化的默认动作）。
   * **验收必须在关掉强迫后量自然行为**（复核 §5-5：否则 `miniTCasts ≥ 5` 是恒真式）。 */
  let RING_FORCE_EPS = 0;
  /* v1.5.39 修订：**上限提到 1.0**。理由（实测）：目标格（有人真在滚环）只占决策的 **0.15%**
   * ⇒ 在格子里再乘 ε=5% 等于"整跑几乎不强制"（0.0075%），第一臂的 0 是**算术问题**不是证据。
   * 格子本身极罕见 ⇒ **格内 ε=1.0（每次都强制）**才是正确的类比，且不会扰动非目标格。 */
  function setRingForceEps(v) { const x = Number(v); RING_FORCE_EPS = (isFinite(x) && x > 0) ? Math.min(1, x) : 0; return RING_FORCE_EPS; }
  function ringForceEps() { return RING_FORCE_EPS; }
  /* v1.5.40（用户选"继续"）：**强迫必须退火**。
   * 实测（v1.5.39）：格内常开 ε=1.0 会把训练**整体冻死**（6/6 零提升，产物退回种子）；
   * 而 ε=5% 又因目标格极罕见（0.15%）等于没做 ⇒ 正确形态是"**早期强制示范、之后关掉**"，
   * 让最终产物来自**无强迫的后段**，验收才有意义。 */
  /* v1.5.42（用户选 ②）：**探索期标志** —— 由 scoreMemberN 按当前代更新（= 是否在强迫窗口内）。
   * 用途：提升闸门与选择过滤在探索期内**不惩罚**被强迫出来的个体（否则它们全被拒 ⇒ 整臂冻回种子，
   * 实测窗口 20/40/80 的逃逸率只有 0/1/1 个 seed）。窗口外一切照旧。 */
  let IN_EXPLORE = false;

  let RING_FORCE_UNTIL = 0;
  function setRingForceUntil(n) { const x = Number(n); RING_FORCE_UNTIL = (isFinite(x) && x > 0) ? Math.floor(x) : 0; return RING_FORCE_UNTIL; }
  function ringForceUntil() { return RING_FORCE_UNTIL; }
  /* 第 gen 代实际生效的强迫概率（纯函数，便于守门）：只在 < until 的代里生效。 */
  function ringForceEpsAt(gen) {
    if (RING_FORCE_EPS <= 0) return 0;
    if (!RING_FORCE_UNTIL) return RING_FORCE_EPS;      // 未设 until ⇒ 全程（旧行为，仅用于对照）
    return ((gen || 0) < RING_FORCE_UNTIL) ? RING_FORCE_EPS : 0;
  }
  /* 目标格的"该出手"判定：返回要打的环流者 pid，或 -1（不该出手）。纯函数，便于守门。 */
  function ringForceTarget(state, pid, legal) {
    const mt = (legal || []).filter(function (x) { return x.key === R.SK.MINI_T && x.affordable; })[0];
    if (!mt) return -1;
    let best = -1;
    for (let q = 0; q < state.p.length; q++) {
      if (q === pid) continue;
      const pq = state.p[q];
      if (!pq || pq.hp <= 0) continue;
      if ((pq.ringStreak || 0) >= 1 && (best < 0 || pq.ringStreak > state.p[best].ringStreak)) best = q;
    }
    return best;
  }

  let IMIT_TEACHER = null;           // null = 沿用老的 heavyfire 教师
  function setImitTeacher(fn) { IMIT_TEACHER = (typeof fn === 'function') ? fn : null; return !!IMIT_TEACHER; }
  function imitTeacher() { return IMIT_TEACHER; }
  /* v1.5.96：**完整动作**的教师调用 —— `teacherAction` 只回 key，而覆盖时必须带 target。 */
  function teacherFull(botFn, state, pid, legal) {
    try {
      const r = botFn(state, pid, legal);
      if (typeof r === 'string') return { key: r, target: null };
      return r || null;
    } catch (e) { return null; }
  }
  /* v1.5.96：**真示范**开关（默认关 ⇒ 行为一字不变）。用法与理由见 `makeEconChooser` 里的长注释。 */
  let IMIT_OVERRIDE = false;
  function setImitOverride(on) { IMIT_OVERRIDE = !!on; return IMIT_OVERRIDE; }
  /* v1.5.96：按**名字**选教师（`EPIRUS_IMIT_TEACHER=ringspam` 之类）。
   * 名字→函数的映射**留在这个文件里**，免得 server / worker 各写一份清单（本仓库为这种"两处各写一遍"栽过四次）。 */
  function setImitTeacherByName(name) {
    if (!name) return false;
    const n = String(name).trim();
    if (n === 'antiring') return setAntiRingTeacher();
    if (BOT_PICKS && typeof BOT_PICKS === 'object' && typeof BOT_PICKS[n] === 'function') {
      IMIT_TEACHER = BOT_PICKS[n];
      return true;
    }
    /* v1.5.96：也接受**全局 bot 注册表的函数名**（`pickRingSpam` 之类）。
     * 为什么必须留这条路：环专精 **不在 `BOT_PICKS` 里** —— 那张表是"对手池"的注册表
     * （`buildOpps` 与若干诊断循环都 `Object.keys(BOT_PICKS)`），往里加键会**改默认训练**
     * ⇒ 拿环当教师只能走全局注册表，且**默认池一字不动**。 */
    const G = (typeof global !== 'undefined' && global && global.EpirusBots) || null;
    if (G && typeof G[n] === 'function') { IMIT_TEACHER = G[n]; return true; }
    return false;
  }

  /* 反环教师：有对手 ep ≥ 2（正在攒环/够小雷）且我付得起小雷 ⇒ 打他一记小雷；否则交给基础策略。 */
  function makeAntiRingTeacher(baseFn) {
    return function (state, pid, legal) {
      const mt = (legal || []).filter(function (x) { return x.key === R.SK.MINI_T && x.affordable; })[0];
      if (mt) {
        let best = -1;
        for (let q = 0; q < state.p.length; q++) {
          if (q === pid) continue;
          const pq = state.p[q];
          if (!pq || pq.hp <= 0) continue;
          /* v1.5.37（复核 §5-2）：条件是 `ep >= 2` 时在真实自对局里 **45%** 的决策都成立，
           * 而"有人真在滚环"只有 **0.15%** ⇒ 教师实际在教"见人兜里有 2 ジ就砸小雷"。
           * 改成 `ringStreak >= 1`（该座真的在连开聚能环）⇒ 示范的动作才与"开环"这个状态相关。 */
          if ((pq.ringStreak || 0) >= 1 && (best < 0 || pq.ringStreak > state.p[best].ringStreak)) best = q;
        }
        if (best >= 0) return { key: R.SK.MINI_T, target: best };
      }
      return baseFn(state, pid, legal);
    };
  }
  /* 装成"反环教师"（基础策略用 heavyfire，与老的模仿教师一致） */
  function setAntiRingTeacher() { return setImitTeacher(makeAntiRingTeacher(BOT_PICKS['heavyfire'])); }

  let IMIT_UNTIL = 0;                // 退火代数（由 setImitUntil 设置；0=关闭）
  function setImitUntil(n) { IMIT_UNTIL = Math.max(0, Math.floor(n) || 0); }
  /* ===== v1.5.97：**分段教师计划**（两段课程）=====
   * 动因（v1.5.96 §7 的机制结论）：一次性用"开环教师"无效 —— 环**恒不可负担**、教师够不着；
   * 先用"攒钱教师"把 ep 攒起来（已证可行：`ep≥3` 从 0.0% → 12.6 / 9.5 / 40.1%），
   * **第二段**再换"开环教师"，此时环才可负担 ⇒ 示范才落在环上。
   * 口径：`EPIRUS_IMIT_PLAN="教师名:占比,教师名:占比"`（占比之和≈1），在 `[0, IMIT_UNTIL)` 内切段；
   * **每段各自线性退火**（β 从 IMIT_BETA 降到 0）⇒ 第二段会**重新**施加示范压力。
   * 不设 plan ⇒ 行为与旧版**逐位相同**（单教师 + 单一退火窗）。
   * 解析**只写这一份**：`setImitPlanByName(spec, totalGens)` 供 server 与 worker **共用**（今晚的教训）。 */
  let IMIT_PLAN = null;              // [{start, until, teacher, name}]
  function setImitPlan(segs) {
    IMIT_PLAN = (Object.prototype.toString.call(segs) === '[object Array]' && segs.length) ? segs : null;
    return IMIT_PLAN ? IMIT_PLAN.length : 0;
  }
  function imitPlanSegment(gen) {
    if (!IMIT_PLAN) return null;
    for (let i = 0; i < IMIT_PLAN.length; i++) {
      const s = IMIT_PLAN[i];
      if (gen >= s.start && gen < s.until) return s;
    }
    return null;
  }
  function imitTeacherForGen(gen) {
    const s = imitPlanSegment(gen);
    return s ? s.teacher : IMIT_TEACHER;
  }
  /* ===== v1.5.98：**只示范目标卡**（`onlyKey`）=====
   * 动因（v1.5.97 §4 的机制结论）：两段课程里第二段把第一段教出来的"攒"抹掉了。
   * 机制：override 在**环不可负担时**也会拿教师的动作覆盖 —— 而教师的 fallback（蓄能/ジ）是短视的，
   * 于是每次覆盖都在把策略往"不攒、随手出牌"推。
   * ⇒ 让示范**只在教师真要教那张卡时**才生效（覆盖与奖励计数**都**过滤）：
   *   只对"环"计一致性/做覆盖 ⇒ fallback 不再覆盖策略自己的好动作 ⇒ 第一段的成果不被回冲。
   * 默认 `null` = 不过滤（行为与旧版逐位相同）。可全局设（`EPIRUS_IMIT_ONLY`），
   * 也可**按段**设在计划里：`EPIRUS_IMIT_PLAN="pickDeepSaver:0.5,pickRingSpam:0.5:ring"`。 */
  let IMIT_ONLY = null;
  function setImitOnly(k) {
    if (k == null || k === '') { IMIT_ONLY = null; return null; }
    /* v1.8.23：也接受逗号列表（爆珠链同时教 charge 与 laserEye）。 */
    const keys = String(k).split(',').map(function (s) { return s.trim(); }).filter(Boolean);
    if (!keys.length) { IMIT_ONLY = null; return null; }
    for (const key of keys) if (!R.byKey[key]) throw new Error('[imit] EPIRUS_IMIT_ONLY 不是一张合法的卡：' + key);
    IMIT_ONLY = keys.join(',');
    return IMIT_ONLY;
  }
  function imitOnlyForGen(gen) {
    const s = imitPlanSegment(gen);
    if (s && s.only) return s.only;
    return IMIT_ONLY;
  }
  /* v1.5.99：`IMIT_SUB_ONLY` —— 见 `makeEconChooser` 里的长注释（只对设了 only 的示范生效）。 */
  let IMIT_SUB_ONLY = false;
  function setImitSubOnly(on) { IMIT_SUB_ONLY = !!on; return IMIT_SUB_ONLY; }
  /* ===== v1.5.141（DS 研究 · `docs/research/logs/RESEARCH-LOG-2026-09-21-ds.md` §5）：**补贴局里连"珠"一起补**（默认关）=====
   * 病（本日实测，臂 `v7bead1`）：v1.5.99 的补贴局补贴的是 **ep**（白来的 ep），而"电磁炮"还需要 `elec:1`
   * ⇒ 它在补贴局里**仍然不可负担** ⇒ v1.5.96 那条"只在教师动作**确实可负担**时才覆盖"的示范
   * **永远示范不到"放炮"** —— 93 粒的读数（蓄能 5 次、得珠 5 颗、全过期、放炮 **0**）正是这条机制的形状。
   * 打开它 = 在补贴局里给**受评席**每回合补一颗珠 ⇒ "放炮"随时可示范（配 `IMIT_SUB_ONLY` + `only=railgun`
   * 就能只教这一张卡）。⚠️ **只补受评席**（不动对手席 ⇒ 不改变补贴局的对手行为）；
   * **只影响 `regen>0` 的补贴局** ⇒ 原生考卷/体检/五道门读数不受影响。
   * `evo.js` **不在** `FINGERPRINT_FILES` ⇒ 零重记成本（这是选在这里做的主要原因）。 */
  let SUB_BEAD = false;
  function setSubBead(on) { SUB_BEAD = !!on; return SUB_BEAD; }
  function subBeadOn() { return SUB_BEAD; }
  /* ===== v1.5.143（状态分布塑形 · DS §5 提案过未跑，0921 午班接手）=====
   * 假说：珠线失败的瓶颈**不是价格**（0921 实测：`BEAD_W` 0.15/0.25/0.5/1.0 四档 × 三 seed 的长程电磁炮
   * 频率是彩票表，1.0 档连"蓄能"都归零 ⇒ 标度连单调都不是），而是**两回合序列的信用分配**：
   * 蓄能当回合 0 伤害、珠只活到下一回合末 ⇒ 中间那一回合被"按即时伤害/密度给钱"的主梯度惩罚。
   * 这条旋钮把序列**降成一回合**：以概率 p 让普通训练局（`regen=0`，即**非补贴局**，与 `SUB_BEAD` 通道互不干扰）
   * **开局**就给全部席位一颗电珠 + 至少 2 ジ ⇒ 电磁炮在**第一个决策**就可负担、放炮的回报当场计入 fit。
   * ⚠️ **对称注入**（全席都给，不是只给受评席）：只给受评席等于把"有珠"和"这一席更强"混在一起，
   *    会漏进座位身份通道（本仓 D50/D58 家族的老形状）；对称则只改变**状态分布**、不改变席位间的相对关系。
   * 默认 0 = 逐字不变（不设 env ⇒ 训练/门禁读数一字不动）。 */
  let BEAD_SEED = 0;
  function setBeadSeed(v) {
    const n = Number(v);
    BEAD_SEED = (isFinite(n) && n > 0) ? Math.min(1, n) : 0;
    return BEAD_SEED;
  }
  function beadSeedOn() { return BEAD_SEED; }
  /* ===== v1.8.37（10-25 ZCode · 激光眼移植批 §二十一）：珠塑形的**珠种档**（默认 'elec' ⇒ 逐字不变）=====
   * 病：`BEAD_SEED` 自 v1.5.143 起只发**电珠**——它成牌的是电磁炮（v1.5.144 首例）；
   * 激光眼的前置件是**爆珠**（首次 = 1ジ + 1 爆珠，state.js:152-153），电珠塑形对它连分母都不给
   * ⇒ §E734 否证的"BEAD_SEED=0.5"那一根，否的是电珠档；爆珠档从未被试过。
   * 语义：kind='boom' 时同一钩子同一概率改发爆珠（ep 抬到 ≥2 不变、全席对称不变、rng 消耗不变）。
   * 只认 'elec' / 'boom' 两个值，别的**响亮拒**（与 TRAIN_MODE 的 exit 7 纪律同族：不许静默落回默认档）。 */
  let BEAD_SEED_KIND = 'elec';
  /* ===== v1.8.37 夜班续（10-26 千问 §E763）：补贴局的**珠种** =====
   * 缺省 elec ⇒ `subBeadHook` 逐字保持 v1.5.141 的行为（DS 当年为电磁炮铺的是电珠）。
   * boom 那一档把同一颗珠换成爆珠 ⇒ 激光眼（首次 1ジ + 1 爆珠）在**补贴局**里随时可负担，
   *   而补贴局正是示范通道（`IMIT_OVERRIDE` 只在那里覆盖受评席）能落到"打出去"的那一段。
   * ⚠ 与 `EPIRUS_SUB_BEAD` 那根布尔分家：布尔走 worker 消息、珠种走 econ 单一来源 ⇒
   *   **只设珠种不设布尔 = 钩子不进**（读回照样印 boom，所以"读到"不等于"生效"，臂上要看 `subBeadOn()`）。 */
  let SUB_BEAD_KIND = 'elec';
  function setSubBeadKind(k) {
    if (k !== 'elec' && k !== 'boom') throw new Error('setSubBeadKind: 只认 \'elec\'/\'boom\'，收到 ' + JSON.stringify(k));
    SUB_BEAD_KIND = k;
    return SUB_BEAD_KIND;
  }
  function subBeadKind() { return SUB_BEAD_KIND; }
  function setBeadSeedKind(k) {
    if (k !== 'elec' && k !== 'boom') throw new Error('setBeadSeedKind: 只认 \'elec\'/\'boom\'，收到 ' + JSON.stringify(k));
    BEAD_SEED_KIND = k;
    return BEAD_SEED_KIND;
  }
  function beadSeedKind() { return BEAD_SEED_KIND; }
  function imitBetaForGen(gen) {
    if (IMIT_PLAN) {
      const s = imitPlanSegment(gen);
      if (!s) return 0;
      const span = Math.max(1, s.until - s.start);
      return IMIT_BETA * Math.max(0, 1 - (gen - s.start) / span);   // **每段各自**线性退火
    }
    if (!IMIT_UNTIL || gen >= IMIT_UNTIL) return 0;
    return IMIT_BETA * (1 - gen / IMIT_UNTIL);      // 线性退火（旧口径，不设 plan 时逐位不变）
  }
  /* 按名字建计划（唯一一份解析；server 与 worker 都调它）。
   * `spec` = "name:frac,name:frac"；`totalGens` = 示范窗总代数（= IMIT_UNTIL）。
   * 片段无法解析 / 名字解析不出来 ⇒ **抛错**（不许静默退回默认教师 —— `v7stock1` 的教训）。 */
  function setImitPlanByName(spec, totalGens) {
    const txt = String(spec == null ? '' : spec).trim();
    if (!txt) return setImitPlan(null);
    const parts = txt.split(',').map(function (p) { return p.trim(); })
      .filter(function (p) { return p.length > 0; });
    const total = Math.max(1, Math.floor(Number(totalGens) || 0));
    const segs = [];
    let at = 0, acc = 0;
    for (let i = 0; i < parts.length; i++) {
      const m = /^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*([0-9]*\.?[0-9]+)(?:\s*:\s*([A-Za-z_][A-Za-z0-9_]*|\*))?$/.exec(parts[i]);
      if (!m) throw new Error('[imit] 计划片段无法解析：' + JSON.stringify(parts[i]) +
        '（应形如 pickDeepSaver:0.5 或 pickRingSpam:0.5:ring；第三段 = 只示范哪张卡，`*` = 不过滤）');
      const name = m[1], frac = Number(m[2]);
      const only = (!m[3] || m[3] === '*') ? null : m[3];
      if (only && !R.byKey[only]) throw new Error('[imit] 计划里的 only 不是一张合法的卡：' + only);
      if (!(frac > 0)) throw new Error('[imit] 计划片段占比必须 > 0：' + parts[i]);
      const until = (i === parts.length - 1) ? total
        : Math.min(total, Math.max(at + 1, Math.round(total * (acc + frac))));
      let teacher = (name === 'antiring') ? makeAntiRingTeacher(BOT_PICKS['heavyfire']) : null;
      if (!teacher && BOT_PICKS && typeof BOT_PICKS[name] === 'function') teacher = BOT_PICKS[name];
      if (!teacher) {
        const G = (typeof global !== 'undefined' && global && global.EpirusBots) || null;
        if (G && typeof G[name] === 'function') teacher = G[name];
      }
      if (!teacher) {
        throw new Error('[imit] 计划里的教师名字解析失败：' + name +
          '（可用：antiring / BOT_PICKS 的键 / 全局注册表函数名，如 pickRingSpam、pickDeepSaver）');
      }
      segs.push({ start: at, until: until, teacher: teacher, name: name, only: only });
      at = until; acc += frac;
    }
    if (segs.length && segs[segs.length - 1].until < total) segs[segs.length - 1].until = total;
    return setImitPlan(segs);
  }
  /* 脚本教师的一句话决策（供模仿比对用） */
  function teacherAction(botFn, state, pid, legal) {
    try {
      const r = botFn(state, pid, legal);
      return (typeof r === 'string') ? r : (r && r.key) || null;
    } catch (e) { return null; }
  }

  /* v1.5.177（DS）：补贴率从**硬编码常量**变成可下达的旋钮 ——
   * 动因（数据）：全卡边际扫描证明"钱是系统性的墙"（long 里只有 59%/18%/3% 的回合买得起 1/2/3 费，
   * multi 更紧：30 张卡里 0 张可测）；而"给钱+教卡"的双侧实验**必须先能调"给多少钱"**。
   * 默认仍是 0.08 ⇒ 不下达时逐位等于旧行为；非法值原样返回（宿主据此判"被拒"）。 */
  let REGEN_SLICE = 0.08;   // 每 12 局留 1 局（约 8%）带补贴
  function setRegenSlice(v) {
    const n = Number(v);
    if (!isFinite(n) || n <= 0) return REGEN_SLICE;
    REGEN_SLICE = Math.min(1, Math.max(0.01, n));
    return REGEN_SLICE;
  }
  function regenSlice() { return REGEN_SLICE; }
  function regenForGen(gen) { return 0; }   // 兼容旧入口；回放切片按局索引走
  function setRegenTotal(n) { /* 保留兼容：回放切片不再依赖总代数 */ }
  function regenForGame(g, games, gen) {
    /* v1.7.158：地板只留**一处**（`sliceHit` 里那句 `Math.max(2, …)`，`:111`）。原来这里也夹一次 ⇒ 门禁审查第十二批的
     *   变异实测："单点摘掉不红、两点同时摘才红" ⇒ 那枚地板看着有两条守门人，实际谁都不独占它（本仓"两处各写一遍"那一族）。
     *   行为逐字不变：`setRegenSlice` 把切片夹在 [0.01,1] ⇒ `Math.round(1/切片)` ∈ [1,100]，只有切片=1 那一档落到地板（1⇒2），
     *   而那一档两处算法给同一个数 ⇒ D132 的三档密度读数（0.08⇒10 ‖ 0.5⇒60 ‖ 0.01⇒2）与改前必须一模一样。 */
    return sliceHit(g, Math.round(1 / REGEN_SLICE), gen) ? 2 : 0;   // v1.5.186：相位按代旋转（原来 `g % step` 与 `seat = g % n` 会锁死）
  }

  /* ===== 承诺级 ε（千问方案）=====
   * 动作级 ε 靠多次独立抽样撞运气才能走完 3~5 回合的连续攒钱轨迹；
   * 承诺级 ε 每局抽一个"储蓄视界 h"，规定 ep < 1+h 时只准出 ジ —— 轨迹被**真正走到**。 */
  function makeCommitChooser(params, temp, h) {
    const inner = policyChooserN(params, temp, 0);
    return function (state, pid, legal) {
      if (h > 0 && state.p[pid] && state.p[pid].ep < 1 + h) {
        for (let i = 0; i < legal.length; i++) {
          if (legal[i].key === R.SK.JI && legal[i].affordable) return { key: R.SK.JI, target: null, target2: null };
        }
      }
      return inner(state, pid, legal);
    };
  }

  /* Tolerance band (multi-objective selection). 0.01 = tightened for the 3P head-to-head
   * issue; 0.03 = the div555-era value (wider band -> more diverse pick).
   * Qianwen's review: this used to be read from an environment variable INSIDE
   * the sandbox (naming it here would trip the L3 lint).
   * That is wrong on two counts: (a) the CLI sandboxes have no `process`, so they ALWAYS got
   * the default 0.03; (b) the server sandbox may or may not expose `process`, so the SAME
   * constant could differ between the two paths. It is now an explicit parameter set by the
   * caller (server / CLI), never a hidden env read inside the engine. */
  let WR_TOL = 0.03;
  function setWrTol(v) { const n = Number(v); if (isFinite(n) && n >= 0) WR_TOL = n; }

  /* ===== v7（v1.5.19）：**自对局健康**（单一真源）=====
   * 为什么需要：单一 1st 率能被"熬"骗（REVIEW §11：long-33 靠 20/20 局零伤害平局拿到 45.3%）。
   * v7 加完特征后这件事变严重了 —— 实测 12 个 seed 里分最高的几个（48.4% / 45.3%）在**自对局**里
   * 只剩 1~2 张卡、打到 54~60 回合（G=1.00~1.66），而 `champ-audit` 的 G 列正是这么量出来的。
   * ⇒ 把"自对局行为形状"做成**换冠军的硬门槛**，并且**与 tools/audit-lib.mjs 的 G 列共用这一份实现**
   * （两处各写一遍必出事：docs/METHODOLOGY.md 第 13 条）。
   * 指标：effSkills = exp(非ジ出手分布的熵)（"有效技能数"）、drawRate（全员存活率）、rounds。
   * 反证（np-test D35）：把门槛关掉（setHealthGate({on:false})）或用不可能阈值，D35 必须红。 */
  let HEALTH = { on: true, games: 20, promoteGames: 8, n: 5, minG: 3, maxDraw: 0.2, maxRounds: 40 };
  /* ===== v1.5.19（方向 A）：把**自对局**折进适应度 =====
   * 为什么需要：健康门槛只"筛"不"教" —— 实测只筛时 6/7 个 seed 被拦回"健康但弱"的角落（考卷 15.8%），
   * 因为训练器优化的始终是"对脚本的 1st 率"，而退化（G≈1、50~60 回合）在**自对局**里才显形。
   * 做法：每个个体额外打 MIRROR_GAMES 局"n 座同一策略"，把这几局的**非ジ动作直方图并进同一个
   * `agg.use`** ⇒ 已有的覆盖熵项（divNorm，权重 DIV_W）自然把"自对局里只剩两三张卡"的个体压低。
   * **胜负名次一项都不折**（镜像局的第 1 名是轮盘，没有信息），也不动伤害/回合口径。
   * 反证（np-test D36）：MIRROR_GAMES=0 与 =2 的 divNorm 必须不同，而 first/games **必须逐位相同**。 */
  /* ===== v1.5.23（用户裁定）：**教它惩罚开环的人** =====
   * 起因：用户实测"对手连开 9 回合聚能环把ジ刷到 +3/回合，四个冠军座位零反应"；
   * 而项目两次把 `ringspam` 放进池子的实验都判定"池子是弱杠杆"（第三次同型结论见 CHANGELOG v1.5.20）⇒
   * 真正缺的是**信用分配**：把"对手在开环时我打断了他"变成一条**窄条件、可归因**的奖励。
   * 怎么在不改引擎的前提下侦测"对手在开环"：环每回合多发 **+2/+3 ジ**（R10）⇒ 一次 `ep` 事件
   * 的 `delta ≥ 2` 且不是我 ⇒ 这个对手正在开环。同一回合里**我**打中他、或用小雷作废了他的招 ⇒ 记一次打断。
   * 权重刻意取小（默认 0.04，两次打断满额）⇒ 不改变主目标（胜负），只做方向性引导。
   * 反证（np-test D39）：把 ringBreaks 记账删掉 / 权重设 0 ⇒ D39 立刻红。 */
  /* ===== v1.5.25（用户选 ①）：**惩罚被动**的窄奖励 =====
   * 起因：v7anneal-34 在"被动场"里 E=100%（对手只出ジ时，它也只会堆架势）⇒ 体检被判"集体防御"。
   * 判据（纯事件层，不动引擎）：把一局按回合分组（**每回合每玩家最多一条 `action` 事件**，
   * 于是"又看到某个 pid 的 action"就是新回合），记"我这个回合打中了、且这一回合一点没挨打"的回合数。
   * 奖励 `PRESS_W × min(1, 主动回合数/3)`（默认 0.03）——只奖"对手没威胁时我还在推进"，不奖乱打。 */
  /* ===== v1.5.29（第三方复核 §5-1，用户选 b）：**破墙奖励** =====
   * 起因（实测）：v1.5.27 的冠军在自对局里 G 6.55 很漂亮，但在 4 面反弹墙前**一枪未发**
   * （穿透卡命中 0），长程反弹墙 85% -> 0% —— 它把唯一能穿反弹的激光剑这条线整个丢了。
   * 做法：窄条件（**只认能穿反弹/穿防御的卡**，清单从 R.skills 推导）+ 可归因（damage.source === seat）
   * => PIERCE_W x min(1, 命中数/2)，默认 0.04（两次封顶）。清单不硬编码 => 规则改了自动跟着变。 */
  let PIERCE_W = 0.04;
  function setPierceReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) PIERCE_W = v; return PIERCE_W; }
  function pierceReward() { return { w: PIERCE_W, keys: pierceKeyList() }; }
  /* v1.8.39：破反弹墙奖励的 setter/getter（键表由规则数据推导 ⇒ 规则改了自动跟着变）。 */
  function setWallBreakReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) WALL_BREAK_W = v; return WALL_BREAK_W; }
  function wallBreakReward() { return { w: WALL_BREAK_W, keys: wallBreakKeyList() }; }
  function reflectReward() { return { w: REFLECT_W, stat: { games: REFLECT_STAT.games, max: REFLECT_STAT.max, paid: REFLECT_STAT.paid } }; }
  function beadWasteReward() { return { w: BEAD_WASTE_W, stat: { games: BEAD_WASTE_STAT.games, max: BEAD_WASTE_STAT.max, paid: BEAD_WASTE_STAT.paid } }; }
  /* 能穿反弹/穿防御的卡（从规则数据推导：激光剑/坦克/狙击枪/电磁炮） */
  function pierceKeyList() {
    return (R.skills || []).filter(function (sd) {
      const pp = sd.pierce || {};
      return !!(pp.reflect || pp.defense);
    }).map(function (sd) { return sd.key; });
  }
  /* v1.8.39：穿**反弹**的卡（规则数据推导：激光剑/狙击枪/电磁炮；坦克不穿反弹 ⇒ 不进这张表）。 */
  function wallBreakKeyList() {
    return (R.skills || []).filter(function (sd) { return !!(sd.pierce && sd.pierce.reflect); }).map(function (sd) { return sd.key; });
  }
  /* 纯函数：数我用「穿反弹卡」**落地命中**的次数（守门/量具可直接喂事件序列）。 */
  /* 纯函数：数"我这席**过期掉的珠**"的事件条数（事件 = js/core/resolve.js:1302 的 {type:'beadExpire', pid, kind, n}）。 */
  function countBeadExpiredEvents(events, seat) {
    let n = 0;
    for (const e of (events || [])) { if (e.type === 'beadExpire' && e.pid === seat) n++; }
    return n;
  }
  /* 纯函数：数"我把伤害**弹回去**"的总量（事件 = js/core/resolve.js 的 {type:'reflect', to, amt}）。 */
  function countReflectAmt(events, seat) {
    let d = 0;
    for (const e of (events || [])) { if (e.type === 'reflect' && e.to === seat) d += (e.amt || 0); }
    return d;
  }
  /* 纯函数（A 案）：数"我打在**本回合正在摆防御的目标**身上的落地伤害"。
   * 回合切法沿用 voidScan：同一个 pid 再次 action = 新回合；只认 outcome==='ok' 的行动。 */
  function countGuardHits(events, seat) {
    let cur = -1; let seen = {}; const rounds = [];
    for (const e of (events || [])) {
      if (e.type === 'action') {
        if (cur < 0) cur = 0;
        else if (seen[e.pid] !== undefined) { seen = {}; cur++; }
        seen[e.pid] = true;
        if (!rounds[cur]) rounds[cur] = { guard: {}, dmg: {} };
        if (e.outcome === 'ok' && R.GUARD_FAMILY.indexOf(e.key) >= 0) rounds[cur].guard[e.pid] = true;
      } else if (e.type === 'damage') {
        if (cur < 0 || e.to == null || e.source !== seat) continue;
        if (!rounds[cur]) rounds[cur] = { guard: {}, dmg: {} };
        rounds[cur].dmg[e.to] = (rounds[cur].dmg[e.to] || 0) + (e.amt || 0);
      }
    }
    let hits = 0, amt = 0;
    for (const r of rounds) {
      if (!r) continue;
      for (const k in r.dmg) if (r.guard[k]) { hits++; amt += r.dmg[k]; }
    }
    return { hits: hits, amt: amt };
  }
  function guardHitReward() { return { w: GUARD_HIT_W, stat: { games: GUARD_HIT_STAT.games, max: GUARD_HIT_STAT.max, paid: GUARD_HIT_STAT.paid } }; }
  function countWallBreakHits(events, seat) {
    const wk = wallBreakKeyList();
    let n = 0;
    for (const e of (events || [])) { if (e.type === 'damage' && e.source === seat && e.via && wk.indexOf(e.via) >= 0) n++; }
    return n;
  }
  /* v1.8.39b：同一件事按**伤害量**数（v1.8.39 的 /1 命中数第 0 代就吃满 ⇒ 退化成常数，实测 R0/R3/R6 已否证）。
   *   伤害天然连续 ⇒ 不饱和、有梯度；上限 4 点（与 DEAL_W 的 /4 同尺度）。 */
  function wallBreakDamage(events, seat) {
    const wk = wallBreakKeyList();
    let d = 0;
    for (const e of (events || [])) { if (e.type === 'damage' && e.source === seat && e.via && wk.indexOf(e.via) >= 0) d += (e.amt || 0); }
    return d;
  }
  /* 纯函数：数我用穿透卡**落地命中**的次数（便于守门做行为断言） */
  function countLaserHits(events, seat) {
    let n = 0;
    for (const e of (events || [])) {
      if (e.type === 'damage' && e.source === seat && e.via === R.SK.LASER_EYE) n++;
    }
    return n;
  }
  function countPierceHits(events, seat) {
    const pk = pierceKeyList();
    let n = 0;
    for (const e of events) {
      if (e.type === 'damage' && e.source === seat && e.via && pk.indexOf(e.via) >= 0) n++;
    }
    return n;
  }

  /* 纯函数：数我**花掉**蓄能珠的次数（v1.5.76 P1）。
   * 真源 = `{type:'bead', pid, kind:'elec'|'boom', delta}`：得珠 `delta:+1`、花掉 `delta:-1`
   * （state.js 的扣珠处与蓄能得珠处各发一条）。**只认花掉** —— 攒着不用、让它过期，都不记分。 */
  function countBeadSpent(events, seat, kind) {
    let n = 0;
    for (const e of (events || [])) {
      /* v1.8.37 夜班续：`kind` 给了就只数那一种珠（花费侧 `js/core/state.js:227/228` 两条事件都自带 kind ⇒
       * 读现成字段，不改 core）。不给 = 数全部 = v1.5.76 原义逐字不变。 */
      if (e.type === 'bead' && e.pid === seat && (e.delta || 0) < 0 && (!kind || e.kind === kind)) n++;
    }
    return n;
  }
  /* ===== v1.5.79（第七轮复核 §15-1）：把"**优先打威胁**"当能力奖 =====
   * 复核的机制发现：池子里**没人会瞄人**（脚本走 `pickTargetN`：能打死→血最多；v7 冠军能瞄但没被奖励过）
   * ⇒ 所谓"狙击专精"其实是**池子漏洞**：给 4 席加一条"谁放冷枪就打谁"的一行规则，v17-146 的 A 考卷 30% → **0%**。
   * 这与环课题的关键区别（也是它这次**有戏**的理由）：环的出手率是 **0**（奖励再大也 bootstrap 不到），
   * 而"打威胁者"**已经在发生**（复核实测靶向率 22.5% ≈ 随机 25%）⇒ 窄奖励能给**已有的偶然行为**定向加压。
   * 判据全部来自事件（不猜字段）：威胁 = 上一回合 q 出过 `pierce.*` 类或 `ring`，或上一回合 q 造成 ≥2 伤害；
   * 计分 = 我这一回合**打在威胁者身上**的**不同受击者数**（`e.source === seat`，两次封顶 ⇒ 奖励广度而非堆叠）。 */
  let TGT_W = 0;                       // 默认关：实验臂用 EPIRUS_TGT_W 打开
  function setTargetReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) TGT_W = v; return TGT_W; }
  /* v1.8.23（10-23 用户裁定「爆珠两个都可以试试」）：**激光眼命中**奖励（默认 0，实验臂用 EPIRUS_LASER_W 开）。
   *   口径 = 本局 laserEye **造成的光伤次数**（非防御时就是 1 点；防御时 0 伤害但无效化仍由 D100 族记账）。
   *   标度同 TGT：/1 封顶 ⇒ 0 次 0 分、1 次吃满，方差大 ⇒ 真有梯度。 */
  /* 默认 0；宿主（train-server / train-worker / train-3p）读 `EPIRUS_LASER_W` 后走 setter 注入。
   *   ⚠ 不许在 js/ 里字面读 `process.env.*`（D122 的暗键守卫：js 只许字面读声明过的引擎键）。 */
  let LASER_W = 0;
  function setLaserReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) LASER_W = v; return LASER_W; }
  function laserReward() { return LASER_W; }
  /* ===== v1.8.29（用户裁定 10-23「失效技能应该都要给奖励」+「激光眼打中防御同时刚好有另一个人攻击，
   *   给比一般命中更高的奖励，看看冠军能不能摸索出这个」）=====
   * 两个计数全部从事件推导，不猜卡名：
   *   · 一次**失效成功** = `voided` 且 `byPid === 我`（第 4 参本来就是 v1.5.37 为归因加的）
   *     且**被废的不是 ジ**（`voids` = 本次新落的字段，写入点只有 `resolve.js` 里 `setVoid` 那一处）
   *     ⇒ 激光眼破防、激光眼破转移、小雷废掉对面的攻击卡都算；小雷废掉一张 ジ 不算（用户明确排除）。
   *   · **理想情况** = 这次废掉的是**防御族**（`R.GUARD_FAMILY`，从 rules.js 取表 ⇒ 规则改了自动跟着变），
   *     且**同一回合**该目标还挨了**别人**一刀（`damage.source ∉ {null, 我}`）⇒ 我把盾敲掉、别人的伤真落地。
   *     只认落地的 `damage`、不认 `blocked`：那一刀被挡掉说明我的破防什么也没换来。
   * ⚠ 回合边界沿用 `countThreatHits` 的既有口径（**同一个 pid 再次 `action` = 新回合**）；连接必须**两趟**：
   *   破防与别人的那刀谁先落在流里不固定（按优先级结算），所以先攒齐整回合再判 —— 单趟边扫边判会漏掉
   *   "我先破防、后面那一刀才落地"这一半，而那正是用户点名的形状。
   * ⚠ **出厂默认 = `VOID_W 0.05` / `VOID_IDEAL_W 0.10`**（用户 10-27 15:5x：「这玩意早就要开了，应该先开着再找
   *   激光眼，不然偶然出现的激光眼没有奖励就又训练没了」）⇒ 奖励必须**先于行为存在**，否则稀事件拿不到梯度。
   *   env `EPIRUS_VOID_W` / `EPIRUS_VOID_IDEAL_W` 仍可覆盖；**两档都设 0 ⇒ 与 v1.8.40 逐位相同**（对照臂用）。
   *   （**不学 v1.8.23 的激光眼**：它在 train-server / train-worker / train-3p 各读一次 env，
   *    正是这个文件开头记载的"A/A 事故"形状的第 N 次复发。） */
  let VOID_W = 0.05, VOID_IDEAL_W = 0.10;
  function setVoidReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) VOID_W = v; return VOID_W; }
  function setVoidIdealReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) VOID_IDEAL_W = v; return VOID_IDEAL_W; }
  function voidReward() { return { w: VOID_W, idealW: VOID_IDEAL_W }; }
  /* 单趟扫描攒齐回合、末尾连接 ⇒ 两个计数一次算齐（两份"重建回合"= 两套口径，这里只留一处写入）。 */
  function voidScan(events, seat) {
    const rounds = [];
    const hits = [];
    let seen = {}, cur = -1;
    for (const e of (events || [])) {
      if (e.type === 'action') {
        if (cur < 0) cur = 0;
        else if (seen[e.pid] !== undefined) { seen = {}; cur++; }
        seen[e.pid] = true;
        if (!rounds[cur]) rounds[cur] = {};
      } else if (e.type === 'damage') {
        if (cur < 0 || e.to == null || e.source == null) continue;
        if (!rounds[cur]) rounds[cur] = {};
        const rr = rounds[cur][e.to] || (rounds[cur][e.to] = {});
        rr[e.source] = (rr[e.source] || 0) + (e.amt || 0);
      } else if (e.type === 'voided') {
        if (e.byPid !== seat) continue;
        const v = e.voids;
        if (!v || v === R.SK.JI) continue;
        hits.push({ r: cur, to: e.pid, guard: R.GUARD_FAMILY.indexOf(v) >= 0 });
      }
    }
    let ideal = 0;
    for (const h of hits) {
      if (!h.guard || h.r < 0) continue;
      const d = rounds[h.r] && rounds[h.r][h.to];
      if (!d) continue;
      for (const q in d) if (Number(q) !== seat && d[q] > 0) { ideal++; break; }
    }
    return { wins: hits.length, ideal: ideal };
  }
  function countVoidWins(events, seat) { return voidScan(events, seat).wins; }
  function countVoidIdeal(events, seat) { return voidScan(events, seat).ideal; }
  /* ===== v1.5.103（v1.5.100 §20）：**清场计数**奖励（默认关，实验臂用 `EPIRUS_CLEAR_W` 打开）=====
   * 口径**必须与门禁同源**（`tools/audit-lib.mjs` 场B 那一段）：
   *   ① 分界是**收缩开始** —— 收缩的伤 `source == null`（不可格挡），它之后的死者**不算**清场；
   *   ② 新规则下"打 1 点就能在全灭判胜里赢" ⇒ **胜率不作判据**（第五轮复核 §2-1）。
   * ⚠️ `death` 事件**不带凶手**（只有 `pid`/`reason`）⇒ 只能自己维护"最后一次伤害来源"来归因；
   *    不归因就等于奖励"别人把场子清了"（在 5 席同策略自对局里那是白送分）。 */
  let CLEAR_W = 0;
  function setClearReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) CLEAR_W = v; return CLEAR_W; }
  function clearReward() { return { w: CLEAR_W }; }
  /* ===== v1.5.121（第十三轮复核 §23 的 **E4**）：**挡下伤害**计数奖励（默认关；实验臂用 `EPIRUS_BLOCK_W` 打开）
   * 事件口径（只认"真的挡掉/弹走"，**不认摆架势**）：
   *   · `{type:'blocked', to: seat}` —— 防御 / 反弹 / 原型制御 / 金刚盾 / 八卦阵 / 藤甲 / 全息 挡下；
   *   · `{type:'reflect', to: seat}` —— 反弹与原型制御把伤害**弹回**给施法者（也算"我挡住了"）。
   * ⚠️ 接线坑（我实测踩过）：`setEconomyReward` 里的 `if (o.<键> != null)` 必须落在**函数开头 1200 字符内**
   * —— D77 就是按这个 slice 查的；新旋钮的注释写太长会把 `divForceGens/wallFilter/wallGames` 顶出窗口 ⇒ 门当场红。
   * 实测：`divForceGens` 落在 1244 时红；把我那条 218 字符的前置注释压到 60 字符后就回到窗口内 ✓。
   * ⚠️ 只数**发生在我身上**的那一次（`e.to === seat`），与"攻击方打空"无关。 */
  let BLOCK_W = 0;
  function countBlocks(events, seat) {
    let n = 0;
    for (const e of (events || [])) {
      if ((e.type === 'blocked' || e.type === 'reflect') && e.to === seat) n++;
    }
    return n;
  }
  /* v1.5.124（§28a）：**用过的招数种类数**（去重、排除 ジ）—— 广度收益项的绝对量。
   * 只认"成功结算"的出手（`outcome === 'ok'`），被无效化的不算（否则刷被废的假动作也能赚钱）。 */
  /* v1.7.90：**落地**的招数种类数 —— 与 `effSkillsLand` 的分子同源（`damage.via` 且是真卡名）。
 *   为什么不用 `action.outcome==='ok'`：那是"出手成功"，不含"打上了没有"（`WIDTH_W` 用的就是那个）。
 *   口径说明：`via` 有一批取值不是卡（`chain` / `夢魘` 之类）⇒ 必须 `R.byKey[via]` 过滤。 */
/* v1.7.91（用户 10-17 质问：「为什么 Geff 不读防御类？把白防御倒过来不就是有效防御」）：
 *   原版只数 `damage.via` ⇒ **防御类永远不落地** ⇒ 落地奖励一分钱不给防御（实测把防御类占比挤掉 8pt）。
 *   改成**材料性落地**：① 造成伤害（`damage.via`）② 被挡/反弹（`blocked`/`reflect` 归给**同席那张防御 action**）
 *   ③ 治疗（`heal.via`）。口径与 `defense-quality.mjs` 的「白防御」互为反面：白防御 = 出了防御但没人打他。
 *   ⚠ 事件流**没有 round 字段**（`D196` 记过）⇒ 用「该席下一次 action」当回合边界。 */
function countVarietyLanded(events, seat, RR) {
  const rules = RR || R;
  const evs = events || [];
  const seen = {};
  for (let i = 0; i < evs.length; i++) {
    const e = evs[i];
    if (e.type === 'damage' && e.via && (e.source == null || e.source === seat) && rules.byKey[e.via]) { seen[e.via] = 1; continue; }
    if (e.type === 'heal' && e.via && rules.byKey[e.via]) { seen[e.via] = 1; continue; }
    if (e.type !== 'action' || e.pid !== seat || !e.key || e.outcome !== 'ok' || e.key === R.SK.JI) continue;
    /* 防御那一半：向后找同席的 blocked/reflect，直到该席下一次 action（= 下一回合）为止。 */
    let landed = false;
    for (let j = i + 1; j < evs.length; j++) {
      const f = evs[j];
      if (f.type === 'action' && f.pid === seat) break;
      if ((f.type === 'blocked' || f.type === 'reflect') && f.to === seat) { landed = true; break; }
    }
    if (landed) seen[e.key] = 1;
  }
  /* v1.7.95 自证：**归因覆盖率** —— 该席吃到的 blocked/reflect 里，有多少能归到它某个 action。
   *   这个数直接分开「归因窗口写错」与「饱和形状压没」：覆盖率高 ⇒ 窗口没错；覆盖率低 ⇒ 窗口错了。 */
  if (WIDTH_LAND_W > 0) {
    for (let i = 0; i < evs.length; i++) {
      const e = evs[i];
      if (!((e.type === 'blocked' || e.type === 'reflect') && e.to === seat)) continue;
      WIDTH_LAND_STAT.blk++;
      for (let j = i - 1; j >= 0; j--) {
        const f = evs[j];
        if (f.type !== 'action' || f.pid !== seat) continue;
        WIDTH_LAND_STAT.blkAttr++; break;
      }
    }
  }
  return Object.keys(seen).length;
}
function countVariety(events, seat) {
    const seen = {};
    for (const e of (events || [])) {
      if (e.type === 'action' && e.pid === seat && e.outcome === 'ok' && e.key && e.key !== R.SK.JI) seen[e.key] = 1;
    }
    return Object.keys(seen).length;
  }
  /* v1.5.126（用户洞察）：**贵卡**的判定与计数 —— 从**声明字段**推导，不写卡名清单（D81/D72 的规矩）：
   *   `cost >= 3`（大雷 5 · 地雷/净化/摄魂 3）**或** `energyNeeds` 非空（电磁炮需 1 电珠 · 激光眼需爆珠）。
   * 只认 `outcome === 'ok'` 的出手（被无效化的不算 ⇒ 不可刷）。 */
  function isBigCard(def) {
    if (!def) return false;
    if (typeof def.cost === 'number' && def.cost >= 3) return true;
    if (def.energyNeeds && Object.keys(def.energyNeeds).length) return true;
    return false;
  }
  function countBigCards(events, seat, RR) {
    const rules = RR || R;
    let n = 0;
    for (const e of (events || [])) {
      if (e.type !== 'action' || e.pid !== seat || e.outcome !== 'ok' || !e.key) continue;
      if (isBigCard(rules.byKey[e.key])) n++;
    }
    return n;
  }
  /** v1.5.187：数**该席打出大雷后引发的交互**（连带）。归因走 `bigTChain.from`（施法者），
   *  不看 `damage.reason`（只覆盖吃到伤害那半）、不看 `voided.reason`（**该事件没有 reason 字段**，原因在 `by`）。 */
  function countBigTChain(events, seat, RR) {
    const rules = RR || R;
    let n = 0;
    for (const e of (events || [])) if (e.type === 'bigTChain' && e.from === seat) n++;
    return n;
  }
  /** v1.5.188（Q-14 ② 的分母）：该席**真正打出的大雷**次数（`outcome === 'ok'` ⇒ 被无效化的不算，
   *  与 `countBigCards` 同一口径 ⇒ 不可刷）。卡从 `rules.SK.BIG_T` 取，不写字面卡名。 */
  function countBigTCasts(events, seat, RR) {
    const rules = RR || R;
    let n = 0;
    for (const e of (events || [])) {
      if (e.type === 'action' && e.pid === seat && e.outcome === 'ok' && e.key === rules.SK.BIG_T) n++;
    }
    return n;
  }
  function bigCardReward() { return { w: BIGCARD_W }; }
  function bigTChainReward() { return { w: BIGT_CHAIN_W, shape: 'rate' }; }   // v1.5.187：读回生效值 · v1.5.188：连"形状"一起读回（率形 vs 计数形）
  function blockReward() { return { w: BLOCK_W }; }
  /* v1.5.124（§28a）：广度收益项的只读回执（权重 + 阈值；判据用**无筛选种群**的 G 中位，见 CHANGELOG）。 */
  function widthReward() { return { w: WIDTH_W, floor: WIDTH_FLOOR, target: WIDTH_TARGET }; }
  function countClears(events, seat) {
    let shrink = false, n = 0;
    const lastBy = {};                 // 谁最后伤了谁（死亡事件无凶手字段 ⇒ 用伤害事件回溯）
    for (const e of (events || [])) {
      if (e.type === 'damage') {
        /* v1.5.113（与 `audit-lib` 同步修）：哨兵用收缩**自己的标记**，不能用 `source == null`
         * （地雷/天火按规则就是无来源伤害 ⇒ 旧口径会提前停止计数、**少算清场**）。 */
        if (e.reason === '终局收缩') shrink = true;
        else if (e.to != null) lastBy[e.to] = e.source;       // 覆盖式：最后一次伤害者才可能算凶手
      } else if (e.type === 'death') {
        if (!shrink && e.pid !== seat && lastBy[e.pid] === seat) n++;
      }
    }
    return n;
  }
  function threatKeyList() { return pierceKeyList().concat([R.SK.RING]); }
  function targetReward() { return { w: TGT_W, threatKeys: threatKeyList() }; }
  function countThreatHits(events, seat) {
    const tk = threatKeyList();
    const rounds = [];                 // rounds[r] = { cast:{pid:[key]}, dmg:{pid:amt}, myTo:{pid:hits} }
    let seen = {}, cur = -1;
    for (const e of (events || [])) {
      if (e.type === 'action') {
        /* ⚠ 回合边界：**一个 pid 重复出现**就是新回合的开始，且必须把 seen 清空
         * （漏了清空 => 所有 pid 都出现过之后，每个动作都被判成新回合 => 回合重建变垃圾 =>
         *  countThreatHits 恒 0。这正是 v1.5.79 第一版奖励**静默空操作**的原因，D68 已加硬到 ≥4 回合守住）。 */
        if (cur < 0) cur = 0;
        else if (seen[e.pid] !== undefined) { seen = {}; cur++; }
        seen[e.pid] = true;
        const rr = rounds[cur] || (rounds[cur] = { cast: {}, dmg: {}, myTo: {} });
        (rr.cast[e.pid] = rr.cast[e.pid] || []).push(e.key);
      } else if (e.type === 'damage') {
        if (cur < 0) continue;
        const rr = rounds[cur] || (rounds[cur] = { cast: {}, dmg: {}, myTo: {} });
        if (e.source != null) rr.dmg[e.source] = (rr.dmg[e.source] || 0) + (e.amt || 0);
        if (e.source === seat && e.to != null) rr.myTo[e.to] = (rr.myTo[e.to] || 0) + 1;
      }
    }
    const isThreat = function (q, r) {          // q 在上回合是否构成威胁（第 1 回合没有上回合）
      if (r < 1) return false;
      const pv = rounds[r - 1]; if (!pv) return false;
      const ks = pv.cast[q] || [];
      for (let i = 0; i < ks.length; i++) if (tk.indexOf(ks[i]) >= 0) return true;
      return (pv.dmg[q] || 0) >= 2;
    };
    let hits = 0;
    for (let r = 0; r < rounds.length; r++) {
      const rr = rounds[r]; if (!rr) continue;
      for (const q in rr.myTo) if (isThreat(Number(q), r)) hits++;
    }
    return hits;
  }

  /* v1.5.76（P1）：珠子闭环奖励权重（默认 0.05，两次封顶）。窄条件 + 可归因 + 事件派生。 */
  let BEAD_W = 0.05;
  /* ===== v1.8.37 夜班续（10-26 千问 §E763）：把"花掉珠子"这笔钱**按珠种拆开** =====
   * 病根（ZCode §二十一·九/十 的结账行）：`发放 0 次 · 充到爆珠 8 次` ⇒ **免费珠让种群从不自己造珠**，
   * 而 `BEAD_W` 不分珠种 ⇒ 蓄电珠与蓄爆珠拿同一笔钱，序列奖励（`SEQ_KIND=boom`）永远付不出去。
   * 本键只给**花掉的爆珠**定价（缺省 0 ⇒ 不加项 ⇒ fit 逐字不变，与 `bigtChainW` 那族同一口径）。 */
  let BEAD_BOOM_W = 0;
  function setBeadBoomW(w) { const v = Number(w); if (isFinite(v) && v >= 0) BEAD_BOOM_W = v; return BEAD_BOOM_W; }
  function setBeadReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) BEAD_W = v; return BEAD_W; }
  function beadReward() { return { w: BEAD_W }; }

  let PRESS_W = 0.03;
  function setPressReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) PRESS_W = v; return PRESS_W; }
  function pressReward() { return { w: PRESS_W }; }

  /* 重建回合分组并数"主动回合"（纯函数，便于守门单测）。
   * 分组依据：一局里每回合每个玩家最多一条 action 事件 ⇒ 见到已出现过的 pid 的 action 即新回合。 */
  function countPressRounds(events, seat) {
    const rounds = [];
    let seen = {}, cur = -1;
    for (const e of events) {
      if (e.type === 'action') {
        if (seen[e.pid] !== undefined) { seen = {}; cur++; }
        else if (cur < 0) cur = 0;
        seen[e.pid] = true;
      }
      if (e.type === 'damage') {
        if (cur < 0) continue;
        if (!rounds[cur]) rounds[cur] = { my: 0, taken: 0 };
        if (e.source === seat) rounds[cur].my += e.amt || 0;
        if (e.to === seat) rounds[cur].taken += e.amt || 0;
      }
    }
    let n = 0;
    for (const r of rounds) if (r && r.my > 0 && r.taken === 0) n++;
    return n;
  }

  /* v1.5.31（方案 A）：示范期拉长到 0.8 + 接力调粗到 0.10。
   * 依据：v7teach 臂第一次让"小雷打环"可达（ringWallProbe 小雷次数 1>0），但 20 局才 1 次 ⇒ 接力太弱。 */
  let RING_W = 0.10;
  /* v1.5.24（用户选方案 A）：**退火** —— 前期权重 0（先把标准分练出来），中段线性升，后期满额。
   * 为什么：v1.5.23 的常开奖励练出了"会打环但标准分掉 14pt"的偏科生（环墙 68.5% / 标准 30.5%）；
   * 退火让种群先在主目标上站住，再叠加"惩罚开环者"的方向性压力。 */
  /* v1.5.29（用户实测 + 方案 b）：**退火默认关闭**（全程满额）。
   * 依据：① 退火那一轮（v1.5.24）与常开那轮（v1.5.23）的配对差异不显著，没换来任何好处；
   * ② 用户实测"我用聚能环时 v7press-36 也没做任何动作打断我" ⇒ 环奖励的**行为效果**本来就没建立起来，
   *    再叠一层退火只会让它更弱。需要回退成退火的实验可以显式调 setRingRamp。 */
  /* v1.5.31（课程臂专用窗口）：示范期（前 125 代，占 250 代的一半）里**环奖励不开**——
   * 实测：环奖励从第 0 代就开会让训练冻死（v7both/v7soft 两臂 6/6 seed 零提升）。
   * 现在改成"先示范、后强化"：模仿教师把动作示范出来，之后奖励接手。 */
  let RING_G0 = 125, RING_G1 = 200;
  function setRingReward(w) { const v = Number(w); if (isFinite(v) && v >= 0) RING_W = v; return RING_W; }
  function setRingRamp(g0, g1) {
    const a = Number(g0), b = Number(g1);
    if (isFinite(a) && a >= 0) RING_G0 = a | 0;
    if (isFinite(b) && b > RING_G0) RING_G1 = b | 0;
    return { g0: RING_G0, g1: RING_G1 };
  }
  /* 第 gen 代实际生效的环奖励权重（退火曲线）。纯函数，便于守门单测。 */
  function ringWeightAt(gen) {
    if (RING_W <= 0) return 0;
    const g = (typeof gen === 'number' && gen > 0) ? gen : 0;
    if (g <= RING_G0) return 0;
    if (g >= RING_G1) return RING_W;
    return RING_W * (g - RING_G0) / Math.max(1, RING_G1 - RING_G0);
  }
  function ringReward() { return { w: RING_W, g0: RING_G0, g1: RING_G1, at0: ringWeightAt(0), atEnd: ringWeightAt(1e9) }; }

  let MIRROR_GAMES = 2;
  /* v1.5.69：**独立的座位探针局数** —— 阈值式座位惩罚的样本来源。
   * 教训（v1.5.68）：最初想蹭 MIRROR_GAMES（=2）的局，但守卫 `seatDec >= 3` 永不满足
   * ⇒ 惩罚**从未触发**、v16 那 6 个 seed 是在"惩罚关闭"下跑的（又是静默空操作）。
   * 故独立取样：默认 6 局（`EPIRUS_SEAT_GAMES` 可调），守卫放宽到 `>= 4`。 */
  let SEAT_GAMES = 6;
  function setSeatGames(v) { if (isFinite(v) && v >= 0) SEAT_GAMES = v | 0; return SEAT_GAMES; }   // 模块级（内层那个同名定义不可见）
  function setMirrorGames(k) {
    const v = Number(k);
    if (isFinite(v) && v >= 0) MIRROR_GAMES = v | 0;
  function setSeatGames(v) { if (isFinite(v) && v >= 0) SEAT_GAMES = v | 0; return SEAT_GAMES; }
    return MIRROR_GAMES;
  }
  function mirrorGames() { return MIRROR_GAMES; }
  function seatGames() { return SEAT_GAMES; }
  function setHealthGate(o) {
    o = o || {};
    if (o.on != null) HEALTH.on = !!o.on;
    if (o.games != null && o.games > 0) HEALTH.games = o.games | 0;
    if (o.promoteGames != null && o.promoteGames > 0) HEALTH.promoteGames = o.promoteGames | 0;
    if (o.n != null && o.n >= 2) HEALTH.n = o.n | 0;
    if (o.minG != null) HEALTH.minG = Number(o.minG);
    if (o.maxDraw != null) HEALTH.maxDraw = Number(o.maxDraw);
    if (o.maxRounds != null) HEALTH.maxRounds = Number(o.maxRounds);
    return healthGate();
  }
  function healthGate() { return { on: HEALTH.on, games: HEALTH.games, promoteGames: HEALTH.promoteGames, n: HEALTH.n, minG: HEALTH.minG, maxDraw: HEALTH.maxDraw, maxRounds: HEALTH.maxRounds }; }

  /* 自对局体检：5 座都是**同一个策略**（与 champ-audit 的 A/B/C/D 列同一口径）。 */
  /* v1.5.35（用户裁定）：**终局平局的正确口径**。
   * 规则里写的是"到上限按血最多者胜"（`rules.js:134`）⇒ 游戏本身已按血量排名次；
   * 此前体检把"全员存活"一律记成平局 ⇒ 血量高的胜局被误记成"和"（农夫场 0% 胜 / 100% 和的假象）。
   * 现在只有**全员存活且血量完全相同**才算平局；血量有差 ⇒ 那是**按血量的胜局**。
   * （用户补充：若血量也相同，则判负/不分胜负——本项目按"不计胜"处理。） */
  function allAliveTied(p) {
    if (!p || !p.length) return false;
    for (let i = 0; i < p.length; i++) if ((p[i].hp || 0) <= 0) return false;
    for (let i = 1; i < p.length; i++) if (p[i].hp !== p[0].hp) return false;
    return true;
  }

  /* v1.5.88（甲·步 1）：**退火强迫多样性** —— 前 DIV_FORCE_GENS 代里，在被测成员的**计分对局**中
   * 以 eps=1 在"可负担的非ジ候选"里**轮转**选招（逼出宽直方图）。产物必须取自窗口之后（与环那次同一配方：
   * 强迫只负责"把状态走出来"，退火后由网络自己保住）。每代错开起点，避免所有成员同步。 */
  function makeDiversityForce(inner, gen) {
    let rr = (gen * 7) % 97;
    return function (state, pid, legal) {
      const aff = [];
      for (let i = 0; i < legal.length; i++) if (legal[i].affordable && legal[i].key !== R.SK.JI) aff.push(legal[i].key);
      if (aff.length > 1) { rr++; return { key: aff[rr % aff.length], target: null, target2: null, bead: null }; }
      return inner(state, pid, legal);
    };
  }
  /* v1.5.88（甲·步 2）：**破墙硬过滤** —— 成员在"4 席 reflectspam"里对我方造成的伤害 < 0.5/局就直接压到底。
   * 起因：v7divK-82 多样性最好（G 4.42）却对 4 面反弹墙**零伤害**（0.00/局、100% 零伤害局），
   * 换包时才被拦。而它在自对局里的穿透卡用量看起来正常（激光剑 28/坦克 16/狙击枪 44）⇒
   * **"自对局用了穿透卡"不能预测"反弹墙里打不打得动"** ⇒ 必须在**真的反弹墙**里量（3 局就够抓 0 伤害）。 */
  function wallProbe(params, games, n) {
    const foe = BOT_PICKS['reflectspam'];
    if (!foe) return null;
    const G = Math.max(1, games | 0);
    let dmg = 0;
    for (let g = 0; g < G; g++) {
      const st = S.createState(TRAIN_MODE === 'long' ? 'long' : 'multi', { next: mulberry32(91000 + g * 13) }, n);
      const ch = [];
      for (let pid = 0; pid < n; pid++) ch.push(pid === 0 ? trainChooser(params) : wrapBotN(foe));
      Play.autoGameN(st, ch);
      for (const e of (st.events || [])) if (e.type === 'damage' && e.source === 0) dmg += (e.amt || 0);
    }
    return dmg / G;
  }

  function mirrorHealth(params, games, n, mode) {
    const G = (games && games > 0) ? (games | 0) : 20;
    const N = (n && n >= 2) ? (n | 0) : 5;
    const mk = (mode === 'long') ? 'long' : 'multi';
    let dmg = 0, heavyDmg = 0, holo = 0, holoOther = 0, draws = 0, rounds = 0, zero = 0;

    /* v1.5.79：威胁靶向奖励的 **支付诊断**（只读，不改变行为）。
     * 封顶式奖励的天然风险是「每局都封顶」 => 奖励退化成**常量** => 梯度约等于 0
     * （同型事故：v1.5.68 的 seatPen 恒 0，整臂在"惩罚关闭"下白跑）。
     * threatCapRate = 有多少局真的吃满封顶，这是"奖惩有没有梯度"的直接读数。 */
    let threatHitsSum = 0, threatCapGames = 0;
    /* 同型体检：**已上线**的 press/pierce 奖励是不是也在空发？（它们同样依赖 e.source === seat） */
    let pressSum = 0, pierceSum = 0;
    const seatWins = new Array(N).fill(0);   // v1.5.68：5 席同策略的各座胜场（座位偏置的直接读数）
    let seatDec = 0;
    const keyCount = {};
    /* v1.5.28（第三方复核 §4-2b）：**落地命中按卡统计** —— G（出手分布的熵）会被"变宽但丢关键卡"骗：
     * v1.5.27 实测 G 4.15→6.55 的同时，把唯一能穿反弹的**激光剑**用到 0 命中（长程反弹墙 85%→0%）。
     * 这里直接统计 `damage` 事件的 `via`，并**从规则数据推导**出"能穿反弹/穿防御"的卡（不硬编码）。 */
    const landByKey = {};
    for (let g = 0; g < G; g++) {
      const st = S.createState(mk, { next: mulberry32(9000 + g) }, N);
      st.slotSalt = slotSaltFor(9000 + g);
      const ch = [];
      for (let i = 0; i < N; i++) ch.push(trainChooser(params));
      Play.autoGameN(st, ch);
      if (st.winner !== 'draw' && st.winner != null) { seatWins[st.winner]++; seatDec++; }   // v1.5.68
      let gd = 0;
      for (const e of st.events) {
        /* v1.5.32：**把盾套给别人**要单独计数（用户实测：v7wall-33 每局 18.7 次全息、100% 送人）*/
        if (e.type === 'holoSet') { holo++; if (e.target !== e.pid) holoOther++; }
        if (e.type === 'damage') {
          dmg += e.amt; gd += e.amt;
          const def = e.via ? R.byKey[e.via] : null;
          if (e.via) landByKey[e.via] = (landByKey[e.via] || 0) + 1;
          if (def && def.cost != null && def.cost >= 3) heavyDmg += e.amt;
        }
        /* G：只统计**非ジ**的成功出手（ジ 占比 ~60% 是算术必然，算进去会把覆盖度量成常数）。 */
        if (e.type === 'action' && e.outcome === 'ok' && e.key && e.key !== R.SK.JI) {
          keyCount[e.key] = (keyCount[e.key] || 0) + 1;
        }
      }
      rounds += st.round;
      if (gd === 0) zero++;
      if (allAliveTied(st.p)) draws++;   // v1.5.35：只有血量也相同才算平局

      /* v1.5.79：统计"威胁命中"的真实分布（诊断奖励是否退化成常量） */
      /* 与奖励的封顶同步：tgtBonus = TGT_W * min(1, hits/1) ⇒ hits>=1 即满额。 */
      { const _seatD = g % N; const _th = countThreatHits(st.events, _seatD); threatHitsSum += _th; if (_th >= 1) threatCapGames++; pressSum += countPressRounds(st.events, _seatD); pierceSum += countPierceHits(st.events, _seatD); }
    }
    const ks = Object.keys(keyCount);
    const tot = ks.reduce(function (a, k) { return a + keyCount[k]; }, 0);
    /* 从 R.skills 推导"能穿反弹/穿防御"的卡（激光剑/坦克/狙击枪/电磁炮）—— 规则改了它自动跟着变。 */
    const pierceKeys = (R.skills || []).filter(function (sd) {
      const pp = sd.pierce || {};
      return !!(pp.reflect || pp.defense);
    }).map(function (sd) { return sd.key; });
    let H = 0;
    for (const k of ks) { const pr = keyCount[k] / tot; H -= pr * Math.log(pr); }
    /* v1.5.167（qoder §N24 · 用户"G_eff 像是为了刷 eff 只用最容易被测到的卡"）：**兑现加权**的第二把尺子。
     * `effSkills` 数的是"发起了几种"——一张常出手常被防住的卡与一张少见但每次掉血的卡**在这把尺上等价**；
     * `effSkillsLand` 用同一套熵去数 `landByKey`（真正造成过伤害的卡），于是"广"必须是"打得出血"的广。
     * 实测差距（`tools/probe-cast-vs-land.mjs`，现役 cmin4）：出手:落地 = 537:278 ⇒ `G=4.44` 而净兑现只有 `2.66（3 种真卡）`。
     * ⚠️ 它**只当同分带内的排序键/体检读数**，不当奖励：仓里有前例——"奖励贵技能落地"的探针会选出
     *   乱挥双枪的冠军（实测 −27pt，见 `evalSubsidyProbe` 的注释），所以**兑现次数进 fit 是错的路**。
     * ⚠️ **只数真卡名**（发布前自查发现的口径缺陷）：`landByKey` 按 `damage.via` 统计，而 `via` 有一批取值**不是一张卡**——
     *   `deliverDamage` 在 `via` 缺省时会回落到中文 `reason`（`resolve.js:305`）⇒ "终局收缩"（`source==null` 的全员 −1）按规则白送的血入账；
     *   另有 `headshot`（爆头 = 狙击的**结果修饰**，`resolve.js:1207`）、`dream`/`chain`/`counter`/`taunt` 这些引擎内标记。
     *   不滤就会**奖励"拖到收缩阶段还活着"的包**、惩罚主动进攻的包：实测同臂 6 粒候选的非卡名占"落地"10%~41%（band4 是 104/293=41%），
     *   ⇒ §N25 的 L1"改判"整条是这个 bug 的产物（污染下 band5 的 `落地G=2.62` 是全场最大，净口径下只有 1.51、最大者换成 band1）。
     *   ⇒ `landByKey` 本身**保持原样**（v1.5.28 起 `pierceMissing` 吃它，动它 = 偷改既有判据），只在新字段上收口径。
     *   **已知偏保守的一处**：`原型制御·转移`（`resolve.js:270` 只给 reason）是真卡伤害，但键名不是 `SK.proto` ⇒ 被一并滤掉。
     *   代价 = 少数一种卡；收益 = 永不把"非卡的血"算成卡。选**宁可少计**，并把滤掉的量记在 `landedFiltered` 里自证。 */
    const lks = Object.keys(landByKey).filter(function (k) { return landByKey[k] > 0 && !!R.byKey[k]; });
    const ltot = lks.reduce(function (a, k) { return a + landByKey[k]; }, 0);
    const lfilt = Object.keys(landByKey).reduce(function (a, k) { return a + (R.byKey[k] ? 0 : landByKey[k]); }, 0);
    let HL = 0;
    for (const k of lks) { const pr = landByKey[k] / ltot; HL -= pr * Math.log(pr); }
    return {
      games: G, dmgPerGame: dmg / G, heavyPerGame: heavyDmg / G, holoPerGame: holo / G,
      zeroRate: zero / G, drawRate: draws / G, rounds: rounds / G,
      holoOtherPerGame: holoOther / G,
      effSkills: tot ? Math.exp(H) : 0, distinctKeys: ks.length, nonJi: tot,
      effSkillsLand: ltot ? Math.exp(HL) : 0, landedKeys: lks.length, landedTotal: ltot, landedFiltered: lfilt,
      landByKey: landByKey, pierceKeys: pierceKeys,
      /* v1.5.266（§E68）：**出手计数**也随读数返回（只加字段，不改任何判定）。
       * 动机：`landByKey` 只数"造成过伤害"的卡 ⇒ 聚能环/蓄能这类**不打血**的卡在里面永远是 0，
       * 拿它当"优点还在不在"的判据会把这两维**静默判成不可判**（09-28 实测 veto 就撞在这里）。 */
      castByKey: keyCount,
      /* 零落地的"穿透卡"（能穿反弹/穿防御）—— 为 0 就说明**破墙的那条线丢了** */
      pierceMissing: pierceKeys.filter(function (k) { return !landByKey[k]; }),
      seatWins: seatWins, seatDecisive: seatDec,
      threatHitsPerGame: threatHitsSum / Math.max(1, G), threatCapRate: threatCapGames / Math.max(1, G),
      pressRoundsPerGame: pressSum / Math.max(1, G), pierceHitsPerGame2: pierceSum / Math.max(1, G),
      seatSpread: (function () { if (seatDec < 3) return null; const p = seatWins.map(function (w) { return 100 * w / seatDec; }); return Math.max.apply(null, p) - Math.min.apply(null, p); })()
    };
  }
  function healthFails(mh) {
    if (!mh) return [];
    const f = [];
    if (mh.effSkills < HEALTH.minG) f.push('G 有效技能数 ' + mh.effSkills.toFixed(2) + ' < ' + HEALTH.minG);
    if (mh.drawRate > HEALTH.maxDraw) f.push('平局率 ' + (mh.drawRate * 100).toFixed(0) + '% > ' + (HEALTH.maxDraw * 100) + '%');
    if (mh.rounds > HEALTH.maxRounds) f.push('自对局回合 ' + mh.rounds.toFixed(1) + ' > ' + HEALTH.maxRounds);
    return f;
  }

  function pickChampionByWinRate(t, games, seedBase) {
    const cands = [t.champion].concat(t.lastTop || []);
    const pool = [];
    const seen = new Set();
    for (const params of cands) {
      if (!params || seen.has(params)) continue;
      seen.add(params);
      const sel = policyChooser(params, 0.05);
      let tot = 0, n = 0, minWr = 1;
      const detail = [];
      for (const nm of Object.keys(BOT_PICKS)) {
        const r = correctedWinRate(sel, BOT_PICKS[nm], games, seedBase + n * 131);
        tot += r.wr; n++;
        if (r.wr < minWr) minWr = r.wr;
        detail.push({ name: nm, wr: r.wr });
      }
      const wr = n ? tot / n : 0;
      // 硬门槛：任一基准 <50% → 直接失去冠军资格（GATE_ALL 时覆盖全部基准）
      let gateOk = true, gateMin = 1;
      for (const d of detail) if (GATE_ALL || GATE_NAMES.indexOf(d.name) >= 0) { gateOk = gateOk && d.wr > 0.5; if (d.wr < gateMin) gateMin = d.wr; }
      // min 主导：过了门槛按 0.5·平均 + 0.5·最差基准；没过门槛则压到所有合格候选之下
      const base = gateOk ? (0.5 * wr + 0.5 * (n ? minWr : 0)) : (gateMin * 0.4 - 1);
      /* v7：**自对局健康门槛**（见 mirrorHealth 的说明）。不过门槛的候选被压到所有健康候选之下，
       * 且不许进容差带 ⇒ 训练器不能再靠"熬"拿分。 */
      const mh = (HEALTH.on && !IN_EXPLORE) ? mirrorHealth(params, HEALTH.games, HEALTH.n, TRAIN_MODE) : null;   // v1.5.42：探索期不评估健康
      const hFails = healthFails(mh);
      const healthOk = hFails.length === 0;
      const score = healthOk ? base : base - 1;
      pool.push({ params: params, score: score, wr: wr, minWr: minWr, detail: detail, health: mh, healthOk: healthOk, healthFails: hFails });
    }
    // 多目标：先按胜率分选出容差带，再在其中取覆盖熵最高者
    let best = null, bestScore = -1, bestWr = -1, bestMin = -1, bestDetail = null;
    let topScore = -1e9;
    for (const c of pool) if (c.score > topScore) topScore = c.score;
    const band = pool.filter(function (c) { return c.healthOk && c.score >= topScore - WR_TOL; });
    let bestDiv = -1, bestDivNorm = 0, bestDistinct = 0;
    /* 头对头验收（2/3 人实测都需要的保险）：
     * 1st+0.5*top2 这类名次指标**不能完整代表头对头强度**——3 人侧实测容差带内的
     * 最发散候选虽然指标够格，却被 2 倍数量的强候选打成 17:62。
     * 故：带内候选必须与「最高分候选」对拼 >= H2H_MIN 才允许被选中，否则顺延到下一个。 */
    const H2H_MIN = 0.5;
    const topCand = pool.reduce(function (a, b) { return b.score > a.score ? b : a; });
    const topSel = policyChooser(topCand.params, 0.15);
    const ranked = band.slice().sort(function (a, b) {
      return champEntropy(b.params, 0.15, 60, seedBase + 7777).divNorm - champEntropy(a.params, 0.15, 60, seedBase + 7777).divNorm;
    });
    let h2hNote = null;
    for (const c of ranked) {
      const e = champEntropy(c.params, 0.15, 60, seedBase + 7777);
      let ok = true, h2h = null;
      if (c !== topCand && c.params !== topCand.params) {
        const r = correctedWinRate(topSel, policyChooser(c.params, 0.15), 60, seedBase + 4242);
        h2h = r.wr;
        ok = r.wr >= H2H_MIN;
      }
      if (!ok) { h2hNote = (h2hNote || '') + ' [跳过 divNorm=' + e.divNorm.toFixed(3) + ' 把头对头仅 ' + (h2h * 100).toFixed(0) + '%]'; continue; }
      best = c.params; bestScore = c.score; bestWr = c.wr; bestMin = c.minWr; bestDetail = c.detail;
      bestDivNorm = e.divNorm; bestDistinct = e.distinct; bestDiv = e.divNorm; break;
    }
    if (!best) { best = topCand.params; bestScore = topCand.score; bestWr = topCand.wr; bestMin = topCand.minWr; bestDetail = topCand.detail; bestDivNorm = 0; bestDistinct = 0; }
    if (h2hNote) console.log('[多目标] 头对头验收拦截:' + h2hNote);
    if (best) { t.divNorm = bestDivNorm; t.distinct = bestDistinct; t.bandSize = band.length; }
    if (best) { t.champion = best.slice(); t.bestChamp = best.slice(); t.bestChampScore = bestScore; }
    return { champion: best, wr: bestWr, minWr: bestMin, score: bestScore, detail: bestDetail };
  }

  global.EpirusTrainer = {
    makeTrainer, step, finishStep, scoreMember, buildOpps, oneGame, correctedWinRate, champVsBaseline, mulberry32, seedChampion, pickChampionByWinRate, champEntropy, setRegenTotal, regenForGen, makeCommitChooser, evalEconProbe, evalSubsidyProbe, costOfKey, setImitUntil, imitBetaForGen, setImitTeacher, imitTeacher, makeAntiRingTeacher, setAntiRingTeacher, setImitTeacherByName, setImitOverride, teacherFull, setImitPlan, setImitPlanByName, imitTeacherForGen, setImitOnly, imitOnlyForGen, setImitSubOnly, setSubBead, subBeadOn, setBeadSeed, beadSeedOn, setRegenSlice, regenSlice, countImitInject, resetImitStat, tagImitActions, imitAttribution, resetImitAttribution, sliceHit, isCommitGame, regenForGame, setChargeMinEp, chargeMinEpOn, setWrTol, setTrainMode, trainMode, setStyleSlice, styleSlice, seatGames, setSeatGames,
  setEconomyReward, economyReward, economyTargets, economyStock, coverageEntropy, setFightReward, fightReward, rankCredit, firstBloodSeat, roleOf,
    mirrorHealth, setHealthGate, healthGate, healthFails, setMirrorGames, mirrorGames,
    setRingReward, ringReward, countRingBreaks, setRingRamp, ringWeightAt,
    setPressReward, pressReward, countPressRounds,
    setPierceReward, pierceReward, countPierceHits, pierceKeyList,
    setWallBreakReward, wallBreakReward, countWallBreakHits, wallBreakDamage, wallBreakKeyList, reflectReward, countReflectAmt, guardHitReward, countGuardHits, beadWasteReward, countBeadExpiredEvents,
    setBeadReward, beadReward, countBeadSpent,
    /* v1.8.37 夜班续（§E763）：补贴局的珠种（枚举 setter，非法值响亮拒）+ 按珠种拆的珠奖励 setter。
     * `beadBoomW` 的值走 `economyReward()` 读回（D77 的往返契约只认那条路），这里不另开一个 getter。 */
    setSubBeadKind, subBeadKind, setBeadBoomW,
    setKillField, killField, countKillSeats, killSeatFor, botRegisteredName,   // v1.5.160 收割席注入（含**开火计数**，§N12 教训）‖ v1.7.158 反查注册名（注入名单从"标签"变成"测量"）
    setFamilyField, familyField, countFamilyField, familySeatSet,   // §E798（10-27 夜班）：训练桌形状（k 席家族副本 + 其余脚本）‖ 同样带**作用计数**，注了 0 局要响亮失败
    setOppTable, oppTable, oppSeatIndex,   // v1.5.279 §E124：整桌同原型（默认关；`oppSeatIndex` 是纯函数，门 D187 直接判它）
    setTargetReward, targetReward, countThreatHits, threatKeyList, setLaserReward, laserReward, countLaserHits,
    /* v1.8.29：失效成功定价（计数是纯函数 ⇒ 门可以直接喂事件序列断言，不必跑一整局）。 */
    setVoidReward, setVoidIdealReward, voidReward, countVoidWins, countVoidIdeal, voidScan,
    setClearReward, clearReward, countClears,
    blockReward, countBlocks,   // v1.5.121 E4：挡下伤害计数（奖励权重走 econ-env 的 blockW）
    widthReward,                // v1.5.124 §28a：广度收益项（权重走 econ-env 的 widthW）
    bigCardReward, countBigCards, bigTChainReward, countBigTChain, countBigTCasts,   // v1.5.126：贵卡出手奖励（权重走 econ-env 的 bigcardW）· v1.5.187/188：大雷连带收益项（bigtChainW，**率形**）
    allAliveTied, setRingForceEps, ringForceEps, ringForceTarget, setRingForceUntil, ringForceUntil, ringForceEpsAt,
    scoreMemberN, oneGameN, evalN, policyChooserN, policyChooser, pickChampion, econBase, hasPurgeable, wrapBotN, pickTargetN, pickTarget2N, rankOf, seqLockedTurn,
    setBigTPush, bigTPushOn, bigTPushPick, bigTPushTarget, bigTPushSalt, wrapBigTPush,   // v1.5.332 §E270：大雷"每四五局一张"的上线档（默认值只由上面那个常数表达，门 D224 钉）· v1.6.3 §E282：外面那层给脚本席用
    setSupportPrior, supportPriorOn, supportPriorTarget, setSupportPriorKnobs, supportPriorKnobs,   // §E646（路线 B）：送盾的部署层先验，**默认 0=关**；自证在 `tools/probe-support-prior.mjs`
    setDrainPush, drainPushOn, drainPushWants, drainPushSalt,              // v1.5.334 §E275：摄魂"残血只在探索里软提升"（默认 0=关，门 D225 钉）
    /* v1.8.33（§E712）：序列窗锁的"窄锁"档（默认 0 ⇒ 出厂逐字不变）。`chainKeysOf` 是纯函数 ⇒ 门/量具可直读，
     * 三个 stat 口用来证明"开档真的改变了行为"（否则"开了但没生效"与"没开"同形，§E83 那一族）。 */
    setLockNarrow, lockNarrowOn, lockNarrowStat, resetLockNarrowStat, chainKeysOf,
    /* v1.8.33 同一笔：贴贴的高 ep 软注入（默认 0=关；`cursePushWants` 是纯函数 ⇒ 门/量具可直读）。 */
    setCursePush, cursePushOn, cursePushWants, cursePushSalt, cursePushStat, resetCursePushStat,
    setBeliefSearch, beliefSearchOn, policyChooserBelief, beliefObserve, setBeliefPly, beliefPly,
    setBeliefTarget, beliefTarget, setBeliefTie, beliefTie,
    setBeliefBead, beliefBead, setBeliefRingPrice, beliefRingPrice, setBeliefBeadRedeemable, beliefBeadRedeemable,
    setBeliefFireSpend, beliefFireSpend,
    setTrainEps, trainEps, countTrainEps, resetTrainEpsStat   // v1.5.237 E28：训练侧执行口径旋钮（默认关）+ **开火计数**
  };
})(typeof window !== 'undefined' ? window : globalThis);
