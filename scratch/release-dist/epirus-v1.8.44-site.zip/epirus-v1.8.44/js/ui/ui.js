/* Epirus — 界面：对局交互 / 回合演示 / 训练场调度（全部本地，无依赖） */
(function () {
  'use strict';
  const R = window.EpirusRules, S = window.EpirusState, X = window.EpirusResolve;
  const Tip = window.EpirusSkillTip;   // v1.5.173：卡面提示的组装单一来源（`js/ui/skill-tip.js`，门 D131 钉"必须被用、必须被加载"）
  const BeadChoice = window.EpirusBeadChoice;   // v1.5.199：「这一手蓄能攒哪种珠」的单一来源（`js/ui/bead-choice.js`，门 D142 钉加载顺序与三处调用）
  const Play = window.EpirusPlay, Bots = window.EpirusBots;
  const P = window.EpirusPolicy, Trainer = window.EpirusTrainer, Champ = window.EpirusChampion;

  /* v1.7.111（用户 10-18 裁定「页面开先验」）：**送盾先验默认开档 2**（改目标 + 挑不到就改攒，按概率）。
   *   为什么要在页面开：`v7beadseed-82` 这类包**靠它才不刷屏**（裸包 17.3 次/局，开档 4.2/5.4），
   *   而先验原先只接在评测/训练工具里（`eval-5p` / `promote-champion`），页面零调用 ⇒ 产品行为与测量口径不一致。
   *   这里只是**把部署层开关打开**，不改引擎规则；开关本身不消耗 `state.rng`（`evo.js` 那份实现已自证）。
   * §E648：这一行现在是**现网默认值的唯一来源**（引擎常数仍是 0），原来那个 `catch(e){void e;}` 会把
   *   "加载顺序被调后 `EpirusTrainer` 还没就绪"吞成**静默回裸包**——页面照样能玩、CHANGELOG 却写着已开，
   *   只有去量行为才发现。⇒ 现在**回读引擎**并逐条响亮报（控制台没这两行之一就是没接上，不是"没问题"）。 */
  try {
    if (!Trainer || typeof Trainer.setSupportPrior !== 'function') {
      console.warn('[support-prior] ⛔ `EpirusTrainer.setSupportPrior` 不存在 ⇒ **页面没开先验**（产品口径退回裸包，而账上写着已开）');
    } else {
      Trainer.setSupportPrior(2);
      const PRIOR_BACK = typeof Trainer.supportPriorOn === 'function' ? Trainer.supportPriorOn() : null;
      const PRIOR_KNOBS = typeof Trainer.supportPriorKnobs === 'function' ? Trainer.supportPriorKnobs() : null;
      if (PRIOR_BACK !== 2) console.warn('[support-prior] ⛔ 声明开档 2，引擎回读 `' + PRIOR_BACK + '` ⇒ setter 没生效，产品与测量已分叉');
      else console.info('[support-prior] 页面档 = ' + PRIOR_BACK + ' ‖ knobs 引擎回读 = pick=' + (PRIOR_KNOBS && PRIOR_KNOBS.pick)
        + ' skipP=' + (PRIOR_KNOBS && PRIOR_KNOBS.skipP) + ' minEp=' + (PRIOR_KNOBS && PRIOR_KNOBS.minEp));
    }
  } catch (e) { console.warn('[support-prior] ⛔ 开档抛错：' + ((e && e.message) || e)); }

  const $ = function (id) { return document.getElementById(id); };
  const NAME = ['你', '电脑'];
  const CAT_NM = { energy: '能量', attack: '攻击', defense: '防御', special: '特殊' };
  /* v1.5.18：删掉 `fast` / `lucky` 两个标签 —— 它们对应的模式已从 `MODES` 里删除（用户裁定）。 */
  const MODE_NM = { standard: '标准(2人·3血)', multi: '多人(3血)', multi4: '4 血', long: '长程(5血)' };
  /* ===== v1.6.5（用户 10-03 夜裁定「把 2 人合并进多人，变成选人数 × 3血/5血正交，4 血也可以上，实现连续性」）=====
   * 原来页面有一根「模式」下拉，它其实**同时**决定了人数与血量（standard=2人3血 / multi=3~5人3血 / long=3~5人5血），
   * 于是「2 人 · 5 血」「任意人数 · 4 血」这类组合在页面上点不出来。现在两根轴各自一个下拉（`#sel-players` / `#sel-hp`），
   * **模式键由这两根轴查出来** —— 下面这张表是唯一的映射来源：
   *   · 门 D28（本版重写）钉"这张表 + 2 人 3 血那一格的像必须恰好等于 `R.MODES` 的全部 key"：
   *     漏一个 = 有模式没有入口（D28 当年就是这么抓到 `fast`/`lucky` 的），多一个 = 幽灵选项。
   *   · 血量 4 是本版新增的一格规则（`R.MODES.multi4`），其余字段照 `multi` ⇒ "4 血 = 3 血那套 + 多一格血"，
   *     不是第四套规则。
   * ⚠ `standard` 只在 **2 人 · 3 血** 那一格命中：它是 v1.0.0 功能冻结的那套（含"收缩起点 100 > 回合上限 60 ⇒ 一局里永不触发"
   *   这条历史形状）。2 人 + 4/5 血走 multi4/long，那里收缩/回合上限是真的会起作用 —— 这是**规则差异**，不是 bug。 */
  const HP_MODE = { 3: 'multi', 4: 'multi4', 5: 'long' };
  const HP_MODE_2P = 'standard';
  function modeFor(hp, players) {
    const h = parseInt(hp, 10) || 3;
    if ((parseInt(players, 10) || 2) === 2 && h === 3) return HP_MODE_2P;
    return HP_MODE[h] || HP_MODE[3];
  }

  /* ---------- 小工具 ---------- */
  function skillName(key) { return R.byKey[key] ? R.byKey[key].name : key; }
  function byName(key) { return R.byKey[key] ? R.byKey[key].name : key; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------- 对局状态 ---------- */
  const B = {
    state: null, modeKey: 'standard', diff: 'lv:regular', players: 2, hp: 3, multi: false,
    roundStarted: false, locked: false, snap: null, aiKey: null,
    evCursor: 0, transcript: [], aiHistory: [],
    roundStartSnapshot: null, warnedChampNoTrain: false, undoUsed: false,
    /* §E667（2026-10-20，用户："给导出对局记录里面加上本次的对手"）：开局/换档**当场**记下的历史，
     *   导出的头部只读这几格，不在那里重推（理由见 `seatOppLabel` 头上那段）。`diffLabel` 跟着一起快照，
     *   否则 `难度=`（活读）会与 `对手=`（快照）不同档 ⇒ 一张头部自相矛盾。 */
    oppSeats: '', oppInfo: '', oppMid: null, diffLabel: ''
  };

  /* v1.5.11（用户裁定"按你的意思做"）：终局收缩参数（起扣回合 / 每回合扣血）从页面控制区读，
   * 0 = 关闭；空/非法值回落到规则默认。经 createState 的 opts 传入（内部浅拷贝，不污染 MODES）。 */
  const SD_KEY = 'epirus.sudden';
  function sdOpts() {
    const on = $('inp-sd'), dm = $('inp-sd-dmg');
    if (!on || !dm) return null;
    const a = parseInt(on.value, 10), b = parseInt(dm.value, 10);
    if (!isFinite(a) || a < 0) return null;
    return { suddenDeath: a, suddenDeathDmg: (isFinite(b) && b > 0 ? b : 1) };
  }
  function loadSd() {
    try {
      const j = JSON.parse(localStorage.getItem(SD_KEY) || 'null');
      if (j && typeof j.suddenDeath === 'number' && $('inp-sd')) {
        $('inp-sd').value = j.suddenDeath;
        if ($('inp-sd-dmg')) $('inp-sd-dmg').value = j.suddenDeathDmg || 1;
      }
    } catch (e) { /* ignore */ }
  }
  function saveSd() {
    try { localStorage.setItem(SD_KEY, JSON.stringify(sdOpts() || {})); } catch (e) { /* ignore */ }
  }
  /* ===== v1.5.333（用户 10-03 晚裁定「你把 p=8 默认开吧」）：大雷的"看得见"档**已经是默认行为** =====
   * 这一行**不再是开关**：值写在唯一的来源 `js/train/evo.js` 的 `BIGT_PUSH`（现值以那里为准 ⇒ 这里不复制数字，复制了就会腐烂；
   *   就变成"两处开关"—— 本仓的老账是两处必漂移，所以 v1.5.332 那两行显式调用被撤掉了，改由门 D224 钉"默认值在册 + 无调用方也生效"）。
   * 用户的话：「最后大雷只要每四五局有一次就行了，亏损这一点没什么关系」→「按 p=8 准备上线」→「p=8 默认开」。
   * 实测（产品考卷 70,200 局、与同树**关掉档**逐桌配对，§E270/§E271）：**3 血桌每 5.2 局一张、−0.52 ±0.16pt ‖ 5 血桌每 3.2 局一张、−0.40 ±0.13pt**；
   *   ⚠ 2 人真桌实测每 250 局才一张（那张牌在 2 人桌上开不了窗口）⇒ 要 2 人也看得见只能动门槛/单价（用户裁定级，见 §E272）。
   * ⚠ 三条边界：① **不是改规则**（`js/core/*` 未动、指纹仍 `ebdbff36`、5 珠价与 3 回合封锁原样、两槽冠军未 promote）；
   *   ② 默认开 = **训练/评测/门禁也带着这一档跑** ⇒ 对照要显式 `--shipbigt=0`；
   *   ③ **回退 = 把 `evo.js` 里那个常数改成 0**（一行）。 */

  function newGame() {
    applyAxes();   // v1.6.5：人数 × 血量 → 模式键（旧版这根叫 `syncModeOptions`，它按人数把"标准"置灰）
    const n = B.players || 2;
    /* v1.6.6：这根旗标**只管版式**（2 人 = 左右两块面板；3~5 人 = 右栏堆叠），不再决定"走哪条 AI 路"
     * —— 以前它还兼管"2 人用 `doPick`/`chooseAI`、多人用 `doPickMulti`/`chooseAIMulti`"，那两条已合成一条。
     * ⇒ 读代码的人注意：`B.multi === false` **不表示**"这局用的是 v1.0 那套 AI"，只表示座位是 2 个。 */
    B.multi = n > 2;
    if (typeof syncDiffOptions === 'function') syncDiffOptions();
    B.state = S.createState(B.modeKey, null, n, sdOpts());
    /* v1.5.66：**每局一个槽位/顺序盐** —— 让目标枚举顺序与结算相位在页面上也不再有身份
     * （训练与评测早就带盐；此前只有页面缺省 0 ⇒ 页面走确定性顺序）。 */
    B.state.slotSalt = (Math.random() * 4294967296) >>> 0;
    B.roundStarted = false; B.locked = false; B.aiKey = null; B.picking = null;
    B.evCursor = 0; B.transcript = []; B.aiHistory = [];
    B.roundStartSnapshot = null; B.warnedChampNoTrain = false; B.undoUsed = false;
    closeOverlay();
    buildSkillGrid();
    renderSide(0); renderSide(1);
    /* v1.6.5：这行不再分"多人/标准"两种写法 —— 人数与血量是两根明写的轴，模式名只是它们的查表结果。 */
    /* §E667：开局这一格算**一次**，页面首行与导出的头部读同一份（抄两遍 = 两份实现会分叉） */
    const oppInfo = aiInfo();
    B.oppInfo = oppInfo.source;
    B.oppSeats = seatOppLabel(oppInfo);
    B.oppMid = null;
    B.diffLabel = diffName(B.diff);            /* 与 `对手=` 同一时刻的快照：中途换档时这两格必须说的是同一档 */
    logClear('新对局：' + n + ' 人 · ' + (MODE_NM[B.modeKey] || B.modeKey) + ' · 难度=' + diffName(B.diff) +
      ' · 对手AI=' + B.oppInfo + ' · 每人初始 ' + B.state.mode.hp + ' 血');
    hint('请选择技能出招 —— 双方同时出手，按优先级结算。');
  }

  function diffName(d) {
    /* v1.6.6：档名一律取自 `DIFF_TIERS`（查不到才退回风格名）—— 原来这里自己写了一遍"简单/中等/困难"，
     *   那是 2 人旧三档的残留，按用户裁定已作废。 */
    const t = tierOf(d);
    if (t) return t.name;
    const st = styleOf(d);
    return st ? st.name : String(d);
  }

  /* ---------- 侧栏渲染 ---------- */
  function panelHtml(pid) {
    const st = B.state, p = st.p[pid];
    const full = Math.min(Math.floor(p.hp), 8);
    let hearts = '';
    for (let i = 0; i < full; i++) hearts += '♥';
    if (p.hp - Math.floor(p.hp) >= 0.45 && full < 8) hearts += '♡';
    if (p.hp > 8) hearts += ' ×' + p.hp;
    /* v1.5.15 修**信息泄漏**（用户报）：`蓄能` 选电珠还是爆珠**只有本人知道**，别人只知道"有人蓄能了"
     * ⇒ 对手面板不再显示珠的**类型**，只显示"持珠（类型未知）"。本人（pid 0）照旧显示 电/爆。 */
    const chipMine = (pid === 0);
    const chips = ['ジ', '电', '爆'].map(function (k) {
      if (!chipMine && k !== 'ジ') return '';
      const v = k === 'ジ' ? p.ep : (k === '电' ? p.elec : p.boom);
      return '<span class="stat">' + k + ' <b>' + v + '</b></span>';
    }).join('') + ((!chipMine && (p.elec || p.boom)) ? '<span class="stat">珠 <b>?</b></span>' : '');

    const badges = [];
    if (p.hp <= 0) badges.push(['已淘汰', 'red']);
    if (p.mineArmed) badges.push(['地雷', 'warn']);
    if (p.rodGuard > 0) badges.push(['避雷针守卫', 'blue']);
    if (p.chains && p.chains.length) badges.push(['铁索连环×' + p.chains.length, 'pur']);
    if (p.nightmare) badges.push(['梦魇-0.5/回合', 'warn']);
    if (p.vampire) badges.push(['吸血鬼公爵', 'pur']);
    if (p.baguaExtra) badges.push(['无极变速·本回合', 'blue']);
    if (p.fireWeakNow) badges.push(['藤甲·火伤+1', 'warn']);
    if (p.tauntActive) badges.push(['被挑衅·必须攻击', 'warn']);
    if (p.infiniteEnergy) badges.push(['回魂·无限能量', 'gold']);
    if (p.stickers.length) badges.push(['符咒×' + p.stickers.length, 'pur']);
    const cd = Object.keys(p.cooldown).filter(function (k) { return p.cooldown[k] > 0; });
    if (cd.length) badges.push(['禁用中:' + cd.map(skillName).join('/') + '×' + cd.length, 'warn']);

    return '<h3>' + (pid === 0 ? '🧑 ' : '🤖 ') + esc(p.name) + '</h3>' +
      '<div class="statbar"><span class="stat">HP <b>' + p.hp + '</b></span>' + chips + '</div>' +
      '<div class="hearts">' + (hearts || '') + '</div>' +
      '<div class="badges">' + (badges.map(function (bd) { return '<span class="badge ' + bd[1] + '">' + bd[0] + '</span>'; }).join('') || '<span class="dim" style="font-size:11px">无状态</span>') + '</div>';
  }

  function renderSide(pid) {
    if (B.multi) {
      if (pid === 0) { $('side-0').innerHTML = panelHtml(0); return; }
      let h = '';
      for (let i = 1; i < B.state.p.length; i++) {
        h += '<div class="mpanel' + (B.state.p[i].hp <= 0 ? ' dead' : '') + '">' + panelHtml(i) + '</div>';
      }
      $('side-1').innerHTML = h;
      return;
    }
    $('side-' + pid).innerHTML = panelHtml(pid);
  }

  /* ---------- 技能面板 ---------- */
  function costLabel(s) {
    switch (s.key) {
      case R.SK.JI: return '免费 · 得1ジ';
      case R.SK.CHARGE: return '1ジ · 得能量珠';
      case R.SK.RING: return '首3ジ · 连发免费';
      case R.SK.CANNON: return '相位:2ジ→全ジ→全ジ+1血';
      case R.SK.LASER_EYE: return '首1ジ+爆珠 · 连用2ジ';
      case R.SK.RAILGUN: return '2ジ+电珠';
      case R.SK.FIRESTORM: return '首1ジ · 连用2ジ';   /* R62 */
      default: return (s.cost === 0 ? '免费' : s.cost + 'ジ');
    }
  }
  function buildSkillGrid() {
    const grid = $('skillgrid');
    const st = B.state;
    // 不可用（ジ/珠子不足或条件不满足）的技能直接置灰不可点——不再"能点但显示无效"
    const legalMap = {};
    if (!st.over) { for (const l of Play.legalActions(st, 0)) legalMap[l.key] = l; }
    grid.innerHTML = '';
    /* v1.5.22（用户第三次澄清）：**技能格按钮**用 `R.skills` 的规则声明顺序
     * （能量(ジ/蓄能/聚能环) → 攻击 → 防御 → 特殊）—— 用户的原话是"能量类跑到防御类下面了，不符合直觉"。
     * ⚠️ 此前两轮我都把"防御优先"错用在这里：**"防御优先"说的是回合日志里的显示顺序**（见 roundLineParts
     * 与 evText 的显示排序），与这个格子无关。顺带：`R.skills` 的顺序始终是 AI 合法集与训练口径的真源，绝不能动。 */
    const sdOrder = R.skills.map(function (s, i) { return { s: s, i: i }; });
    for (const sdItem of sdOrder) {
      const s = sdItem.s;
      const modeOk = S.canUseSkillInMode(st, s.key);
      const cd = (st.p[0].cooldown[s.key] || 0);
      const multiOnly = R.MULTI_ONLY.indexOf(s.key) >= 0 && !S.canUseSkillInMode(st, s.key);
      const la = legalMap[s.key];
      const unaffordable = !multiOnly && modeOk && cd <= 0 && !st.over && (!la || !la.affordable);
      const btn = document.createElement('button');
      btn.className = 'skillbtn c-' + s.cat;
      const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = s.name;
      const ct = document.createElement('span'); ct.className = 'ct';
      ct.textContent = multiOnly ? '多人模式' : (cd > 0 ? ('禁用剩' + cd + '回合') : costLabel(s));
      btn.appendChild(nm); btn.appendChild(ct);
      /* v1.5.173（用户实测报"摄魂 bug 没解决"追到的真凶）：**卡面文案与引擎门槛不同源**。
       * `SK.DRAIN` 的 `desc` 把窗口写死成"HP 小于等于 1"（R25 原口径），而长程按 `state.mode.drainHpMax=3` 放行（`RULES-NP.md` N24）
       * ⇒ HP 2 上格子按规则**应该亮**（也确实亮），提示却说 1 ⇒ 玩家读出来就是"血回上去了摄魂还能用"。
       * **引擎没错（实测 HP4/5 一律拒），错在那句话。**组装放在 `js/ui/skill-tip.js`（纯函数、单一来源，
       * 且 `rules.js` 是指纹五件套之一、不能为一个显示字符串换代），这样门 D131 能 headless 直接跑它。 */
      btn.title = '【' + CAT_NM[s.cat] + ' · 优先级' + (s.pri || 3) + '】手势：' + (s.gesture || '—') + '\n' + Tip.of(R, st, s);
      btn.disabled = multiOnly || !modeOk || cd > 0 || st.over || unaffordable;
      if (multiOnly) btn.title += '\n（多人专用（2 人局不开放），见 docs/RULES-NP.md N14）';
      else if (!modeOk) btn.title += '\n（本模式不可用）';
      else if (unaffordable) btn.title += '\n（ジ/珠子不足或条件不满足，本回合无法发动）';
      btn.onclick = function () { pickSkill(s.key); };
      grid.appendChild(btn);
    }
  }

  /* ---------- 对局流程 ---------- */
  function hint(txt) { $('battle-hint').textContent = txt; }
  function logClear(first) {
    const lb = $('logbox'); lb.innerHTML = '';
    if (first) addLog('div', 'rnd', esc(first));
  }
  function addLog(tag, cls, html) {
    const lb = $('logbox');
    const el = document.createElement(tag);
    el.className = cls || 'ev';
    el.innerHTML = html;
    lb.appendChild(el);
    lb.scrollTop = lb.scrollHeight;
  }
  /* ===== v1.5.22（用户裁定）：结算事件行的**显示顺序**（纯显示层，引擎结算顺序一行不动）=====
   * 三条规则：① **防御类先于攻击类**；② **被无效的先于使其无效的**；③ **原技能先于镜面反射复制出来的**。
   * 实现：给每条事件算一个显示档 (tier, sub)，然后**稳定排序**（同档保持引擎顺序，绝不打乱无关事件）：
   *   tier 0 防御类 · 1 中立 · 2 攻击类 · 3 **镜像复制**（复制出来的一律最后 ⇒ 原技能必然在它前面）
   *   sub  0 普通/**被无效** · 1 **使其无效**（cancel/clash/thunderRing）⇒ "被无效先、使其无效后"
   * ⚠️ 只排**渲染用的副本**（`.map` 出新数组），`state.events` 本身绝不排序 —— 引擎怎么结算就怎么结算。
   * 反证（np-test D38）：把 logEvents 改回直接遍历 list、或去掉 tier/sub ⇒ D38 立刻红。 */
  const EV_TIER_DEF = { guardSet: 1, holoSet: 1, blocked: 1, reflect: 1, voidImmune: 1, curseBlock: 1, rodBlock: 1, rod: 1 };
  /* v1.5.140（用户实机报的显示顺序 bug）：同是防御档，**"摆出架势"必须排在"它的挡下/免疫/反弹"之前**。
   * 引擎按发射顺序记事件（攻击方的结算常早于防守方的 guardSet ⇒ `blocked` 先发射），
   * 渲染层不重排就会出现"先看到挡下、后看到摆出"的先果后因（results/93-2 三局抓到 R9/R10/R23）。 */
  const EV_SUB_RESULT = { blocked: 1, reflect: 1, voidImmune: 1, curseBlock: 1, rodBlock: 1 };
  const EV_TIER_ATK = { damage: 1, headshot: 1, bigTChain: 1, ban: 1, hidden: 1 };
  const EV_TIER_MIRROR = { mirror: 1, mirrorCopySelf: 1, mirrorNoEffect: 1 };
  const EV_SUB_VOIDER = { cancel: 1, clash: 1, thunderRing: 1 };
  function evDisplayRank(e) {
    if (!e) return [1, 0];
    /* v1.5.23（用户实测 22 回合）：**死亡结算必须排在造成它的伤害之后**。
     * 第一版把 `death` 当"中立"⇒ 它跑到了伤害前面（"先死再掉血"，很搞笑）。 */
    if (e.type === 'death') return [2, 1];
    if (EV_TIER_MIRROR[e.type] || (e.type === 'guardSet' && e.copied)) return [3, 0];
    if (EV_SUB_VOIDER[e.type]) return [1, 1];
    if (EV_TIER_DEF[e.type]) return [0, EV_SUB_RESULT[e.type] ? 1 : 0];
    if (EV_TIER_ATK[e.type]) return [2, 0];
    return [1, 0];
  }
  function orderEventsForDisplay(list) {
    return list.map(function (e, i) { return { e: e, i: i, k: evDisplayRank(e) }; })
      .sort(function (a, b) { return (a.k[0] - b.k[0]) || (a.k[1] - b.k[1]) || (a.i - b.i); })
      .map(function (o) { return o.e; });
  }
  function logEvents(list, rootCls) {
    for (const e of orderEventsForDisplay(list)) {
      const t = evText(e, list);   // v1.5.253：把**整回合事件表**传进去（连带是否真打中要它才判得出）
      if (t) addLog('div', t.cls || 'ev', t.html);
    }
  }

  function ensureRound() {
    if (B.roundStarted) return;
    X.startTurn(B.state);
    // startTurn 副作用（梦魇/回魂等）立即入日志
    const evs = B.state.events;
    if (B.evCursor < evs.length) logEvents(evs.slice(B.evCursor));
    B.evCursor = evs.length;
    B.roundStarted = true;
    // startTurn 的副作用可能改变资源（如回魂=无限能量），同步刷新技能可用性
    buildSkillGrid(); renderSide(0); renderSide(1);
    if (B.state.over) { finish(); return; }
  }

  function pickSkill(key) {
    if (B.state.over) return;
    /* v1.5.80（第八轮复核 §5-②，tools/ui-probe.mjs 复现）：结算期间（B.locked）点击被**静默丢弃**。
     * 现在明确告知。**不做排队**：排队会引入"迟到的动作"这类新状态，风险大于收益。 */
    if (B.locked) { hint('本回合正在结算，请等对手出手完再出招 —— 你刚才的点击没有生效。'); return; }
    /* v1.5.80（§5-①，探针复现）：目标弹窗开着时再点别的技能，原本会**静默替换**弹窗
     *（更糟的是点自指向技能会**立即落子** ⇒ 误触白扔一回合）。现在显式取消并留痕。 */
    if (B.picking) {
      const was = B.picking.key;
      B.picking = null; closeModal();
      addLog('div', 'ev dim', '（已放弃【' + skillName(was) + '】的目标选择）');
    }
    if (key === R.SK.CHARGE) {
      B.picking = { key: key, bead: null };
      openModal('<h3>蓄能：存哪种能量珠？</h3>', [
        { label: '⚡ 电能（电磁炮用）', fn: function () { B.picking = null; closeModal(); doPickMulti(key, 'elec'); } },
        { label: '💥 爆破能（激光眼用）', fn: function () { B.picking = null; closeModal(); doPickMulti(key, 'boom'); } },
        { label: '↩ 取消', fn: function () { cancelPick(); } }
      ]);
      hint('请选择要存的能量珠种类（Esc 或「取消」可放弃）。');
      return;
    }
    doPickMulti(key, null);
  }

  /* ===== v1.6.6：2 人那一套独立的出招/结算分支已删除 =====
   * 原来这里是 `doPick`（2 人版：只问一个 AI、日志自己拼一行、transcript 自己写一份），
   * 与下面的 `doPickMulti`（N 人版）是**同一件事的两份实现** —— 而 v1.5.21 已经把"拼回合行 + 写 transcript"
   * 抽成单一来源（`roundLineParts` / `pushTranscript`）给多人那条路用，2 人这条路一直在自己抄一份。
   * 现在难度阶梯要跨人数统一（`DIFF_TIERS`），两路并存就意味着"阶梯的行为要测两遍、门要钉两遍"，
   * 而 2 人版的日志格式还漏掉多人版后来修的每一项（死亡席不占位、目标显示、观战回合也进 transcript）。
   * ⇒ 2 人走 N 人那条路：`doPickMulti` 在"只有一个对手"时不弹目标框（`opps.length > 1` 才弹），
   *   座位名仍是 `你/电脑`（`state.js:defaultNames(2)`），回合行由 `roundLineParts` 打出 `你=【…】 电脑=【…】`。
   * 反证：这条合并的可玩性不是靠"我看代码觉得等价"，是 smoke 的 12 格扫描 + battle 真打（2 人 × 三档血量各起一局）。 */
  /* ---------- 多人（3-5）对局 ---------- */
  /* 3P 冠军包（多人自对战训练产物）：不兼容/缺失返回 null */
  let multiChampCache, multiChampFrom;   // v1.5.10：multiChampFrom ∈ 'local'（本机自训/导入）| 'builtin'（内置包）
  function resetMultiChampCache() { multiChampCache = undefined; multiChampFrom = undefined; }
  function loadMultiChamp() {
    if (multiChampCache !== undefined) return multiChampCache;
    let pack = null;
    try {
      const raw = localStorage.getItem('epirus.champion3p');
      if (raw) pack = JSON.parse(raw);
    } catch (e) { /* ignore */ }
    multiChampCache = P.loadGame(pack);                      // 严格 → 状态段只增的旧包**逐位等价嵌入**（v8 兼容）
    multiChampFrom = multiChampCache ? 'local' : null;
    if (!multiChampCache && typeof window.EPIRUS_CHAMPION_3P !== 'undefined') {
      multiChampCache = P.loadGame(window.EPIRUS_CHAMPION_3P);   // 回退内置包
      multiChampFrom = multiChampCache ? 'builtin' : null;
    }
    return multiChampCache;
  }
  /* ===== v1.6.6：2 人桌的底层包 = 2P 那颗（v1.0 为 1v1 训的），≥3 人 = 3P 那颗 =====
   * 理由不是"历来如此"，是 §E286 的实测：3P 那颗在 1v1 上是**分布外**的
   *   （同一把尺、贪心档：3P 包让替身夺冠 27.5% ‖ 2P 包只让 15.5%），
   *   而且剂量梯在 2 人桌上**反号**（3P 包 ε=0 的 27.5% 竟比 ε=.5 的 19.4% 还软）⇒ 用它当"困难"档是假档。
   * 换成 2P 那颗之后同一串剂量重新单调（15.5 → 20.1 → 24.1 → 24.5，见 `DIFF_TIERS` 的 note）。
   * 附带好处：「训练场」练出来的 2P 冠军重新有地方可玩（v1.6.6 之前页面只有"困难"一个槽用它，而那个槽已被剂量阶梯取代）。
   * ⚠ 两槽的"本机优先"语义保持一致：2P 走 `Champ.store.load()`（键 `epirus.champion.v3`，来源由它自己回传）。 */
  function champForCount(n) {
    if ((n || 2) > 2) {
      const p = loadMultiChamp();
      return { params: p || null, from: p ? multiChampFrom : null };
    }
    const c = Champ.store.load();
    if (c) return { params: c, from: Champ.store.lastSource };
    const p3 = loadMultiChamp();   // 2P 那颗也没有 ⇒ 回退 3P 并**明说**（不许静默换包）
    return { params: p3 || null, from: p3 ? multiChampFrom + '·回退(2P 槽空)' : null };
  }
  /* ===== v1.6.63（§E590）冠军池：≥3 人桌逐席各抽一枚 =====
   * 契约 `docs/POOL-CONTRACT.md` §3/§4。真源 `champion-map/pool-members.tsv`，页面只读它的派生物
   *   `js/bundled-champion-pool.js`（**内嵌不 fetch**：产品入口是双击 index.html，`file://` 取不到本地文件）。
   * ⚠ 组成是**纯派生**（`compose(该档成员, n-1, rng(state.slotSalt))`）⇒ 同一局不论问第几席、第几回合答案都同，
   *   所以这里**故意不设缓存**（有缓存就有"缓存与局不同步"这一类错）。`cloneState` 走 JSON 往返会带上 slotSalt。
   * ⚠ 抽签实现不在本文件重写 —— 走 `js/pool-draw.js` 那一份（门 `D234` 与量具 `tools/probe-pool.mjs` 用的是同一份）。 */
  /** 降级分三种原因，**必须分开说**（浏览器实机跑出来的第一条就是这句：默认档"普通"没配成员时，
   *  旧文案会写"bundle 缺失或该档池空"，而 bundle 其实加载得好好的 ⇒ 把"还没配"说成了"坏了"）。 */
  function poolOffReasonOf(k, tier) {
    const slot = POOLS[k], S = slot.st;
    loadPoolOf(k);
    const back = k === 'p2' ? '退回单包（那一枚 2P 冠军）' : '四席同一枚（内置槽）';
    if (S.status === 'no-bundle') return slot.name + ' bundle 未加载 ⇒ ' + back;
    /* §E621：走到这里说明"这一次还没拿到全局"（bundle 的 defer 脚本还没执行），**不是**坏了；
     *   单独一句是为了下次有人读到它不会又去查 bundle 在不在（我这晚就是这么绕了一圈的）。 */
    if (S.status === 'not-yet') return slot.name + ' bundle 还没执行到（脚本顺序，不是故障）⇒ ' + back;
    if (!S.members || !S.members.length) return slot.name + ' bundle 里一枚都解不开 ⇒ ' + back;
    const n = S.members.filter(function (m) { return m.tier === (tier && tier.pool); }).length;
    if (!n) return '该难度档（' + (tier && tier.pool) + '）还没配' + slot.name + '成员 ⇒ ' + back + '，**不是故障**';
    return null;
  }
  function poolOffReason(tier) { return poolOffReasonOf('p3', tier); }
  function poolOffReason2(tier) { return poolOffReasonOf('p2', tier); }
  /* §E599（10-12）：池层**两份**（多人 3P 与 2P 各一份），而逻辑**只写一遍** —— 抄第二份是本仓栽得最多的一种错。
   *   2P 池 = **2P 原生**包（`js/bundled-champion-pool-2p.js`，真源 `champion-map/pool-members-2p.tsv`）；
   *   用户 10-12 裁定：2P 每局只要一个对手 ⇒ 成员不必多；**种类 <5 的不要**。
   *   ⚠ 老注释里"`n<=2` 完全走老路"的理由（§E286：3P 包在 1v1 上是分布外）**对 2P 原生包不成立** ⇒
   *     2P 走的是另一份池，不是把 3P 池搬到 2 人桌。 */
  const POOLS = {
    p3: { g: 'EPIRUS_CHAMPION_POOL', st: { members: null, params: {}, bad: [], status: 'init' }, name: '池' },
    p2: { g: 'EPIRUS_CHAMPION_POOL_2P', st: { members: null, params: {}, bad: [], status: 'init' }, name: '2P 池' },
  };
  const POOL = POOLS.p3.st;                      /* 旧引用（`POOL.bad` 等）继续指向 3P 那一份 */
  function loadPoolOf(k, force) {
    const slot = POOLS[k], S = slot.st;
    if (S.members !== null && !force) return S.members;
    const raw = (typeof window !== 'undefined' && window[slot.g]) || null;
    if (!raw || !Array.isArray(raw.members)) {
      /* §E621 修法 B（用户 10-15 裁定：「按 b 修好 2p 冠军池的问题」）：**"这一次还没拿到全局"不是"bundle 坏了"**。
       *   原来这里把 `S.members` 落成 `[]` 再记 `status='no-bundle'`，而上面那句 `members !== null` 就 return
       *   ⇒ 首屏那一次"还没有"被**永久缓存**：`ui.js` 是同步脚本、两份 pool bundle 是 `defer`（defer 永远在解析完之后执行），
       *   而默认人数 = 2 ⇒ 任何回显路径都会在这里先摸一次 p2 ⇒ **2 人桌的池自 §E599 起从未生效过**（日志 DONE-14 / 待裁 #28）。
       *   现在：保持 `members = null`（下一次调用再试），状态单独记 `'not-yet'`，原因句与真·无 bundle 分开说（契约 §4：不许静默，也不许把"还没"说成"坏了"——
       *   这句正是上面那条注释早就警告过的同一件事，这次是它自己的另一半被踩中）。 */
      /* 两种"拿不到"要分开说，否则这句又变成第二个假原因：文档还在解析 ⇒ 真是脚本顺序问题（还会再来一次）；
       *   解析已经完了还拿不到 ⇒ bundle 真的没加载/形状不对（这句才允许说"未加载"）。 */
      const parsing = (typeof document === 'undefined') || document.readyState === 'loading';
      S.members = null; S.params = {}; S.bad = []; S.status = parsing ? 'not-yet' : 'no-bundle'; return S.members;
    }
    S.members = []; S.params = {}; S.bad = []; S.status = 'ok';
    /* ⚠ 解包用本文件顶上的别名 `P = window.EpirusPolicy`（`unpack` 挂在那里）——
     *   第一版这里写成 `window.EpirusChampionPack.unpack` 是**错的**：那个对象只导出 `extract`/`version`，
     *   于是全部"解不开"、静默退回单包（浏览器实机跑出来的：`PK.unpack is not a function`）。
     *   `allowLegacy=true`：池成员跨代（3P 侧 `K2`/`SHIPPED-Ldemo` 是 v6 形状、`T8-s114` 是 v7；
     *   2P 侧是 2P 原生形状）⇒ 与 `tools/*` 侧同一口径；权重身份已由 `tools/build-pool-bundle.mjs` 逐条重算 wid 与表对账过。 */
    /* ⚠ 解包用本文件顶上的别名 `P = window.EpirusPolicy`（`unpack` 挂在那里）——
     *   第一版这里写成 `window.EpirusChampionPack.unpack` 是**错的**：那个对象只导出 `extract`/`version`，
     *   于是全部"解不开"、静默退回单包（浏览器实机跑出来的：`PK.unpack is not a function`）。
     *   `allowLegacy=true`：池成员跨代（3P 侧 `K2`/`SHIPPED-Ldemo` 是 v6 形状、`T8-s114` 是 v7；
     *   2P 侧是 2P 原生形状）⇒ 与 `tools/*` 侧同一口径；权重身份已由 `tools/build-pool-bundle.mjs` 逐条重算 wid 与表对账过。 */
    for (const m of raw.members) {
      let p = null;
      try { p = P.unpack(m.pack, true); } catch (e) { p = null; }
      if (!p) { S.bad.push(m.id); continue; }                    /* 契约 §4：解不出的整枚出局并点名，不许拿 null 顶上 */
      S.members.push({ id: m.id, wid: m.wid, tier: m.tier });
      S.params[m.id] = p;
    }
    return S.members;
  }
  function loadPool(force) { return loadPoolOf('p3', force); }
  function loadPool2(force) { return loadPoolOf('p2', force); }
  /* §E600-B（用户 10-13 裁定：「把启发式随机脚本塞到弱池子里面」）：掺几席、掺谁由 `bots.js` 的
   *   `DIFF_TIERS[].scriptMix` 说话，而**推导只有一处** —— `js/pool-draw.js` 的 `scriptSeats`。
   *   页面与量具（`tools/probe-pool.mjs`）都调它，否则量的是"我以为产品会怎么掺"（规矩 134 那一族）。
   *   规则（写在 `pool-draw.js` 里）：① 至少留 `min` 席**包**（2P 只有 1 席 AI ⇒ 掺不动，池不许被整个盖掉）
   *   ② 认不出的风格 id 跳过并说出来（契约 §4：降级不许静默）③ 位置由 `compose` 用同一个 rand 决定。 */
  function scriptMixFor(tier, aiSeats) {
    const D = window.EpirusPoolDraw;
    if (!D || typeof D.scriptSeats !== 'function') return null;
    const styles = (window.EpirusBots && window.EpirusBots.STYLES) || [];
    return D.scriptSeats(tier, aiSeats, styles);
  }
  function poolDrawFor(state, tier, n) {
    const D = window.EpirusPoolDraw;
    if (!D || !tier || !tier.pool) return null;
    const k = (n > 2) ? 'p3' : 'p2';                       /* §E599：2P 走 2P 原生池那一份（不是把 3P 池搬过去） */
    /* §E609：这一档该拿哪份名单、要不要按带加权 —— **推导只有一份**（`pool-draw.js` 的 `rosterFor`），
     *   页面不许自己判"mid 空了就换 mix"（那就是量具与产品两份实现，规矩 134 那一族）。 */
    const R = D.rosterFor(loadPoolOf(k), tier);
    const members = R.members;
    if (!members.length) return null;
    const aiSeats = Math.max(1, n - 1);                   /* 2P ⇒ 1 席 */
    const mix = scriptMixFor(tier, aiSeats);
    const draw = D.compose(members, aiSeats, D.rng((state && state.slotSalt >>> 0) || 1), mix && (mix.seats || typeof mix.p === 'number') ? mix : null, R.bandW);
    if (draw && mix && mix.note) draw.mixNote = mix.note;
    if (draw && R.note) draw.bandNote = R.note;           /* 这张池表还没拆带 ⇒ 必须说出来，不许静默退回 mid */
    return draw;
  }
  /** 这一席该用哪一枚。`n<=2` 完全走老路：§E286 实测 3P 包在 1v1 上是**分布外**的 ⇒ 把池搬到 2 人桌等于造一个假档。 */
  /* §E599（10-12）：`n<=2` **不再**短路 —— 2P 也走池，但走的是**2P 原生**那一份（用户裁定：每局一个对手、成员不必多）。
   *   老注释那句"3P 包在 1v1 上是分布外（§E286）⇒ 把池搬到 2 人桌等于造一个假档"**仍然成立**，
   *   正因为如此，2P 池的成员一律是 2P 考卷训出来的包（`pool-members-2p.tsv`），而不是 3P 池的成员。 */
  function champForSeat(pid, state, tier) {
    const n = (state && state.p && state.p.length) || (B.players || 2);
    const single = champForCount(n);
    const plan = poolPlan(state, tier, n);
    if (!plan.on) { if (plan.why) single.poolNote = plan.why; return single; }
    const draw = plan.draw;
    /* 2P 只抽 1 席 ⇒ 不论人类坐哪个 pid，AI 那一席永远取 `seats[0]`（3P/4P/5P 才按 pid 对位） */
    const m = draw.seats.length === 1 ? draw.seats[0] : draw.seats[(pid || 1) - 1];
    /* §E600-B：这一席是**脚本席**（简单档掺进来的启发式脚本）⇒ 不查包，直接给脚本的 pick。
     *   认不出这个风格 = 本席退回单包并说出来（契约 §4 同一条纪律，不许静默换人）。 */
    if (m && m.kind === 'script') {
      const sst = styleOf(m.id);
      if (!sst) { single.poolNote = '脚本席 ' + m.id + ' 认不出 ⇒ 本席退回单包'; single.poolDraw = draw; return single; }
      return { params: null, scriptPick: sst.pick, scriptName: sst.name, from: 'script:' + m.id,
        poolDraw: draw, seatId: m.id, poolNote: draw.mixNote || null };
    }
    const P2 = plan.two ? POOLS.p2.st : POOL;
    const p = m && P2.params[m.id];
    if (!p) { single.poolNote = '席位 ' + pid + ' 抽到的成员解不开 ⇒ 本席退回单包'; single.poolDraw = draw; return single; }
    return { params: p, from: (plan.two ? 'pool2:' : 'pool:') + m.id, poolDraw: draw, seatId: m.id,
      poolNote: (draw.allSame && !plan.two) ? '该档池只够 ' + draw.seats.length + ' 席 ⇒ 四席全同（降级，已明说）' : null };
  }
  /** 池到底生不生效，**只这一处判**（v1.6.63 内的一次修正，未另起版本号）。
   *   为什么要有这个函数：`champForSeat`（真决策）先查了"本机导入优先"，而 `aiInfo`（席位标签的回显）**没查**就报"池·mid 本局=…"
   *   ⇒ 10-12 03:0x~03:1x 浏览器实机抓到（时间更正：这里原写 04:1x，按 `ui.js` mtime 03:12:39 与提交 `e318f15` 03:14 改）：
   *   只要用户在这台机器上训练/导入过 3P 冠军（页面训练完**自动**写
   *   `localStorage['epirus.champion3p']`），五人桌实际四席都用他那枚，而标签说池在跑。
   *   这与契约 §4"降级不许静默"是同一条纪律的另一面：**回显与决策必须走同一个判定**，否则修好一边另一边还是撒谎。 */
  function poolPlan(state, tier, n) {
    if (!tier || !tier.pool) return { on: false, local: false, two: false, why: null, draw: null };
    const two = !(n > 2);
    const single = champForCount(n);
    if (single.from === 'local') return { on: false, local: true, two: two, why: '本机导入优先 ⇒ 池不生效（' + (two ? '对手用你这枚' : '四席都用你这枚') + '）', draw: null };
    const draw = poolDrawFor(state, tier, n);
    if (!draw || !draw.seats.length) {
      return { on: false, local: false, two: two, draw: null,
        why: (two ? poolOffReason2(tier) : poolOffReason(tier)) || '池未生效（原因未归类）⇒ 退回单包' };
    }
    return { on: true, local: false, two: two, why: null, draw: draw };
  }
  /* ===== v1.6.6 兜底脚本（冠军包拿不到时）=====
   * 这里必须是个**定义得住**的函数：`chooseAIMulti` 那行历史上引用过 `DN.hard.pick`，而 `DN` 的声明在 v1.3.22
   * 就删了 ⇒ 那条"显式回退"其实是 ReferenceError（门 D227③e 钉这一处不许再出现未定义的名字）。
   * 桌形决定用哪只：≥3 人 = 多人强档脚本，2 人 = 自适应（历史上 2 人困难档就是 `pickAdaptive`）。 */
  function fallbackPickFor(n) {
    return (n || 2) > 2 ? Bots.pickMultiStrong : Bots.pickAdaptive;
  }
  function fallbackNameFor(n) {
    return ((n || 2) > 2 ? '脚本·多人强档' : '脚本·自适应（2 人）') + '（冠军包缺失/不兼容，已回退）';
  }
  /* v1.5.10（用户要求）：把本机自训/导入的冠军清掉、改回**内置冠军**。
   * 为什么需要：页面优先读 `localStorage['epirus.champion3p']` ⇒ 换 bundle 对老用户无效
   * （REVIEW §11.1 实测踩过：换包后浏览器对战测试其实还在打旧冠军）。
   * ===== v1.5.131（handoff §4-10；复核 §4-4 第 3 条也点到过）：**2P 槽位原先漏了** =====
   * 2P 的本机冠军存在 **`epirus.champion.v3`**（`js/train/trainer.js:6`），而本函数原先只清 3P 那个键
   * ⇒ 本地训过冠军的用户**永远打自己那个旧包**：v1.5.130 刚把线上 2P 冠军从"被珠爆发线 100% 打穿"
   * 修到 `examGateOk:true`，**这一整类用户拿不到**；而按钮 tooltip 写着"清除本机自训/导入的冠军、
   * 改回内置冠军"= **假承诺**。两个槽位的语义本来就一样（都是"改回内置"）⇒ 一起清。
   * 反证：`tools/battle-test.mjs` 同时种两个键再点这个按钮 —— 修前只有 3P 键会消失。 */
  function useBuiltinChampion() {
    let had3 = false, had2 = false;
    try {
      had3 = !!localStorage.getItem('epirus.champion3p');
      localStorage.removeItem('epirus.champion3p');
      had2 = !!localStorage.getItem('epirus.champion.v3');
      localStorage.removeItem('epirus.champion.v3');
    } catch (e) { /* ignore */ }
    resetMultiChampCache();
    const loaded = loadMultiChamp();
    /* ⚠️ 顺序要紧：`newGame()` 会把提示刷成"请选择技能出招"⇒ 提示必须放在它后面
     * （v1.5.10 第一版写反了，被 tools/battle-test.mjs 的 "提示告知已改回内置冠军" 抓到）。 */
    /* v1.5.131：2P 侧也要重开一局（原先只判 `B.multi`）。2P 的 chooser **每次决策都重读**
     * `Champ.store.load()`（`chooseAI:574`）⇒ 清键下次决策即生效；重开只是让这一局从干净状态开始。 */
    if (tierIsChamp(B.diff)) newGame();   // v1.6.6：2 人/多人同一条路 ⇒ 不再分"只有 hard 槽才重开"
    renderChampState();   // 训练场「当前冠军」必须立刻反映"已改回内置"
    hint(had3 || had2
      ? ('已清除本机冠军（' + [(had3 ? '多人' : ''), (had2 ? '2 人' : '')].filter(Boolean).join(' + ') +
         '），改回内置冠军（' + (loaded ? '多人包已加载' : '⚠ 多人内置包缺失/不兼容') + '）')
      : '本机没有自训/导入的冠军，本来就在用内置冠军');
    return { had: had3, had2: had2, loaded: !!loaded, from: multiChampFrom || null };
  }
  /* 当前对局实际用的是哪个 AI（供 UI 显示与探针断言） */
  function styleOf(id) {
    const list = (Bots.STYLES || []);
    for (let i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }
  /* 难度档的**唯一**查询口（表在 `js/train/bots.js` 的 `DIFF_TIERS` ⇒ 工具与门读同一张表，不抄第二份）。 */
  function tierOf(id) {
    const list = (Bots.DIFF_TIERS || []);
    for (let i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }
  function tierIsChamp(id) { const t = tierOf(id); return !!t && t.kind === 'champ'; }
  /* 难度下拉：**全人数同一张阶梯**（v1.6.6 起不再按人数换列表；旧"简单/中等/困难"三档按用户裁定作废）。
   * 组一 = 剂量档（含"极限·猎队"那一档脚本）；组二 = 其余风格，明确标"强度随桌形漂，不是难度档"。 */
  function syncDiffOptions() {
    const sel = $('sel-diff'); if (!sel) return;
    const raw = Bots.DIFF_TIERS || [];
    const want = raw.map(function (x) { return { v: x.id, t: x.name }; });
    /* ⚠ 去重必须拿**原始档位对象**比（第一版在这里比的是已经映射成 `{v,t}` 的列表，`.style` 恒 undefined ⇒
     *   「极限 · 读招」和「风格 · 读招反制」同时出现 = 同一个脚本占两个格子，玩家以为是两档）。 */
    const claimed = {};
    raw.forEach(function (t) { if (t.kind === 'style' && t.style) claimed[t.style] = 1; });
    (Bots.STYLES || []).forEach(function (s) {
      if (!claimed[s.id]) want.push({ v: s.id, t: '风格 · ' + s.name });
    });
    const valid = want.some(function (o) { return o.v === B.diff; });
    if (!valid) B.diff = Bots.DIFF_DEFAULT || (want[0] && want[0].v) || 'lv:regular';
    sel.innerHTML = want.map(function (o) { return '<option value="' + o.v + '">' + o.t + '</option>'; }).join('');
    sel.value = B.diff;
    if (!sel.value && want.length) { sel.value = want[0].v; B.diff = want[0].v; }
  }
  /* ===== §E667（用户要求）：导出的对局记录要写得出"本次的对手是谁" =====
   * 逐席标签取自 `aiInfo().poolDraw.seats` —— 与 `champForSeat` 同一个纯派生（同 slotSalt 同答案），
   *   所以"回显"与"实际决策"不会分叉（`ship-pool` 那条 ⑨ 腿盯的就是这件事，故这里也**不许**自己调 `poolDrawFor`）。
   * ⚠ 必须在**开局当场**算一次存进 `B`，不许导出时再问：① 难度下拉是"对局中即时生效"、不换局（`bind()` 里 `#sel-diff` 那条 onchange），
   *   事后读到的是最后那一档；② 池生不生效第一条判的是"本机有没有导入冠军"，而那个键在局中可被训练/导入改写
   *   ⇒ 事后重推会把"这局到底是谁在打"说成"此刻会是谁在打"。 */
  function seatOppLabel(info) {
    const d = info && info.poolDraw;
    if (!d || !d.seats || !d.seats.length) return info ? info.source : '';   /* 非池档（风格/单包/兜底）：source 本身就是"谁在打" */
    const seats = B.state.p.slice(1);                      /* AI 席 = pid 1..N-1，与 draw.seats 同序 */
    const one = d.seats.length === 1;                      /* 2P 只抽一席 ⇒ 每一席同取 seats[0]（与 champForSeat 一致） */
    const who = seats.map(function (p, i) {
      const m = d.seats[one ? 0 : i];
      if (!m) return p.name + '=未抽到';
      /* §E600-B 同一条纪律：脚本席要一眼看得出是脚本，别读起来像一枚包的名字 */
      return p.name + '=' + (m.kind === 'script' ? '脚本·' + ((styleOf(m.id) || {}).name || m.id) : m.id);
    }).join('  ');
    return who + (d.scriptSeats ? '（掺脚本 ' + d.scriptSeats + ' 席）' : '') +
      (d.mixNote ? ' ⚠' + d.mixNote : '') + (d.bandNote ? ' ⚠' + d.bandNote : '') +
      (d.allSame ? ' ⚠各席全同：该档成员不足' : '');
  }

  function aiInfo() {
    /* v1.6.6：一条阶梯、一种写法。原来这里是两分支（2 人看 `Champ.store`、多人看 `multiChampFrom`），
     * 因为页面有两条 AI 路；现在路只有一条，"用的是哪颗包"当场问 `champForCount()`（它才是判定处，这里只回显）。 */
    const tier = tierOf(B.diff);
    if (!tier) { const st = styleOf(B.diff); return { source: '风格·' + (st ? st.name : B.diff), champ: false }; }
    if (tier.kind === 'style') {
      const st = styleOf(tier.style);
      return { source: '风格·' + (st ? st.name : tier.style) + '（' + tier.name + '）', champ: false, tier: tier.id };
    }
    const cf = champForCount(B.players || 2);
    const packLabel = (B.players || 2) > 2 ? '3P' : '2P';
    /* v1.6.63（§E590）池生效时这里**必须说得出逐席是谁**（契约 §4：降级不许静默）。
     *   组成与 `champForSeat` 用的是同一个纯派生（同 slotSalt 同答案）⇒ 回显与实际决策不会分叉。 */
    if (tier.pool) {
      const plan = poolPlan(B.state, tier, B.players || 2);
      const d = plan.draw;
      if (plan.on && d && d.seats.length) {
        const S = plan.two ? POOLS.p2.st : POOL;
        const nm = plan.two ? '2P池' : '池';
        /* §E609 这一行必须说得出"本档实际从哪些带抽"：mix 生效时还写 `mid(0 枚)` 就是骗人，
         *   而走退路（这张表没拆带）时不写出来就是静默降级（契约 §4）。推导仍只有一份：`rosterFor`。 */
        const RD = (window.EpirusPoolDraw && window.EpirusPoolDraw.rosterFor) ? window.EpirusPoolDraw.rosterFor(S.members, tier) : null;
        const n = RD ? RD.members.length : S.members.filter(function (m) { return m.tier === tier.pool; }).length;
        const srcName = (RD && RD.bandW) ? (nm + '·两带混抽（' + n + ' 枚）') : (nm + '·' + tier.pool + '(' + n + ' 枚)');
        return {
          source: srcName + ' 本局=' +
            d.seats.map(function (s) {
              /* §E600-B：脚本席要一眼看得出是脚本（不然"本局=st:toolkit"读起来像一枚包的名字） */
              if (s.kind === 'script') { const q = styleOf(s.id); return '脚本·' + (q ? q.name : s.id); }
              return s.id;
            }).join('+') +
            (d.scriptSeats ? (' 掺脚本 ' + d.scriptSeats + ' 席') : '') +
            (d.bands ? ' 带比 ' + d.bands : '') +
            (d.mixNote ? ' ⚠' + d.mixNote : '') +
            (d.bandNote ? ' ⚠' + d.bandNote : '') +
            (d.allSame && !plan.two ? ' ⚠四席全同:该档成员不足' : '') +
            (S.bad.length ? ' ⚠出局:' + S.bad.join(',') : '') +
            ' · ' + tier.name + ' ε=' + tier.eps + '/k' + tier.epsK + '/' + tier.epsMode + (tier.ramp ? '·斜坡' : ''),
          champ: true, from: 'pool', tier: tier.id, eps: tier.eps, epsK: tier.epsK, epsMode: tier.epsMode,
          ramp: !!tier.ramp, poolDraw: d, allSame: !!d.allSame
        };
      }
    }
    if (!cf.params) return { source: fallbackNameFor(B.players || 2), champ: false, fallback: true, tier: tier.id };
    const from = cf.from === 'local' ? '本机自训/导入' : cf.from === 'builtin' ? '内置' : String(cf.from);
    const poolOff = tier.pool
      ? (cf.from === 'local'
        ? '（池未生效：本机导入优先 ⇒ ' + ((B.players || 2) > 2 ? '四席用你这枚' : '对手用你这枚') + '）'
        : '（' + (((B.players || 2) > 2) ? poolOffReason(tier) : poolOffReason2(tier)) + '）') : '';
    return {
      source: packLabel + ' 冠军（' + from + '）· ' + tier.name + ' ε=' + tier.eps + '/k' + tier.epsK + '/' + tier.epsMode + (tier.ramp ? '·斜坡' : '') + poolOff,
      champ: true, from: cf.from, tier: tier.id, eps: tier.eps, epsK: tier.epsK, epsMode: tier.epsMode, ramp: !!tier.ramp
    };
  }

  /* 目标启发：用训练器的 v2 口径（反锁 + 必杀优先 + 打领先者），避免互相抵消死循环 */
  function pickTargetFor(state, pid, key) {
    const T = window.EpirusTrainer;
    if (T && T.pickTargetN) return T.pickTargetN(state, pid, key);
    const def = R.byKey[key];
    if (!def || def.target === 'self') return null;
    const opps = S.opponentsOf(state, pid);
    if (!opps.length) return null;
    return opps[0];
  }

  /* 多人 AI：困难 = 3P 冠军（缺失则回退脚本自适应） */
  function chooseAIMulti(state, pid, legal) {
    /* ===== v1.5.30x · 页面侧调试旋钮：**在线对手模型 + 1-ply 重放搜索**（默认关）=====
     * 开法：控制台 `localStorage.setItem('epirus.beliefSearch','1')` ⇒ **下一手就生效**（不必重开一局）。
     * 为什么每次决策都重读一次 localStorage：这一档是给"实机对比手感"用的，不是发布特性 ⇒
     *   宁可多花微秒级的一次读，也不要"改了要刷新页面"那种会被误判成"没生效"的形状。
     * 关掉时 `evo.js` 里那条短路根本不进 ⇒ 现网行为逐字不变（凭据在门 D2xx 的三段式里，不是这句话里）。 */
    let bsOn = 0;
    try { bsOn = localStorage.getItem('epirus.beliefSearch') === '1' ? 1 : 0; } catch (e) { bsOn = 0; }
    if (Trainer.setBeliefSearch) Trainer.setBeliefSearch(bsOn);
    function finish(res) {
      const key = (typeof res === 'string') ? res : (res && res.key);
      const t1 = (res && typeof res === 'object' && res.target != null) ? res.target : pickTargetFor(state, pid, key);
      let t2 = null;
      if (key === R.SK.DUAL_GUN || key === R.SK.MIRROR) {
        const rest = S.opponentsOf(state, pid).filter(function (o) { return o !== t1; });
        t2 = rest.length ? rest[0] : null;
      }
      return { key: key, target: t1, target2: t2, bead: (res && typeof res === 'object' && (res.bead === 'elec' || res.bead === 'boom')) ? res.bead : null };
    }
    /* ===== v1.6.6：难度档由 `bots.js` 的 `DIFF_TIERS` 说话（用户指令 2「冠军作为底层但脚本探索概率很高」）=====
     * `kind:'style'` 的档（含最高一档"极限·猎队"）走脚本；`kind:'champ'` 的档 = **同一颗冠军包 + 一组探索剂量**。
     * 剂量 = (eps, epsK, epsMode, ramp) 四个值 ⇒ 它们**只在这一处**被消费，`tools/probe-diff-ladder.mjs` 量的也是这四个值。 */
    const tier = tierOf(B.diff);
    let scriptChooser = null;   /* §E600-B：这一档掺进来的脚本席登记在这里，交给函数尾**那一处**包装层调用 */
    if (tier && tier.kind === 'champ') {
      /* v1.6.63（§E590）：这里原来写 `champForCount(state.p.length)` ⇒ 四席拿到的是**同一枚**包。
       *   换成 `champForSeat(pid, state, tier)`（契约 §3.1：逐席各抽一枚、可重复、禁四席全同），
       *   下面那行剂量**一字没动** —— 难度与池是两根正交的轴（池决定桌上是谁，ε 决定他多昏手）。 */
      const cf = champForSeat(pid, state, tier);
      /* §E600-B：脚本席**不在这里出手**，只把脚本登记进 `scriptChooser` ⇒ 大雷那层包装在整个 `chooseAIMulti` 里
       *   只许有**一处**调用（门 D224⑫l 数的就是它），掺席既不会把"每几局看得见大雷"这条用途绕过去，
       *   也不会给页面留下第二份"包一层"的形状。落不下去就顺着原路走到函数尾那一处返回。 */
      if (cf.scriptPick) scriptChooser = cf.scriptPick;
      const c = cf.params;
      if (c) {
        B.aiFallback = false;
        const base = legal.filter(function (l) { return l.affordable; });
        const legalForAI = base.length ? base : [{ key: R.SK.JI, affordable: true }];
        /* ===== v1.5.139 → v1.5.141（两次用户实机裁定叠出来的这一行）=====
         * 浏览器冠军 = softmax(0.15) + **键级探索**（探索时只在网络打分前 K 的**不同技能键**里均匀选，
         * 键内取最优候选——目标仍由网络说了算）。机制在 evo.js `policyChooserN`；温度/eval 路径不动：
         * 训练与门禁调用 eps=0 ⇒ 读数逐字不变（全仓 eps>0 的只有这一行）。
         * v1.5.139：ε=0.25 全候选"昏手太多"（贴贴不引爆/天火空爆）⇒ 改 top5 键。对照（93 权重 · headless）：
         *   2 席长程镜像 ε=0 ⇒ 104 回合 0% 决胜；ε.25 全候选 ⇒ 56 回合/97% 但空爆 1.07/局；ε.4~.5 top5 ⇒ ~30 回合/100%。
         * v1.5.141（用户："这一版随机还可以，但**防御偏多**、**丢了集火和滚环**"）⇒ 降 ε 并加 `epsMode='soft'`
         *   （探索**不许**覆盖贪心选定的防御/聚能环，且探索集里不放防御键）。同包同装配 40 局/点（`tools/behavior-profile.mjs`）：
         *     ε.4 uniform：防御 26.4% · 攻击 23.2% · 环 0.0% · 集火 22.0% · 胜率 30% · 镜像破局 100%
         *     ε.4 soft   ：防御 22.8% · 攻击 23.9% · 环 0.2% · 集火 26.5% · 胜率 25% · 镜像破局 100%
         *   **ε.2 soft（现役）：防御 9.1% · 攻击 28.6% · 环 1.5% · 集火 34.1% · 胜率 33% · 镜像破局 100%**
         *     ε.2 uniform：防御 16.7% · 攻击 26.4% · 环 1.4% · 集火 26.7% · 胜率 35%（用户报的病它没治）
         *   代价如实记：昏手（被无效化的出手）3.0% ⇒ 6.2%，仍远低于 ε.25 全候选那代的 1.07 次/局空爆。
         * ===== v1.5.298（用户 09-29 上午裁定：随机性注入太早，第 1~3 回合逐步提升）=====
         * 病（用户实机 `results/G08-71/epirus-battle-15回合 (1).txt` 第 1 回合）：AI 摆【防御】，而那一回合
         *   **结构性地一无所挡** —— 所有攻击卡 ≥1 ジ，而第 1 回合人人 ep=0；架势又只活本回合
         *   （`resolve.js:guardOf` 读 `state.actions[pid]`，每回合 startTurn 清空）⇒ 不是"没挡到"，是**不可能挡到**，
         *   还净亏 1 ジ（防御与 ジ 同为 0 ジ 卡；实测第 2 回合开局 ep 0.00 ‖ 1.00）。
         * 归因（`tools/probe-round1-open.mjs`，两粒包 × 10000 局 × 逐座位，§E145）：
         *   ① **不是包**：ε=0 与近贪心两档的首手防御 **0.00%（0/40000 席）**；
         *   ② **不是温度**：只把第 1 回合温度压到 .001、ε 不动 ⇒ 与现役**逐字同局**（配对差 0.0000，n=3000）
         *      —— 首手 softmax 在 0.15 下已被 ジ 打满 ⇒ "斜坡温度"是白做的事，只坡 ε 就够；
         *   ③ **就是 ε**：现役档首手防御 14.91% ±0.18，且**剂量-反应吻合** —— 按 ε×(池内防御/池宽) 预测，
         *      epsK=5/3/2 三档预测 15.00/13.33/10.00%，实测 15.40/13.74/10.39%；仪器档直读第 1 回合
         *      "探索池 100% 含防御键、其中 79.9% 抽到了防御"。
         *   ⚠ 根因与边界记在 §E145：`evo.js` 里 `if (nonDef.length >= 2) pool = nonDef;` 是 v1.5.141 **有意留下**的
         *      退化分支（原注释"只有防御键可选时不过滤——否则退化成一个确定性的ジ"）。第 1 回合非防御可付卡只剩 ジ 一张
         *      ⇒ "探索不许凭空摆架势"整条失效。**它漏的不只第 1 回合**（现役包 · 3000 局 · 仪器直读）：
         *      ε 注入的防御占第 1 回合全部防御出手的 **100%**、第 3 回合的 **59%**、第 4+ 回合的 **75%**。
         *      改成 `>= 1` 能把**各回合**的凭空防御一次清干净（实测首手 0.00%、全局防御剖面回落到贪心基线；
         *      夺冠 92.47% ‖ 91.87% —— 两档是不同进程，这条**没做配对**，只当方向读），
         *      但那是 09-21 裁定的**逆改**，且长程镜像平均 24.6→31.3 回合、僵死局 0/300→2/300
         *      ⇒ 属"要不要推翻自己上一条裁定"的问题，留给用户裁；本次只兑现"第 1 回合不注入"。
         * 实测代价（同种子配对 n=10000 × 两粒包）：首手防御 −14.92pt [−15.27,−14.56]；对局长度 −0.24/−0.27 回合
         *   （**变短**）；"四席里有人夺冠" −1.00pt [−1.77,−0.23] ‖ −0.43pt [−1.23,+0.37] —— 两粒包符号不一致，
         *   这条尺量的是**四张同名包互相蚕食**（人人多 1 ジ ⇒ 内耗更快 ⇒ 异席的脚本替身更容易捡漏），不是包的强度，别当胜负读；
         *   长程镜像 300 局僵死 0/300（24.6→26.1 回合）⇒ 没有把 v1.5.139 请 ε 进来的那条用途堵回去。 */
        /* 剂量取值：`tier.ramp` 为真 ⇒ 走回合斜坡，**字面形状在 `js/train/bots.js` 的 `tierEps(tier, round)`**（这一行只调用它）；
         *   其余档 = 常数 ε。
         * ★ 为什么形状搬走了（10-12 晚）：原来斜坡的字面值 ui.js 与 `tools/probe-diff-ladder.mjs` **各抄一份**，
         *   下午那次"顶点 0.2→0.1"只改到了页面那份 ⇒ 量具在一种产品里不存在的剂量（第 2 回合 0.1 而不是 0.05）上出了 b5ceab1 的在册账。
         *   ⇒ 一份实现三处消费（页面 ‖ 阶梯尺 ‖ `eval-5p --eps-tier=` 出的头号尺 Hp）。D153 现在钉 `bots.js` 里那一份。
         *   `eps2`（2 人桌的常数剂量）仍在这里挑 —— "几个人才用它"是页面才知道的事。
         * ⚠ §E596（10-12 用户裁定「普通和困难调成 0.1，简单 0.2」）把这条斜坡的**顶点从 0.2 降到 0.1**：
         *   保住的是那条机制的形状 —— **第 1 回合仍然 ε=0**（§E145 的 14.91% 首手防御全部来自这个 0，改动就会把它放回来），
         *   改掉的只是"放开多少"：第 2 回合 0.05、第 3 回合起 0.1 ⇒ 默认档比 v1.5.298 以来**略强**（老手感的探索少了半档）。
         *   这是一次产品裁定，不是顺手改：D153 的钉法与 `D227`②c 的默认档元组都跟着重钉了。 */
        const epsForTier = Bots.tierEpsAt(tier, state.p.length, state.round);
        return finish(Trainer.pickChampion(state, pid, legalForAI, c, 0.15, epsForTier, tier.epsK, tier.epsMode));
      }
      if (!scriptChooser) B.aiFallback = true;                // 冠军缺失 → 显式回退，不静默（§E600-B：脚本席不算回退）
      /* v1.6.6 修的一处**自 v1.3.22 起就存在的死引用**：这一行历史上写的是 `DN.hard.pick(...)`，
       * 而 `const DN = Bots.DIFFICULTY_N` 在同一个提交（3462abf「对手风格即难度档」）里被删掉了 ⇒
       * 走进这条分支不是"回退"，是当场 `ReferenceError: DN is not defined`。
       * 触发条件不罕见：本机训练包损坏/版本不兼容 **且**内置包也解不开（我 10-04 把 2P bundle 的 meta 写成
       *   ASCII 引号那次正是这个形状 —— 页面 `EPIRUS_CHAMPION` 变 undefined，但因为没人点过这条分支所以没炸）。
       * 现在的回退按桌形选脚本（≥3 人用多人强档、2 人用自适应），与 `aiInfo()` 里那句标签同源（`fallbackNameFor`）。 */
      if (!scriptChooser) return finish(fallbackPickFor(state.p.length)(state, pid, legal));
      /* §E600-B：走到这里 = 这一席被抽成脚本席 ⇒ **不算回退**，也不在这里返回，顺着走到函数尾那一处包装层调用。 */
    }
    B.aiFallback = false;
    const st = styleOf(tier ? tier.style : B.diff) || styleOf(B.diff);
    /* v1.6.3（用户 10-03 夜裁定：「接到风格 bot 席，默认难度也看得见」）：这一行以前直接把脚本席交给 `st.pick`
     *   ⇒ 大雷那一档只路过冠军的 chooser（`pickChampion` 内部），而多人**默认难度是「读招反制」**（`syncDiffOptions`），
     *   实测五个具名难度各 40 局 = **0 张 / 200 局**（§E281）：用户要的"每四五局看得见"在默认玩法里一次都没发生。
     * ⇒ 现在用 `EpirusTrainer.wrapBigTPush` 包一层：**散列、目标、"打不出来就原样返回"全在那一份实现里**（这里不抄第二份），
     *   所以页面这一档和考卷/门禁量的是同一段代码；`BIGT_PUSH = 0` 时这层是纯透传（门 D224⑫c 钉）。
     * ⚠ v1.6.6 的形状变化：2 人桌现在**也**走这一行（页面只剩这一条 AI 路，见上面"doPick 已删除"那段）
     *   ⇒ 旧说法"2 人那条路不许包"（D224⑫h）已随之改写：钩子在同一处，但**2 人桌上这扇窗基本开不了**
     *   （要攒满 5 珠，而 1v1 里双方互相打，实测密度由 `probe-diff-ladder` 一并印出，不是"接了就一定看得见"）。 */
    return finish(Trainer.wrapBigTPush(scriptChooser || (st ? st.pick : Bots.pickBalanced))(state, pid, legal));
  }

  /* ===== v1.5.21：回合行与 transcript 的**单一真源** =====
   * 用户实测报的三个 bug 都在这两个函数上：
   *  ① 死掉的玩家仍在回合列表里出【ジ】（本回合没出手 + 已死 ⇒ 应显示【已淘汰】）；
   *  ② 人类死后自动观战那段（autoRunRest）**从不追加 transcript** ⇒ "导出对局记录"只到玩家死前；
   *  ③ 同处只写了"第 N 回合（观战）"，不显示任何人用了什么技能。
   * 解法：把"拼回合行"和"追加 transcript"抽到这里，正常回合与观战回合共用 ⇒ 不可能只改一处。 */
  function roundLineParts() {
    const N = B.state.p.length;
    const parts = [];
    for (let pid = 0; pid < N; pid++) {
      const p = B.state.p[pid];
      const a = B.state.actions[pid];
      /* 本回合没出手 + 已死 ⇒ 已淘汰。⚠️ 本回合刚死但出过手的人仍要显示他用了什么。 */
      if (!(a && a.key) && p.hp <= 0) { parts.push(p.name + '=【已淘汰】'); continue; }
      const tg = (a && a.target != null && a.target !== pid) ? '→' + B.state.p[a.target].name : '';
      const mk = (!a || a.outcome === 'ok') ? ''
        : (a.outcome === 'insufficient' ? '（ジ不足·未发动）' : a.outcome === 'banned' ? '（禁用无效）' : '（无效）');
      parts.push(p.name + '=【' + skillName(a ? a.key : R.SK.JI) + tg + '】' + mk);
    }
    return parts;
  }
  function pushTranscript(parts, events) {
    const lines = events.map(function (e) {
      const t = evText(e, events);
      return t ? t.html.replace(/<[^>]+>/g, '') : null;
    }).filter(Boolean);
    B.transcript.push({
      round: B.state.round, line: parts.join('  '),
      human: parts[0], ai: parts.slice(1).join(' '), lines: lines
    });
  }

  /* 人类玩家被淘汰后：AI 自行打完剩余回合（观战） */
  function autoRunRest() {
    let guard = 0;
    while (!B.state.over && B.state.p[0].hp <= 0 && guard++ < 200) {
      const idx0 = B.state.events.length;
      X.startTurn(B.state);
      if (B.state.over) break;
      const preState = S.cloneState(B.state);
      const N = B.state.p.length;
      const picks = [];
      for (let pid = 1; pid < N; pid++) {
        picks.push(preState.p[pid].hp > 0 ? chooseAIMulti(preState, pid, Play.legalActions(preState, pid)) : null);
      }
      for (let pid = 1; pid < N; pid++) {
        if (!picks[pid - 1]) continue;
        const b = B.state.p[pid];
        S.attemptAction(B.state, pid, picks[pid - 1].key, { bead: BeadChoice.of(b, picks[pid - 1].bead), target: picks[pid - 1].target, target2: picks[pid - 1].target2 });
      }
      X.resolveActions(B.state);
      X.endTurn(B.state);
      /* v1.5.21：观战回合也走同一套回合行 + 追加 transcript（此前只写"（观战）"且不落 transcript） */
      const parts = roundLineParts();
      addLog('div', 'rnd', '第 ' + B.state.round + ' 回合（观战）：' + parts.join('  '));
      logEvents(B.state.events.slice(idx0));
      pushTranscript(parts, B.state.events.slice(idx0));
      persistBattle();
    }
    B.evCursor = B.state.events.length;
    B.locked = false;
    B.roundStarted = false;
    if (B.state.over) finish();
  }

  /* 双枪射手：第二个目标 */
  function pickSecondTarget(key, bead, t1) {
    const opps = S.opponentsOf(B.state, 0).filter(function (o) { return o !== t1; });
    const title = key === R.SK.MIRROR ? '选择输出对象（目标 2/2）' : '选择目标 2/2';
    if (!opps.length) return doPickMulti(key, bead, t1, null);
    openModal('<h3>' + title + '：' + R.byKey[key].name + '</h3>', opps.map(function (o) {
      return {
        label: '👉 ' + B.state.p[o].name + '（HP ' + B.state.p[o].hp + '）',
        fn: function () { closeModal(); doPickMulti(key, bead, t1, o); }
      };
    }));
  }

  function doPickMulti(key, bead, target, target2) {
    if (B.locked || B.state.over) return;
    const def = R.byKey[key];
    if (target === undefined) {
      const opps = S.opponentsOf(B.state, 0);
      if (def && def.target !== 'self' && opps.length > 1) {
        const need2 = key === R.SK.DUAL_GUN || key === R.SK.MIRROR;
        const title = key === R.SK.MIRROR ? '选择复制对象（目标 1/2）' : '选择目标' + (need2 ? ' 1/2' : '');
        B.picking = { key: key, bead: bead };
        const opts = opps.map(function (o) {
          return {
            label: '👉 ' + B.state.p[o].name + '（HP ' + B.state.p[o].hp + '）',
            fn: function () {
              B.picking = null;
              closeModal();
              if (need2) return pickSecondTarget(key, bead, o);
              doPickMulti(key, bead, o, null);
            }
          };
        });
        opts.push({ label: '↩ 取消', fn: function () { cancelPick(); } });
        openModal('<h3>' + title + '：' + def.name + '</h3>', opts);
        hint('请为【' + def.name + '】选择目标（Esc 或「取消」可放弃）。');
        return;
      }
      target = opps.length ? opps[0] : null;
    }
    B.locked = true;
    if (!B.roundStarted) B.roundStartSnapshot = S.cloneState(B.state);
    ensureRound();
    if (B.state.over) { B.locked = false; return; }
    const idx0 = B.state.events.length;
    const preState = S.cloneState(B.state);
    const N = B.state.p.length;
    const picks = [];
    for (let pid = 1; pid < N; pid++) {
      picks.push(preState.p[pid].hp > 0 ? chooseAIMulti(preState, pid, Play.legalActions(preState, pid)) : null);
    }
    S.attemptAction(B.state, 0, key, { bead: bead, target: target, target2: target2 });
    hint('你选择了【' + skillName(key) + (target != null ? ' → ' + B.state.p[target].name : '') + '】，对手思考中…');
    setTimeout(function () {
      for (let pid = 1; pid < N; pid++) {
        if (!picks[pid - 1]) continue;
        const b = B.state.p[pid];
        S.attemptAction(B.state, pid, picks[pid - 1].key, { bead: BeadChoice.of(b, picks[pid - 1].bead), target: picks[pid - 1].target, target2: picks[pid - 1].target2 });
      }
      X.resolveActions(B.state);
      X.endTurn(B.state);
      const events = B.state.events.slice(idx0);
      const parts = roundLineParts();
      addLog('div', 'rnd', '第 ' + B.state.round + ' 回合：' + parts.join('  '));
      logEvents(events);
      pushTranscript(parts, events);
      persistBattle();
      B.evCursor = B.state.events.length;
      buildSkillGrid(); renderSide(0); renderSide(1);
      B.locked = false;
      B.roundStarted = false;
      if (B.state.over) { finish(); return; }
      if (B.state.p[0].hp <= 0) { hint('你已被淘汰，自动观战至结束…'); autoRunRest(); return; }
      hint('第 ' + (B.state.round + 1) + ' 回合准备 —— 请出招（出招前可“悔一步”）。');
    }, 160 + Math.random() * 120);
  }

  /* 测试钩子（tools/np-probe.mjs 用）：只暴露对象引用，不改变游戏逻辑
   * v1.6.5：加 `modeFor` ⇒ smoke 可以**在真页面里**把 12 种（人数 × 血量）组合全过一遍，
   * 断言"映射的像恰好 = R.MODES 的全部 key"（这是行为断言，不是扫文本 —— 静态钉会被重构架空，本仓记过账）。 */
  if (typeof window !== 'undefined') window.EpirusUI = { B: B, newGame: newGame, aiInfo: aiInfo, seatOppLabel: seatOppLabel, battleText: buildBattleText, showRecap: showRecap, modeFor: modeFor, tierOf: tierOf, refresh: function () { buildSkillGrid(); renderSide(0); renderSide(1); } };

  /* v1.6.6：`chooseAI`（2 人专用那条 AI 路）已删除 —— 难度阶梯现在全人数共用一条路（`chooseAIMulti` + `DIFF_TIERS`）。
   * 它原来的三档（简单 = 60% 随机 + 中等、中等 = `pickBalanced`、困难 = 2P 冠军 ε=0）由阶梯接住：
   *   2 人桌上"困难"≈ 新的"困难·冠军"档（同一颗 2P 包、同样 ε=0），"中等"≈"普通/入门"之间，"简单"≈"简单·陪练"。
   * 按用户裁定「原本的简单普通就不能用了」，旧档名不再保留。 */

  /* 悔一步：回到本回合出招前快照 */
  function rebuildLog() {
    const lb = $('logbox'); lb.innerHTML = '';
    addLog('div', 'rnd', '（悔一步）回到上一回合开始前');
    for (const r of B.transcript) {
      addLog('div', 'rnd', '第 ' + r.round + ' 回合：' + (r.line ? r.line : '你=【' + r.human + '】 电脑=【' + r.ai + '】'));
      for (const l of r.lines) addLog('div', 'ev', l);
    }
  }

  function undo() {
    if (B.locked) { hint('结算中不能悔一步'); return; }
    if (B.state.over) { hint('对局已结束，请点“再来一局”'); return; }
    if (B.undoUsed) { hint('本局已用过“悔一步”，为避免“看答案重答”不再允许'); return; }
    if (!B.roundStartSnapshot || !B.transcript.length) {
      hint('暂无可悔的一步（至少完成一回合后才能“悔一步”）'); return;
    }
    B.undoUsed = true;
    B.state = S.cloneState(B.roundStartSnapshot);
    B.roundStarted = false;
    B.transcript.pop();
    B.evCursor = B.state.events.length;
    B.aiHistory = [];
    rebuildLog();
    buildSkillGrid(); renderSide(0); renderSide(1);
    hint('已悔一步：回到上一回合开始前，请重新出招。');
  }

  function finish() {
    persistBattle();
    buildSkillGrid();
    const w = B.state.winner;
    let title, cls = 'gold';
    if (w === 0) { title = '🎉 你赢了！'; }
    else if (w === 'draw') { title = '🤝 平局'; }
    else { title = '💀 ' + (B.state.p[w] ? B.state.p[w].name : '电脑') + ' 获胜'; cls = 'red'; }
    const lines = ['共进行 ' + B.state.round + ' 回合'];
    for (const pp of B.state.p) lines.push(pp.name + ' HP ' + pp.hp);
    openOverlay('<h2 style="color:var(--' + (w === 0 ? 'green' : w === 'red' ? 'red' : 'gold') + ')">' + title + '</h2>' +
      '<p>' + lines.join(' · ') + '</p>',
      [{ label: '📜 查看本局复盘', fn: showRecap }, { label: '再来一局', fn: newGame }]);
  }

  /* 本局复盘：不清空对局，展示逐回合记录（方便看完再决定） */
  function showRecap() {
    const rows = [];
    for (const r of B.transcript) {
      rows.push('<div class="rnd">第 ' + r.round + ' 回合：' + esc(r.line || ('你=【' + r.human + '】 电脑=【' + r.ai + '】')) + '</div>');
      for (const l of r.lines) rows.push('<div class="ev">' + esc(l) + '</div>');
    }
    openOverlay('<h2>📜 本局复盘（共 ' + B.state.round + ' 回合）</h2>' +
      '<div style="max-height:54vh;overflow:auto;text-align:left;font-size:12px;line-height:1.5;background:#141a2e;border-radius:8px;padding:8px 10px">' +
      (rows.join('') || '<div>暂无记录</div>') + '</div>',
      [{ label: '导出记录', fn: exportLog }, { label: '关闭', fn: closeOverlay }, { label: '再来一局', fn: newGame }]);
  }
  /* 上局记录：从 localStorage 读（即使已点过“再来一局”也还在） */
  function showLastBattle() {
    let txt = '';
    try { txt = localStorage.getItem('epirus.lastBattle') || ''; } catch (e) { txt = ''; }
    if (!txt) { hint('暂无上局记录'); return; }
    openOverlay('<h2>📄 上局记录</h2>' +
      '<div style="max-height:54vh;overflow:auto;text-align:left;font-size:12px;line-height:1.5;white-space:pre-wrap;background:#141a2e;border-radius:8px;padding:8px 10px">' +
      esc(txt) + '</div>',
      [{ label: '关闭', fn: closeOverlay }]);
  }

  /* 导出当前对局记录（纯文本，用于复查；同时存 localStorage） */
  /* 组装对局记录纯文本（导出 / 自动保存共用） */
  function buildBattleText() {
    /* §E667（用户要求加"本次的对手"）：这四格是**开局/换档当场**存下的历史，不是此刻重推的读数
     *   —— 换难度不换局，重推会把已经打完的回合说成"此刻这一档"。`难度=` 一并改成开局快照，
     *   否则它会与 `对手=` 不同档（前者活读、后者快照 ⇒ 同一张头部自相矛盾）。
     *   旧记录（改代码前存在 localStorage 里的那些局）没有这几格 ⇒ 明写"未登记"，不许留成空格看起来像"对手不明"。 */
    let txt = 'Epirus 拍手游戏 对局记录\n模式=' + MODE_NM[B.modeKey] + '  难度=' + (B.diffLabel || diffName(B.diff)) + '\n';
    txt += '对手=' + (B.oppSeats || B.oppInfo || '（本局未登记，看不到是谁在打）') + '\n';
    if (B.oppInfo && B.oppSeats && B.oppInfo !== B.oppSeats) txt += '对手AI=' + B.oppInfo + '\n';
    if (B.oppMid && B.oppMid.length) txt += '中途换档=' + B.oppMid.join(' ‖ ') + '\n';
    txt += '\n';
    for (const r of B.transcript) {
      txt += '第 ' + r.round + ' 回合：' + (r.line ? r.line : '你=【' + r.human + '】 电脑=【' + r.ai + '】') + '\n';
      for (const l of r.lines) txt += '   - ' + l + '\n';
    }
    const w = B.state.winner;
    txt += '\n结果：' + (w === 0 ? '你赢了' : w === 'draw' ? '平局' : (B.state.p[w] ? B.state.p[w].name + ' 获胜' : '平局')) + '（共 ' + B.state.round + ' 回合）\n';
    return txt;
  }
  // 每回合自动保存到 localStorage（对局结束也不清空，便于复查/调试）
  function persistBattle() {
    if (!B.transcript.length) return;
    try { localStorage.setItem('epirus.lastBattle', buildBattleText()); } catch (e) { /* ignore */ }
  }
  function exportLog() {
    if (!B.transcript.length) { hint('还没有对局记录可导出'); return; }
    persistBattle();
    const blob = new Blob([buildBattleText()], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'epirus-battle-' + B.state.round + '回合.txt';
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
  }

  /* ---------- 事件文案 ---------- */
  function nm(pid) { return (B.state && B.state.p[pid]) ? B.state.p[pid].name : (NAME[pid] || pid); }
  /* ===== v1.5.253（用户报：**大雷连带被挡下之后 UI 仍显示造成伤害**）=====
   * 根因：`bigTChain` 事件在 `js/core/resolve.js` 里是**无条件发出**的（发完才可能 `continue` 完全挡住、
   *   或把伤害转给防御者的作用目标）⇒ **它自己不含"有没有真打中"的信息**，而 UI 原来把这条**硬编码**成
   *   "受 2 点电伤" ⇒ 于是"被挡下"被渲染成了"造成了伤害"。**结算本身是对的，错的只有文案。**
   * 真相在同回合的 `damage` 事件里（`reason === '真正的落雷·连带'`、`to` = 真实受害者）⇒ 从这里反推，三种情形：
   *   · 有 `to === e.to` 的连带伤害 ⇒ 真打中（并按事件里的 `amt` 印数，不再写死 2）
   *   · 有连带伤害但 `to` 是别人 ⇒ 被挡下并把伤害**转给**了防御者的作用目标（金刚盾/藤甲那种）
   *   · 本回合根本没有连带伤害事件 ⇒ **完全挡住**（自守型防御），不许说"造成了伤害"
   * ⚠️ 必须在 **UI 层**解决：`js/core/resolve.js` 是**指纹五文件之一**，改它 = 规则换代（历史基线作废），
   *   而 `js/ui/` **不在指纹里** ⇒ 文案问题就在 UI 层修。 */
  const BIGT_CHAIN_REASON = '真正的落雷·连带';
  function bigTChainText(e, roundEvents) {
    const tag = (e.kind === 'attack' ? '（其攻击被无效）' : '（被目标攻击）');
    const list = roundEvents || [];
    /* ⚠️ v1.5.253 **第二版**：只看**本候选自己那一段**（从这条 `bigTChain` 到**下一条** `bigTChain`）——
     * 因为引擎对每个候选是"先发 `bigTChain`、紧跟它自己的投递"。
     * 第一版我扫的是**整回合**的连带伤害 ⇒ 一回合里有多个候选时，"被挡下的那条"会看到**别的候选的伤害**，
     * 于是把它误报成"转给你"（我在**真 Chrome**里跑出来就是这句假话，见截图复核）。
     * ⇒ 判据必须落在"段内"，而不是"回合内"。 */
    const here = list.indexOf(e);
    let seg = here < 0 ? list : list.slice(here + 1);
    for (let k = 0; k < seg.length; k++) if (seg[k] && seg[k].type === 'bigTChain') { seg = seg.slice(0, k); break; }
    const chain = seg.filter(function (x) {
      return x && x.type === 'damage' && x.reason === BIGT_CHAIN_REASON;
    });
    const mine = chain.filter(function (x) { return x.to === e.to; })[0];
    if (mine) return { cls: 'ev dmg', html: '⚡ ' + nm(e.from) + ' 的大雷连带：' + nm(e.to) + ' 受 ' + mine.amt + ' 点电伤' + tag };
    const moved = chain[0];
    if (moved) return { cls: 'ev', html: '⚡ ' + nm(e.from) + ' 的大雷连带：' + nm(e.to) + ' 挡下，伤害转给 ' + nm(moved.to) + '（' + moved.amt + ' 点电伤）' + tag };
    return { cls: 'ev dim', html: '⚡ ' + nm(e.from) + ' 的大雷连带：' + nm(e.to) + ' 挡下（未造成电伤）' + tag };
  }

  function evText(e, roundEvents) {
    const dim = { cls: 'ev dim' }, g = { cls: 'ev gold' }, p = { cls: 'ev pur' }, d = { cls: 'ev dmg' }, h = { cls: 'ev heal' };
    switch (e.type) {
      case 'insufficient': return { cls: 'ev dim', html: '💸 ' + nm(e.pid) + ' ジ不足，' + (R.byKey[e.skill] ? R.byKey[e.skill].name : e.skill) + ' 未发动' };
      case 'damage': {
        const why = e.reason && e.reason !== e.via ? '（' + esc(e.reason) + '）' : '';
        return { cls: 'ev dmg', html: '💥 ' + nm(e.to) + ' 受 ' + e.amt + ' 点伤害' + why };
      }
      case 'heal': return { cls: 'ev heal', html: '💚 ' + nm(e.pid) + ' 回复 ' + e.amt + ' 血' + (e.reason ? '（' + esc(e.reason) + '）' : '') };
      case 'ep': return { cls: 'ev', html: '🔋 ' + nm(e.pid) + ' ジ ' + (e.delta > 0 ? '+' : '') + e.delta };
      /* v1.5.15 修**信息泄漏**（用户报）：**获得**珠时不能暴露类型（蓄能选哪种只有本人知道）；
       * **消耗**时保留 —— 那时技能本身就暴露了（放电⇒电珠、激光眼⇒爆珠），属公开信息。 */
      case 'bead': return { cls: 'ev', html: (e.delta > 0
        ? '✨ ' + nm(e.pid) + ' 完成蓄能' + (e.pid === 0 ? '（' + (e.kind === 'elec' ? '电珠' : '爆珠') + '）' : '（珠的类型只有他知道）')
        : '✖ ' + nm(e.pid) + ' 消耗 1 ' + (e.kind === 'elec' ? '电珠' : '爆珠')) };
      case 'beadExpire': return { cls: 'dim', html: '⏳ ' + nm(e.pid) + ' 的' + (e.pid === 0 ? (e.kind === 'elec' ? '电珠' : '爆珠') : '蓄能珠') + '过期（蓄能珠只供下一回合）' };
      case 'mineArm': return { cls: 'ev', html: '💣 ' + nm(e.pid) + ' 埋下地雷' };
      case 'guardSet': return { cls: 'ev dim', html: '🛡 ' + nm(e.pid) + ' 摆出【' + skillName(e.key) + '】架势' };
      case 'holoSet': return { cls: 'ev dim', html: '🛡 ' + nm(e.pid) + ' 用【全息屏障】护住 ' + nm(e.target) + '（本回合视为原型制御架势）' };
      case 'blocked': return { cls: 'ev dim', html: '🛡 ' + nm(e.to) + ' 的【' + (e.by || '架势') + '】挡下伤害' + (e.judge ? '（判定成功）' : '') };
      case 'reflect': {
        /* v1.5.136（用户实机报的 bug ③）：原型制御的弹回原先也印成【反弹】⇒ 日志里分不清是反弹架势还是
         * 原型制御（两者语义不同：反弹只格挡枪/剑线，原型制御挡除地雷/转移外一切）。事件早带了 `by:'proto'`，
         * 只是渲染器没读。 */
        const guardName = e.by === 'armor' ? '藤甲' : (e.by === 'proto' ? '原型制御' : '反弹');
        return { cls: 'ev gold', html: '↩ ' + nm(e.from) + ' 的攻击被 ' + nm(e.to) + ' 的【' + guardName + '】弹回 → 伤害落到 ' + nm(e.from) };
      }
      /* v1.5.136（bug ①的 UI 面）：转移是"转给转移者指定的那个人"（e.dest），不是"弹回攻击者"（e.from）。
       * 旧文案跟着错误实现写；`e.dest` 缺省（旧记录回放）时退回 from，不至于显示 undefined。 */
      case 'transfer': return { cls: 'ev gold', html: '↩ ' + nm(e.to) + ' 使用【转移伤害】，伤害转移给 ' + nm(e.dest != null ? e.dest : e.from) };
      case 'curse': return { cls: 'ev pur', html: '🧧 ' + nm(e.owner) + ' 给 ' + nm(e.pid) + ' 贴上符咒' };
      case 'curseBlock': return { cls: 'ev dim', html: '🧧 符咒被 ' + nm(e.pid) + ' 的架势挡下' };
      case 'firestorm': return e.n > 0 ? { cls: 'ev dmg', html: '🔥 ' + nm(e.pid) + ' 引燃 ' + e.n + ' 枚符咒！' } : { cls: 'ev dim', html: nm(e.pid) + ' 放天火，但没有可引爆的符咒' };
      case 'taunt': return { cls: 'ev pur', html: '📣 ' + nm(e.pid) + ' 对 ' + nm(e.target) + ' 挑衅（下回合必须攻击）' };
      case 'tauntCheck': return { cls: 'ev dim', html: '⚖ 挑衅检查 ' + nm(e.pid) + '：' + (e.ok ? '已攻击 ✓' : '未攻击 → 回合末 -1') };
      case 'voided': return { cls: 'ev dim', html: '🚫 ' + nm(e.pid) + ' 的技能被无效化' + (e.by ? '（' + byName(e.by) + '）' : '') };
      case 'voidedBy': return { cls: 'ev dim', html: '🚫 ' + nm(e.pid) + ' 的技能被【' + skillName(e.by) + '】无效化' };
      case 'voidImmune': return { cls: 'ev gold', html: '🛡 ' + nm(e.pid) + ' 的【' + skillName(e.key) + '】豁免了无效化' };
      case 'cancel': return { cls: 'ev gold', html: '⚔ 双方攻击相抵，均无效' };
      case 'clash': return { cls: 'ev gold', html: '⚔ 高优先级攻击阻止了对方攻击' };
      case 'thunderRing': return { cls: 'ev gold', html: '🌩 双方互放小雷成环 —— 两雷皆无效果' };
      case 'rod': return e.mode === 'A'
        ? { cls: 'ev gold', html: '☂ ' + nm(e.pids[0]) + ' 的避雷针：所有雷系技能无效，施术者反噬 1 电并获得其能量' }
        : { cls: 'ev blue', html: '☂ ' + nm(e.pids[0]) + ' 架起避雷针（3 回合内免雷一次）' };
      case 'rodBlock': return { cls: 'ev gold', html: '☂ ' + nm(e.pid) + ' 的避雷针挡下雷击' };
      case 'ban': return { cls: 'ev dmg', html: '🌩 ' + nm(e.pid) + ' 被雷劈中：多数技能禁用 3 回合（防御/反弹/金刚盾/ジ 除外）' };
      case 'hidden': return { cls: 'ev pur', html: '🌑 触发隐藏技能【' + e.name + '】' + (e.pid != null ? '（' + nm(e.pid) + '）' : '') + (e.to != null ? ' → ' + nm(e.to) : '') };
      /* v1.5.253：不再硬编码"受 2 点电伤" —— 是否真打中要按同回合的连带伤害事件反推（见 `bigTChainText`）。 */
      case 'bigTChain': return bigTChainText(e, roundEvents);
      case 'mirror': return { cls: 'ev pur', html: '🪞 ' + nm(e.pid) + ' 镜面反射：复制 ' + nm(e.from) + ' 的【' + skillName(e.key) + '】→ ' + nm(e.to) };
      case 'mirrorNoEffect': return { cls: 'ev dim', html: '🪞 ' + nm(e.pid) + ' 镜面反射：' + nm(e.from) + ' 本回合的行动不存在或已被作废，无可复制' };
      /* N14 v1.5.16：非伤害类技能 = 效果落在自己身上 + 对 t2 空指（指向保留、本身无效果） */
      case 'mirrorCopySelf': return { cls: 'ev', html: '🪞 ' + nm(e.pid) + ' 镜面反射：复制 ' + nm(e.from) + ' 的【' + skillName(e.key) + '】用在自己身上（空指 → ' + nm(e.to) + '）' };
      case 'revive': return { cls: 'ev gold', html: '👻 ' + nm(e.pid) + ' 回魂复活！本回合无限能量' };
      case 'vampire': return { cls: 'ev pur', html: '🧛 ' + nm(e.pid) + ' 觉醒【吸血鬼公爵】：摄魂自愈 2、受光伤 +1' };
      case 'purify': return { cls: 'ev heal', html: '🧼 ' + nm(e.pid) + ' 净化：清除 ' + e.curses + ' 枚符咒与负面状态' };
      case 'curseExpire': return { cls: 'ev dim', html: '🧧 ' + nm(e.pid) + ' 的符咒到期（' + e.n + ' 枚消失）' };
      case 'headshot': return { cls: 'ev dmg', html: '🎯 爆头！' + nm(e.to) + ' 额外 -1' };
      case 'death': return { cls: 'ev dmg', html: '☠ ' + nm(e.pid) + ' 死亡（' + esc(e.reason || '') + '）' };
      case 'mine': return null; // 与 damage 事件重复，跳过
      default: return null;
    }
  }

  /* ---------- 弹层 ---------- */
  function openModal(html, buttons) {
    $('modal-card').innerHTML = html +
      '<div class="btns">' + buttons.map(function (b) {
        return '<button id="mbtn">' + b.label + '</button>';
      }).join('') + '</div>';
    const btns = $('modal-card').querySelectorAll('#mbtn');
    buttons.forEach(function (b, i) { btns[i].onclick = b.fn; });
    $('modal-root').classList.remove('hidden');
  }
  function closeModal() { $('modal-root').classList.add('hidden'); }
  /* v1.5.80（§5-①）：目标/蓄能的弹窗**必须能取消** —— 否则玩家只能"随便选一个"，
   * 或者以为可以改主意（探针实测：改主意会静默替换/误触落子）。 */
  function cancelPick() {
    const was = B.picking ? B.picking.key : null;
    B.picking = null; closeModal();
    if (was) hint('已取消【' + skillName(was) + '】，请重新出招。');
  }
  /* 点弹窗外（遮罩）或按 Esc 都算取消；只在真的有待选状态时才拦截，避免影响结算/终局弹层。 */
  if ($('modal-root')) $('modal-root').onclick = function (ev) { if (ev.target === this && B.picking) cancelPick(); };
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && B.picking) cancelPick(); });
  function openOverlay(html, buttons) {
    $('overlay-card').innerHTML = html +
      '<div class="btns" style="display:flex;justify-content:center;gap:10px">' +
      buttons.map(function (b) { return '<button id="obtn">' + b.label + '</button>'; }).join('') + '</div>';
    const btns = $('overlay-card').querySelectorAll('#obtn');
    buttons.forEach(function (b, i) { btns[i].onclick = b.fn; });
    $('overlay-root').classList.remove('hidden');
  }
  function closeOverlay() { $('overlay-root').classList.add('hidden'); }

  /* ---------- Tab ---------- */
  function showTab(which) {
    $('tab-battle').classList.toggle('on', which === 'battle');
    $('tab-train').classList.toggle('on', which === 'train');
    $('tab-rules').classList.toggle('on', which === 'rules');
    $('page-battle').classList.toggle('hidden', which !== 'battle');
    $('page-train').classList.toggle('hidden', which !== 'train');
    $('page-rules').classList.toggle('hidden', which !== 'rules');
    if (which === 'train') { drawChart(); renderChampState(); }
    if (which === 'rules' && window.EpirusRulesPanel) window.EpirusRulesPanel.render();
  }

  /* ---------- 训练场 ---------- */
  let lastTrainer = null;
  let stats = { swaps: 0 };
  function renderChampState() {
    /* v1.5.131：**原先"内置包"也会被标成"已保存本地冠军"** —— 因为 `store.load()` 在本地缺失时会回退内置，
     * `c` 照样是真值 ⇒ "当前冠军"永远显示成"已保存本地冠军"（handoff §4-10 的第 3 个症状：
     * 2P 用户既看不出自己在打哪个包，也看不到"用内置冠军"到底有没有生效）。
     * 现在按 `store.lastSource`（由 `trainer.js` 单一来源回传）如实区分三种情形。 */
    const c = Champ.store.load();
    const from = Champ.store.lastSource;
    const el = $('tr-has');
    let label;
    if (from === 'local') {
      label = '已保存本地冠军（本机自训/导入）';
    } else if (from === 'builtin') {
      const m = (typeof window !== 'undefined' && window.EPIRUS_CHAMPION_META) || null;
      label = m
        ? ('内置冠军 · ' + (m.source || '?') + ' · ' + (m.seeds != null ? m.seeds + '×' : '') + (m.gens != null ? m.gens + '代' : '') + (m.ts ? ' · ' + m.ts : ''))
        : '内置冠军';
    } else {
      label = '无（困难难度将代打中等逻辑）';
    }
    el.textContent = label;
  }
  function exportTrainCsv() {
    const trainer = (remoteHistory && remoteHistory.length)
      ? { history: remoteHistory, gen: remoteHistory[remoteHistory.length - 1].gen }
      : lastTrainer;
    if (!trainer || !trainer.history || !trainer.history.length) { alert('还没有训练历史可导出（先训练）。'); return; }
    Champ.saveTrainLogCSV(trainer);
  }
  function stopRemote() {
    if (remoteES) remoteES.close();
    remoteES = null; remoteActive = false;
    $('tr-state').textContent = '已断开显示（服务端可能仍在完成本批训练）';
  }
  function resetServerTrain() {
    fetch(remoteBase() + '/reset').then(function (r) { return r.json(); }).then(function () {
      remoteHistory = []; remoteDoneSeeds = {}; stats.swaps = 0;
      $('tr-state').textContent = '服务端已重置（新种子）'; $('tr-progress').style.width = '0%';
      renderSeedStatus(); drawChart();
    }).catch(function () { $('tr-remote').textContent = '重置失败：服务未启动？'; });
  }
  const EVAL_GAMES = 30;   // 局数只写这一处：按钮文案与结果标题都由它生成（两处各写一遍必漂移）
  $('btn-eval').textContent = '评测冠军(' + EVAL_GAMES + '局/基线)';
  function doEval() {
    const rows = Champ.quickEval(EVAL_GAMES, Date.now() % 100000);
    if (!rows) { $('tr-evalbox').innerHTML = '<p style="color:var(--red)">还没有冠军可评测，先训练。</p>'; return; }
    renderEval(rows, '评测：冠军 vs 8 脚本基准（各 ' + EVAL_GAMES + ' 局）');
  }
  function renderEval(rows, title) {
    let h = '<h4 style="margin:12px 0 2px">' + title + '</h4><table class="eval"><tr><th>对手</th><th>胜</th><th>平</th><th>负</th><th>胜率</th></tr>';
    for (const r of rows) {
      h += '<tr><td>' + r.name + '</td><td>' + r.w + '</td><td>' + r.d + '</td><td>' + r.l + '</td><td>' + (r.wr * 100).toFixed(0) + '%</td></tr>';
    }
    h += '</table>';
    $('tr-evalbox').innerHTML = h;
  }

  /* ---------- 远程训练（Node 服务，SSE 实时进度） ---------- */
  let remoteES = null;
  let remoteHistory = [];   // 累积的远程 rec（跨批保留，供 CSV + 曲线）
  let remoteParents = [];   // 本轮各种子的父种子 id（-1=无父代/现有冠军），用于 CSV 的 parent_seed_id
  let remoteActive = false; // 当前是否处于远程训练（画图用）
  let remoteStart = 0;      // 本次批次的起始代（来自 start 事件）
  let remoteDoneSeeds = {}; // 已早停/完成的种子：{seed: {reason, gen, wr}}
  let remoteGens = 500;     // 本次批次要新增的代
  let remoteRetry = null;   // 服务未启动时的自动探测定时器
  function remoteBase() {
    const port = ($('tr-port').value || '8787');
    return 'http://127.0.0.1:' + port;
  }
  // 探测服务是否可达；1.5s 无响应视为未启动（避免 file:// 页连不上时一直"探测中"）
  function fetchProbe(base) {
    const ctl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    const tid = setTimeout(function () { if (ctl) ctl.abort(); }, 1500);
    return fetch(base + '/', ctl ? { signal: ctl.signal } : undefined).then(function (r) {
      clearTimeout(tid); return { ok: r.ok };
    }).catch(function () { clearTimeout(tid); return { ok: false }; });
  }
  let remoteN = 2;
  function connectRemoteTrain() {
    const gens = Math.max(1, Number($('tr-remote-gens').value || 500));
    remoteGens = gens;
    const nPlayers = Math.max(2, Math.min(5, parseInt($('tr-n') && $('tr-n').value, 10) || 2));
    remoteN = nPlayers;
    // 多人：每代评估更重（一局有 N 个人），默认种群/局数自动拉高
    const pop = Math.max(6, parseInt($('tr-pop').value, 10) || (nPlayers > 2 ? 32 : 14));
    const gpoIn = Math.max(2, parseInt($('tr-gpo') && $('tr-gpo').value, 10) || (nPlayers > 2 ? 20 : 5));
    const seedsN = Math.max(1, Math.min(8, parseInt($('tr-seeds').value, 10) || 3));
    const roundsN = Math.max(1, Math.min(20, parseInt($('tr-rounds').value, 10) || 1));
    const fresh = $('tr-fresh') && $('tr-fresh').checked;
    const base = remoteBase();
    if (remoteRetry) { clearInterval(remoteRetry); remoteRetry = null; }
    if (remoteES) { remoteES.close(); remoteES = null; }
    stats.swaps = 0;
    remoteHistory = []; remoteDoneSeeds = {};
    $('tr-remote').textContent = '正在探测服务…';
    // 先探测服务是否已启动：未启动则提示双击 launcher 并自动重试（页面上"一键"体验）
    fetchProbe(base).then(function (res) { if (res.ok) openRemote(base, gens, pop, gpoIn, fresh, seedsN, roundsN, nPlayers); else waitForServer(base, gens, pop, gpoIn, fresh, seedsN, roundsN, nPlayers); });
  }
  function waitForServer(base, gens, pop, gpoIn, fresh, seedsN, roundsN, nPlayers) {
    $('tr-remote').textContent = '服务未启动。请双击 tools/start-train-server.cmd 启动（或 node server/train-server.mjs）——检测到后自动连接…';
    if (remoteRetry) clearInterval(remoteRetry);
    remoteRetry = setInterval(function () {
      fetchProbe(base).then(function (res) { if (res.ok) { clearInterval(remoteRetry); remoteRetry = null; openRemote(base, gens, pop, gpoIn, fresh, seedsN, roundsN, nPlayers); } });
    }, 2000);
  }
  function renderSeedStatus() {
    const el = $('tr-seeds-status');
    if (!el) return;
    // 必须按「轮-种子」分组：每轮种子号都会从 0 重新开始，只按 seed 分组会让第二轮之后的行永远不更新
    // （第二轮 gen 从 0 起，永远不大于第一轮的 gen，旧代码的 `r.gen > by[s].gen` 判定直接失效）
    const by = {}, order = [];
    for (const r of remoteHistory) {
      const s = r.seed != null ? r.seed : 0;
      const rd = r.round != null ? r.round : 0;
      const k = rd + '-' + s;
      if (!by[k]) { by[k] = { round: rd, seed: s, gen: -1, best: null, champAge: null, sigma: null, swaps: 0 }; order.push(k); }
      const d = by[k];
      if (r.gen > d.gen) { d.gen = r.gen; d.best = r.best; d.champAge = r.champAge; d.sigma = r.sigma; }
      if (r.champChanged) d.swaps++;
    }
    if (!order.length) { el.innerHTML = ''; return; }
    const maxRound = order.reduce(function (m, k) { return Math.max(m, by[k].round); }, 0);
    const out = [];
    // 历史轮：各压成一行摘要
    for (let rd = 0; rd < maxRound; rd++) {
      const same = order.filter(function (k) { return by[k].round === rd; });
      if (!same.length) continue;
      let best = -1;
      for (const k of same) if (by[k].best != null && by[k].best > best) best = by[k].best;
      out.push('<div style="opacity:.62">第' + (rd + 1) + '轮完成 · ' + same.length + ' 种子 · 最高最优分 ' + (best >= 0 ? best.toFixed(3) : '--') + '</div>');
    }
    // 当前轮：逐种子实时行
    for (const k of order.filter(function (x) { return by[x].round === maxRound; })) {
      const d = by[k], done = remoteDoneSeeds[k];
      const seg = ['第' + (d.round + 1) + '轮 · 种子' + d.seed, '世代' + d.gen,
        (d.best != null ? '最优' + d.best.toFixed(3) : '最优-'),
        '更换' + d.swaps + '次',
        (d.champAge != null ? '蝉联' + d.champAge + '代' : ''),
        (d.sigma != null ? 'σ' + d.sigma.toFixed(3) : '')];
      out.push('<div>' + seg.filter(Boolean).join('  ') + (done ? '  ⚠' + done.reason : '') + '</div>');
    }
    el.innerHTML = out.join('');
  }
  function openRemote(base, gens, pop, gpoIn, fresh, seedsN, roundsN, nPlayers) {
    if (remoteES) { remoteES.close(); remoteES = null; }
    remoteActive = true;
    $('tr-remote').textContent = '连接中…';
    const es = new EventSource(base + '/train?gens=' + gens + '&pop=' + pop + '&gpo=' + gpoIn + (fresh ? '&fresh=1' : '') + '&seeds=' + seedsN + '&rounds=' + roundsN + '&n=' + (nPlayers || 2));
    remoteES = es;
    es.onopen = function () { $('tr-remote').textContent = '已连接，服务端训练中（可切去对战）'; };
    es.onmessage = function (ev) {
      let d = {}; try { d = JSON.parse(ev.data); } catch (e) { return; }
      if (d.type === 'start' && d.n > 2) {
        remoteStart = 0;
        $('tr-remote').textContent = '多人训练（' + d.n + ' 人）已启动：' + d.gens + ' 代 · 每代 ' + d.pop + ' 个体 · 每人 ' + d.gpo + ' 局 · ' + (d.workers != null ? d.workers + ' 个 worker' : '串行') + (d.fresh ? ' · 从头训练' : ' · 热启动');
      } else if (d.type === 'start') {
        remoteStart = d.fresh ? 0 : (d.from || 0);
        const n = d.seeds || seedsN, rd = d.rounds || roundsN;
        $('tr-remote').textContent = d.fresh
          ? '已重置，从头训练（' + rd + ' 轮 × ' + n + ' 种子，清空旧冠军）'
          : rd + ' 轮 × ' + n + ' 种子（每轮 ' + gens + ' 代），继续精修现有冠军';
      } else if (d.type === 'roundStart') {
        remoteParents = (d.parents || []).map(function (p) { return p && p.seedId != null ? p.seedId : -1; });
        const par = (d.parents && d.parents.length) ? ('｜' + d.parents.map(function (p, i) { return '种子' + i + '←' + ((p && p.label) || '随机'); }).join(' ')) : '';
        $('tr-state').textContent = '第 ' + (d.round + 1) + '/' + d.rounds + ' 轮开始（' + d.seeds + ' 种子 × ' + d.gens + ' 代）' + par;
      } else if (d.type === 'lineage') {
        $('tr-state').textContent = '第 ' + (d.round + 1) + ' 轮种子谱系：' + d.parents.map(function (p, i) { return '种子' + i + '←' + p.label; }).join('  ');
      } else if (d.type === 'gen' && d.n > 2) {
        const r = d.rec;
        remoteHistory.push({ round: 0, seed: 0, parentSeed: -1, gen: r.gen, best: r.best, sigma: r.sigma, baseline: null });
        $('tr-state').textContent = '多人（' + d.n + '人）训练中… 第 ' + r.gen + ' 代 · 1st ' + (r.firstRate * 100).toFixed(0) + '% / top2 ' + (r.top2Rate * 100).toFixed(0) + '%';
        $('tr-progress').style.width = Math.min(100, (r.gen + 1) / gens * 100) + '%';
        renderSeedStatus();
        drawChart();
      } else if (d.type === 'gen') {
        const r = d.rec;
        const sd = d.seed != null ? d.seed : 0;
        const rd = d.round != null ? d.round : 0;
        remoteHistory.push({ round: rd, seed: sd, parentSeed: (remoteParents[sd] != null ? remoteParents[sd] : -1), gen: r.gen, best: r.best, champChanged: r.champChanged, champAge: r.champAge, sigma: r.sigma, baseline: r.baseline });
        if (r.champChanged) stats.swaps++;
        $('tr-state').textContent = '远程训练中… 第 ' + (rd + 1) + ' 轮 · 世代 ' + r.gen;
        $('tr-progress').style.width = Math.min(100, (r.gen - remoteStart) / gens * 100) + '%';
        renderSeedStatus();
        drawChart();   // 实时画多条种子曲线（y 轴自适应，最优分可>1）
      } else if (d.type === 'seedDone') {
        remoteDoneSeeds[(d.round != null ? d.round : 0) + '-' + d.seed] = { reason: d.reason, gen: d.gen, wr: d.wr };
        $('tr-remote').textContent = 'R' + (d.round != null ? d.round : 0) + ' 种子' + d.seed + ' 已早停：' + d.reason + '（第' + d.gen + '代，真实胜率 ' + (d.wr != null ? (d.wr * 100).toFixed(0) + '%' : '--') + '）';
        renderSeedStatus();
      } else if (d.type === 'seedEval') {
        $('tr-state').textContent = '第 ' + ((d.round || 0) + 1) + ' 轮收尾评估… 种子' + d.seed + ' 真实胜率 ' + (d.wr * 100).toFixed(0) + '%';
      } else if (d.type === 'roundDone') {
        const bestSeedTxt = d.bestSeed != null && d.bestSeed >= 0 ? (' 最优=种子' + d.bestSeed) : ' 保留现有冠军';
        $('tr-state').textContent = '第 ' + (d.round + 1) + '/' + d.rounds + ' 轮完成：冠军真实胜率 ' + (d.champWr != null ? (d.champWr * 100).toFixed(0) + '%' : '--') + bestSeedTxt;
      } else if (d.type === 'done' && d.n > 2) {
        $('tr-progress').style.width = '100%';
        $('tr-state').textContent = '多人（' + d.n + '人）训练完成：1st ' + (d.firstRate * 100).toFixed(1) + '% / top2 ' + (d.top2Rate * 100).toFixed(1) + '%（' + d.secs + 's）';
        $('tr-remote').textContent = '多人冠军已写入 js/bundled-champion-3p.js；对局困难档即时生效；再点一次可继续训练';
        remoteActive = false;
        es.close(); remoteES = null;
        if (d.champ) {
          window.EPIRUS_CHAMPION_3P = d.champ;
          try { localStorage.removeItem('epirus.champion3p'); } catch (e) { /* ignore */ }
          resetMultiChampCache();
          renderChampState();
        }
      } else if (d.type === 'done') {
        $('tr-progress').style.width = '100%';
        const bestSeedTxt = d.bestSeed != null && d.bestSeed >= 0 ? (' 最优=种子' + d.bestSeed) : ' 保留现有冠军';
        $('tr-state').textContent = '远程训练完成：' + (d.rounds || roundsN) + ' 轮 × ' + (d.seeds || seedsN) + ' 种子 (' + d.secs + 's)，冠军真实胜率 ' + (d.champWr != null ? (d.champWr * 100).toFixed(0) + '%' : '--') + bestSeedTxt;
        $('tr-remote').textContent = '训练完成（' + (d.rounds || roundsN) + ' 轮 × ' + (d.seeds || seedsN) + ' 种子' + bestSeedTxt + '），冠军已写入 js/bundled-champion.js；再点一次可继续训练';
        remoteActive = false;
        es.close(); remoteES = null;
        // 把冠军拉进内存，困难档无需刷新即可生效
        fetch(base + '/champion').then(function (r) { return r.json(); }).then(function (j) {
          if (j && j.champion) {
            window.EPIRUS_CHAMPION = j.champion;
            try { localStorage.removeItem('epirus.champion.v3'); } catch (e) { /* ignore */ }
            renderChampState();
            $('tr-remote').textContent = '冠军已载入内存（困难档即时生效；刷新页面可持久化到内置文件）；再点一次可继续训练';
          }
        });
      } else if (d.type === 'error') { $('tr-remote').textContent = '服务错误：' + d.msg; }
    };
    es.onerror = function () {
      remoteActive = false;
      $('tr-remote').textContent = '连接中断。请确认服务仍在运行（tools/start-train-server.cmd）。';
      es.close(); remoteES = null;
    };
  }

  /* ---------- 图表 ---------- */
  function drawChart() {
    const cv = $('chart');
    if (!cv || $('page-train').classList.contains('hidden')) return;
    const dpr = window.devicePixelRatio || 1;
    const w = cv.clientWidth || 600, h = 220;
    cv.width = w * dpr; cv.height = h * dpr;
    const g = cv.getContext('2d');
    g.scale(dpr, dpr);
    g.clearRect(0, 0, w, h);
    let hist = null;
    if (remoteHistory.length) hist = remoteHistory;
    else if (lastTrainer && lastTrainer.history && lastTrainer.history.length)
      hist = lastTrainer.history.map(function (r) { return { seed: 0, gen: r.gen, best: r.best, baseline: r.baseline }; });
    if (!hist || !hist.length) { g.fillStyle = '#8b93c4'; g.font = '13px sans-serif'; g.fillText('训练历史将显示在此，连接远程训练或先训练一次', 16, h / 2); return; }
    // 按「轮-种子」分组：每轮种子号都从 0 重新开始，只按 seed 分组会把各轮曲线首尾相接成锯齿
    const bySeries = {}, keys = [];
    for (const r of hist) {
      const s = r.seed != null ? r.seed : 0;
      const rd = r.round != null ? r.round : 0;
      const k = rd + '-' + s;
      if (!bySeries[k]) { bySeries[k] = { round: rd, seed: s, arr: [] }; keys.push(k); }
      bySeries[k].arr.push(r);
    }
    keys.sort(function (a, b) { return bySeries[a].round - bySeries[b].round || bySeries[a].seed - bySeries[b].seed; });
    const pad = 38;
    let maxV = 1;
    for (const k of keys) for (const r of bySeries[k].arr) if (r.best > maxV) maxV = Math.ceil(r.best * 100) / 100;
    if (!(maxV > 0)) maxV = 1;
    // x 轴按「轮」连续推进：第 N 轮的曲线接在第 N-1 轮右侧（不再各自从 0 起、叠在旧图上）
    let genMax = 0, roundMax = 0;
    for (const k of keys) {
      const s = bySeries[k];
      if (s.round > roundMax) roundMax = s.round;
      for (const r of s.arr) if (r.gen > genMax) genMax = r.gen;
    }
    const stride = genMax + 1;
    const span = Math.max(1, (roundMax + 1) * stride - 1);
    const X = function (rd, gen) { return pad + (w - pad * 2) * ((rd * stride + gen) / span); };
    const Y = function (v) { return h - 20 - (h - 44) * Math.max(0, Math.min(maxV, v)) / maxV; };
    g.strokeStyle = '#2c3560'; g.beginPath();
    for (let x = pad; x <= w - pad; x += 60) { g.moveTo(x, 10); g.lineTo(x, h - 20); }
    g.stroke();
    // 轮分界线 + 轮号（每轮一段横向区间）
    g.setLineDash([4, 4]);
    for (let rd = 1; rd <= roundMax; rd++) {
      const x = X(rd, 0);
      g.strokeStyle = '#3d4a7d'; g.beginPath(); g.moveTo(x, 10); g.lineTo(x, h - 20); g.stroke();
    }
    g.setLineDash([]);
    g.strokeStyle = '#8b93c4'; g.font = '11px sans-serif';
    for (let rd = 0; rd <= roundMax; rd++) {
      const x = X(rd, 0);
      g.fillStyle = '#6f7aa8'; g.fillText('R' + (rd + 1), x + 3, h - 6);
    }
    g.strokeStyle = '#8b93c4'; g.font = '11px sans-serif';
    g.fillText(maxV.toFixed(2), 4, Y(maxV) + 4); g.fillText((maxV / 2).toFixed(2), 4, Y(maxV / 2) + 4); g.fillText('0', 4, Y(0) + 4);
    g.fillText('上限 ' + maxV.toFixed(2), w - 62, 14);
    const COLORS = ['#5ad0ff', '#ff8fa3', '#7be08a', '#ffc94d', '#c39bff', '#7fd7ff', '#ff9f6b', '#9be0c3'];
    keys.forEach(function (k, si) {
      const ser = bySeries[k], arr = ser.arr, color = COLORS[si % COLORS.length];
      g.strokeStyle = color; g.lineWidth = 2; g.beginPath();
      arr.forEach(function (r, i) { const x = X(ser.round, r.gen), y = Y(r.best); i ? g.lineTo(x, y) : g.moveTo(x, y); });
      g.stroke();
      g.fillStyle = color;
      arr.forEach(function (r) { if (r.baseline != null) g.fillRect(X(ser.round, r.gen) - 2, Y(r.baseline) - 2, 3, 3); });
    });
    g.fillStyle = '#8b93c4'; g.font = '11px sans-serif';
    const shown = keys.length > 8 ? keys.slice(keys.length - 8) : keys;
    const lg = (keys.length > 8 ? '… ' : '') + shown.map(function (k) { return 'R' + (bySeries[k].round + 1) + 's' + bySeries[k].seed; }).join(' ');
    g.fillText('各轮种子最优分曲线（' + lg + '；点=对基线真实胜率）', pad, 12);
  }

  /* ---------- 导出/导入 ---------- */
  function exportChamp() {
    const c = Champ.store.load();
    if (!c) { alert('还没有冠军可导出'); return; }
    const blob = new Blob([Champ.store.exportJSON(c)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'epirus-champion.json';
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
  }
  function importChamp(file) {
    if (!file) return;
    const rd = new FileReader();
    rd.onload = function () {
      /* v1.5.141（用户要求"给界面加一个选冠军包的功能"）：先剥外壳 —— 训练产物 `docs/artifacts/*.bak`
       * 是 `window.EPIRUS_CHAMPION[_3P] = {…};`（不是纯 JSON），原来会被 `JSON.parse` 打回。
       * 剥壳逻辑单一来源在 `js/champion-pack.js`（纯函数，可单测）。槽位由外壳名判定。 */
      const PACK = window.EpirusChampionPack;
      const ex = (PACK && PACK.extract) ? PACK.extract(String(rd.result)) : { ok: false, reason: 'parse-error' };
      if (!ex.ok) {
        alert('导入失败：' + champReasonText(ex.reason, ex));
        return;
      }
      const c = P.checkPack(ex.pack);
      if (!c.ok && !P.canUpgradeStateOnly(ex.pack)) {
        alert('导入失败：' + champReasonText(c.reason, c));
        return;
      }
      /* 多人槽（3P/NP）：写 window 全局 + localStorage（页面优先读后者）+ 清缓存 ⇒ 对局"困难"档即时生效。
       * 还原入口就是页面上那个「用内置冠军」按钮（v1.5.10 起已有，会清 `epirus.champion3p`）。 */
      if (ex.slot === '3p') {
        window.EPIRUS_CHAMPION_3P = ex.pack;
        try { localStorage.setItem('epirus.champion3p', JSON.stringify(ex.pack)); } catch (e) { /* 隐私模式等 */ }
        resetMultiChampCache();
        renderChampState();
        alert('多人冠军包已载入：' + (file.name || '(未命名)') + '\n对局「困难」档即时生效（3~5 人场）。\n想还原内置冠军：点「用内置冠军」。');
        return;
      }
      /* 2P 槽：维持原路径（`importJSON` 做版本/维度校验），只是喂**剥壳后**的 JSON。 */
      const r = Champ.store.importJSON(JSON.stringify(ex.pack));
      if (!r.ok) {
        alert('导入失败：' + champReasonText(r.reason, r));
        return;
      }
      Champ.store.save(r.policy);
      renderChampState();
      alert('冠军策略导入成功，可用于“困难·冠军”难度（2 人场）。' +
        (ex.slot === null ? '\n⚠️ 这个文件没有 `window.EPIRUS_CHAMPION_3P` 外壳 ⇒ 按 2P 包处理；多人包请用训练产出的 .bak。' : ''));
    };
    rd.readAsText(file);
  }
  // 冠军包不兼容原因 → 中文提示
  function champReasonText(reason, info) {
    info = info || {};
    const want = info.want != null ? ('应为 ' + info.want) : '';
    const got = info.got != null ? ('实际 ' + info.got + '，') : '';
    switch (reason) {
      case 'version': return '版本不符（' + got + want + '），可能是旧版策略网络训练的冠军';
      case 'length': return '权重长度不符（' + got + want + '），旧版 1177≠新版 1633，无法复用';
      case 'feature': return '状态特征维度不符（' + got + want + '）';
      case 'hidden': return '隐藏层维度不符（' + got + want + '）';
      case 'no-version': return '缺少版本号，无法确认是否兼容';
      case 'parse-error': return 'JSON 解析失败';
      default: return '不是有效的冠军 JSON（' + (reason || 'unknown') + '）';
    }
  }
  function resetChamp() {
    openModal('<h3>确定清空本地冠军策略？</h3><p style="color:var(--dim);font-size:13px">之后“困难”难度将代打中等逻辑，直到重新训练或导入。</p>', [
      { label: '取消', fn: closeModal },
      { label: '清空', fn: function () { closeModal(); Champ.store.clear(); renderChampState(); } }
    ]);
  }

  /* v1.6.5：人数 × 血量 → 模式键（`modeFor` 那张表是唯一来源）。
   * 旧版这根叫 `syncModeOptions`，方向是反的：先选模式、再把"与人数不符"的选项置灰 ⇒
   * 「2 人 · 5 血」「任意人数 · 4 血」在界面上根本不存在。现在两根下拉都可点，模式只是查表结果。 */
  function applyAxes() {
    const pl = $('sel-players'), hp = $('sel-hp');
    if (pl) B.players = parseInt(pl.value, 10) || 2;
    B.hp = hp ? (parseInt(hp.value, 10) || 3) : 3;
    B.modeKey = modeFor(B.hp, B.players);
    if (hp && hp.value !== String(B.hp)) hp.value = String(B.hp);   // 非法值回落后写回，界面与实际建的模式不许分叉
  }

  /* ---------- 事件绑定 ---------- */
  function bind() {
    $('tab-battle').onclick = function () { showTab('battle'); };
    $('tab-train').onclick = function () { showTab('train'); };
  $('tab-rules').onclick = function () { showTab('rules'); };
    applyAxes();   // 首屏同步一次（人数/血量 → 模式键）
    $('btn-lastlog').onclick = showLastBattle;
    /* v1.6.5：两根轴各自的重开逻辑一样（换局），差别只在 `newGame` 里查出来的 modeKey 不同。 */
    $('sel-players').onchange = function () { newGame(); };
    $('sel-hp').onchange = function () { newGame(); };
    $('sel-diff').onchange = function () {
      const prev = B.diff;
      B.diff = $('sel-diff').value;
      /* §E667：换档**不换局**（这条本来就写着"对局中即时生效"）⇒ 一局可能是两档拼的。
       *   导出的头部若只写开局对手就把"前面 K 回合由 A 打、之后由 B 打"说成"全程由 A 打"，
       *   所以这里当场把换档后的逐席也记一行（开局那一格不动，它记的是开局）。 */
      if (B.state && B.state.p && prev !== B.diff) {
        const oi = aiInfo();
        /* 池档的逐席标签不含剂量，补一段；非池档时 `seatOppLabel` 返回的就是 `source`，它自己已经带 ε ⇒ 不再追加 */
        const dose = (oi.poolDraw && oi.eps != null)
          ? ' ε=' + oi.eps + '/k' + oi.epsK + '/' + oi.epsMode + (oi.ramp ? '·斜坡' : '') : '';
        B.oppMid = (B.oppMid || []).concat(['第 ' + (B.roundStarted ? B.state.round : B.state.round + 1) +
          ' 回合起改 ' + diffName(B.diff) + '：' + seatOppLabel(oi) + dose]);
      }
      hint('难度已切换：' + diffName(B.diff) + '（对局中即时生效）');
    };
    $('btn-newgame').onclick = newGame;
    /* v1.5.10（用户要求）：清掉本机冠军、改回内置冠军 */
    if ($('btn-champ-reset')) $('btn-champ-reset').onclick = useBuiltinChampion;
    /* v1.5.11：终局收缩参数入口（读回本机上次的值 + 改动即存） */
    loadSd();
    if ($('inp-sd')) $('inp-sd').addEventListener('change', saveSd);
    if ($('inp-sd-dmg')) $('inp-sd-dmg').addEventListener('change', saveSd);
    $('btn-undo').onclick = undo;
    $('btn-exportlog').onclick = exportLog;
    $('btn-train').onclick = connectRemoteTrain;
    $('btn-stop').onclick = stopRemote;
    $('btn-eval').onclick = doEval;
    $('btn-export').onclick = exportChamp;
    $('btn-reset').onclick = resetChamp;
    $('btn-train-csv').onclick = exportTrainCsv;
    $('btn-remote').onclick = resetServerTrain;
    $('file-import').onchange = function (ev) { importChamp(ev.target.files && ev.target.files[0]); ev.target.value = ''; };
    window.addEventListener('resize', function () { drawChart(); });
  }

  /* logbox 注入到 DOM（index.html 中 .logbox 属于电脑侧栏） */
  function ensureLog() {
    if ($('logbox')) return;
    const side1 = $('side-1');
    const box = document.createElement('div');
    box.className = 'logbox'; box.id = 'logbox';
    side1.appendChild(box);
  }

  bind();
  newGame();
  renderChampState();
  // P1：若加载时发现并清除了“旧架构/不兼容”的**本地**冠军，提示一次（内置冠军不兼容属于版本升级正常现象，不弹窗）
  const why0 = Champ.store.lastInvalidReason;
  if (why0 && why0.indexOf('builtin-') !== 0) {
    const why = champReasonText(why0);
    if (why) setTimeout(function () { alert('检测到旧版/不兼容的本地冠军，已自动清除：' + why); }, 300);
  }
})();
