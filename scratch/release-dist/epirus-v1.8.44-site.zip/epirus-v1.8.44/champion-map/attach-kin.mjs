/* attach-kin.mjs —— §E328：把"这批新点是谁"标清楚，并且**不许它们冒充冠军**。
 *
 * 背景（用户 10-05 20:2x）：「至少把现役的进化链相关的冠军以及同族其他有数据的冠军放到演化图里，
 *   并且现役好像有后续的一些训练结果只不过都不如现役所以没上」⇒ `chain-scan.mjs` 量出 **192 支臂**是以现役为种子续训的，
 *   其中 183 支的臂产品**从没进过面板**。`ruler-figs.mjs` 把它们的点画出来了，但 `lineage` 那一列被我填成了 '续训现役'，
 *   而**这一列在图上和查看器里都是"当过线上冠军"的意思**（`eps-full`/`eps-scan` 拿它当历代冠军名单的唯一来源，
 *   `e287-figs` 打印的"历代上槽冠军 198 枚"就是把这 183 枚算进去了 —— 那是**假的 198**，真的只有 15 枚 + 现役）。
 *
 * 所以这一步做三件事，且只这三件：
 *   ① 把这 183 枚的 `lineage` 清成空，另开一列 `kin` 标它们跟现役的关系（`续训现役` / `父链`）；
 *   ② 把改动前那份 `coords.tsv` 里的 `Sc/Scd/Scs/Sch` **按 id 原样搬过来**（当选键那四列是 §E321 花 24 万局量的，
 *      重跑 `attach-sc` 要再花两小时，而且那批新点本来**没量过** ⇒ 留空，查看器按"未测"压暗，不许当 0）；
 *   ③ 收尾打印守卫：冠军枚数必须回到 15+1，`kin` 非空枚数必须等于名单数。
 *
 * 用法：node champion-map/attach-kin.mjs --from=<改动前的 coords.tsv> --list=<_e328-extra.tsv> [--check]
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join, dirname, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { load as loadSlotId } from './slot-identity.mjs';   /* §E605：身份是不是"解析也认它上过槽"，只有这一份说了算 */

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');
const arg = (k, d) => { const a = process.argv.find(x => x.indexOf('--' + k + '=') === 0); return a ? a.slice(('--' + k + '=').length) : d; };
const FROM = arg('from', ''), LIST = arg('list', '_e328-extra.tsv');
if (!FROM) { console.error('⛔ 必须给 --from=<改动前的 coords.tsv>：没有它就无法把 Sc 四列原样搬回来'); process.exit(2); }
/* --from 原来只按**本目录**解 ⇒ 传仓库根相对路径（docs/artifacts/…）会拼成 champion-map/docs/… 而 ENOENT，
 *   传绝对路径又会被 join 吃掉前缀。这台是整条 coords 链的一环，路径解析必须和 attach-path/ruler-figs 一样：
 *   带斜杠的先按仓库根试，再按本目录试；裸名先本目录。 */
const resolve = p => { if (isAbsolute(p) && existsSync(p)) return p;
  if (p.indexOf('/') >= 0) { const a = join(ROOT, p); if (existsSync(a)) return a; }
  const b = join(HERE, p); if (existsSync(b)) return b;
  const c = p.indexOf('/') >= 0 ? join(ROOT, p) : p;
  console.error('⛔ 读不到 ' + p + '（试过 ' + b + ' ‖ ' + c + '）'); process.exit(2); };

/* 读表不许 `.trim()` 整个文件（§E375：coords.tsv 的末行常是最后加进来的那批，后列空着 ⇒ trim 会连着制表符
 *   把行尾那几个空单元格一起削掉，本行就少 5 列，往后 append 的列全部错位。只剥行尾换行，不剥空白。）*/
const read = p => readFileSync(p, 'utf8').replace(/\r\n/g, '\n').replace(/\n+$/, '').split('\n').map(l => l.split('\t'));
const CO = read(join(HERE, 'coords.tsv')), H0 = CO[0], ROWS = CO.slice(1);
const OLD = read(resolve(FROM)), OH = OLD[0], OR = OLD.slice(1);
const idx = h => { const o = {}; h.forEach((k, i) => { o[k] = i; }); return o; };
const ch = idx(H0), oh = idx(OH);
for (const need of ['id', 'lineage', 'H', 'S']) if (ch[need] === undefined || oh[need] === undefined) {
  console.error('⛔ 两份表都必须有 ' + need + ' 列（一份表头缺了它 ⇒ 我拒绝猜列位）'); process.exit(2); }

/* 名单：id -> kin 标签。`E51-t8-713` 是父链（`chain-scan.mjs` 往上走那一步的产物），其余是子代。 */
const LT = read(join(HERE, LIST)), lh = idx(LT[0]);
if (lh.arm === undefined) { console.error('⛔ --list 要有 arm 列（表头：' + LT[0].join('\t') + '）'); process.exit(2); }
const KIN = {};
for (const r of LT.slice(1)) { if (!r[lh.arm]) continue; KIN[r[lh.arm]] = r[lh.arm] === 'E51-t8-713' ? '父链' : '续训现役'; }

const OLDROW = {}; for (const r of OR) OLDROW[r[oh.id]] = r;
const SC = ['Sc', 'Scd', 'Scs', 'Sch'];
const hasSc = SC.every(k => oh[k] !== undefined);
if (!hasSc) console.warn('⚠ 旧表里没有 Sc 四列 ⇒ 这一版只清 lineage、不搬当选键读数');

/* 表头 = 现表的列 + （若新表没带当选键四列则补上）+ `kin`。**只往尾部加列**，已有列的位置一个都不动。 */
const NEED_SC = hasSc && ch.Sc === undefined;
const OUT_H = H0.concat(NEED_SC ? SC : []).concat(['kin']);
const ROWLEN = OUT_H.length;
const out = [OUT_H.join('\t')];
let cleared = 0, carried = 0, keptChamp = 0;
/* §E488：`lineage` 这一列在图上/查看器里都是"**当过线上冠军**"的意思，所以它只许吃这几类。
 *   原来"清不清"只看"在不在 chain-scan 的名单里" ⇒ 任何**新批次**自带一个没见过的 lineage 值，
 *   就会既不被清、又被算进冠军数（本轮加三枚融合粒时踩到：它们带的 '融合（权重平均）' 不是冠军身份）。
 *   ⇒ 改成白名单：不在名单里但类别不认识 ⇒ 清成空并计数，类别一律不许自己长出来。
 * §E600-A（用户 10-12 裁定③：「如今没有『当前现役』这个东西了，顶多只有当前困难席平均水平」）：
 *   白名单**收掉 `当前线上`** —— 池上线后逐席抽签，没有任何一枚是"玩家遇到的那一个"，
 *   而"活槽此刻住的是谁"由 `slot-identity.mjs` 现解，不再是一个写进表里的身份类别。
 *   ⇒ 副作用正是想要的：旧 ruler 表里残留的 `当前线上` 会被这台自动清成空并计数（不必手工回改 20 张历史表）。*/
const CH_CLASSES = { '历代上槽': 1, '旧槽位冠军': 1 };
/* §E605（10-14 晚，用户裁"五条全修"的第②条）：原来这句是 `if (kin || 类别不合法) 清身份` ⇒ 把"有 kin"当成"身份必假"。
 *   病（现算复现）：折行之后 `Ldemo` 一行**同时**带 `lineage=历代上槽`（从旧 `SHIPPED-Ldemo` 行 UNION 过来）
 *   与 `kin=续训现役`（旧 `Ldemo` 行自己的），而这两件事**都真的**：那枚包既是当年上槽的冠军、也确实有续训子代。
 *   ⇒ 对账报 `冠军枚数 34 ≠ 旧表真冠军 35`（差值 -1，就是这一行被清掉了）。
 *   改法不是"给 Ldemo 开后门"，而是承认这两列**是两个所指**（kin = 这枚是谁的子代 ‖ lineage = 这枚当过线上冠军），
 *   只有当身份**没有独立凭据**时才清 —— 凭据就用 `slot-identity` 的解析名单（`onSlot`，来自 slot-timeline 逐提交解出的权重），
 *   §E488 那 183 枚假冠军不在解析名单里 ⇒ 照旧被清 ⇒ 牙口没削（验证见本文件下面那条注释里的反例）。 */
const ON_SLOT = new Set(loadSlotId(ROOT).onSlot);
const bothCols = [];
const unknownCls = {};
for (const r of ROWS) { const c = r[ch.lineage]; if (c && !CH_CLASSES[c]) unknownCls[c] = (unknownCls[c] || 0) + 1; }
if (Object.keys(unknownCls).length) console.log('⚠ §E488 这批表里带了**不是冠军身份**的 lineage 类别，按白名单清成空：' +
  Object.entries(unknownCls).map(([k, v]) => k + ' ' + v + ' 枚').join(' ‖ '));
for (const r of ROWS) {
  const id = r[ch.id];
  const row = r.slice();
  while (row.length < H0.length) row.push('');
  const kin = KIN[id] || '';
  const cls = row[ch.lineage];
  /* 清身份的两种情况：类别不在白名单里（§E488 那批"新批次自带一个没见过的身份"）‖
   *   有 kin 而身份**又没有解析凭据**（§E488 那 183 枚把子代标成冠军的）。两者都不成立 ⇒ 保留。 */
  const badCls = cls && !CH_CLASSES[cls];
  const fakeByKin = kin && cls && CH_CLASSES[cls] && !ON_SLOT.has(id);
  if (badCls || fakeByKin) { if (cls) cleared++; row[ch.lineage] = ''; }
  else if (cls) { keptChamp++; if (kin) bothCols.push(id + '(' + cls + ')'); }
  /* Sc 四列：新表（ruler-figs 重画时不带这四列）以旧表为准，量过的原样搬，没量过的**留空**（不许当 0） */
  if (NEED_SC) for (const k of SC) row.push(OLDROW[id] ? (OLDROW[id][oh[k]] || '') : '');
  if (OLDROW[id]) carried++;
  row.length = ROWLEN - 1;                       // 硬截到"加 kin 之前"的长度，多一列少一列都不会错位
  if (row.length < ROWLEN - 1) while (row.length < ROWLEN - 1) row.push('');
  out.push(row.concat([kin]).join('\t'));
}

/* 上面那段"ch.Sc === undefined 时才补列"的分支是有前提的：新表若已经带 Sc 列（说明这一步跑在 attach-sc 之后），就不该再补。
 *   两种情况都要能跑，但**必须只有一种成立** ⇒ 这里显式判一下，别让列重复出来。 */
const dupSc = OUT_H.filter(x => x === 'Sc').length;
if (dupSc > 1) { console.error('⛔ 表头里出现两列 Sc ⇒ 这一步与新表的列序不匹配，别写文件'); process.exit(2); }

/* 判据挪到**写之前**：旧版是 writeFileSync 之后才判 ⇒ 一红就已经把 coords.tsv 换掉了，
 *   下一次跑还"从坏的那份接着修"，得靠人手工复原（本仓踩过同族的：空跑必须响亮失败，且不许留下半成品）。 */
const body = out.slice(1).map(l => l.split('\t'));
const OUT_LIN = OUT_H.indexOf('lineage'), OUT_KIN = OUT_H.indexOf('kin');
const nChamp = body.filter(r => r[OUT_LIN]).length, nKin = body.filter(r => r[OUT_KIN]).length;
/* 冠军枚数不靠"看着像"判。原先写的是 `> 20 就停` —— 那是拿今天 15 枚的规模猜的一个魔数，
 *   §E375 往里加 16 枚**真**旧槽位冠军就会把它撞红，而红的原因根本不是"那 183 枚假冠军回来了"。
 *   ⇒ 改成结构式对账：旧表里的真冠军数（那批人已经核过）+ 本轮新打上"旧槽位冠军"这一类的行数，两者必须逐枚对上。
 *   牙口验过：给 --list 换成一份不覆盖那 183 枚的名单 ⇒ 假冠军活下来，报"214 ≠ 15 + 16"EXIT=2。 */
const oldChamp = OR.filter(r => r[oh.lineage]).length;
const newSlot = ROWS.filter(r => r[ch.lineage] === '旧槽位冠军').length;
/* §E488：这一条守卫原来算的是 `旧表非空 lineage 数 + 新表"旧槽位冠军"数`，而**旧表那 31 行里已经含那 16 枚**
 *   ⇒ 它是拿"增量"的算式去核"全量"的数据：§E375 那一次能过，是因为那一轮真的把 16 枚从 0 加到 16；
 *   之后任何一次重跑都会报 `34 ≠ 31 + 16`（实测：本轮加三枚融合粒时撞红，差值 -13 完全由这个双计造成）。
 *   ⇒ 改成只算**本轮新增**的旧槽位冠军：`expected = 旧表非空 + (新表该类 − 旧表该类)`。
 *   牙口没削：把 183 枚假冠军放回来仍然会报（nChamp 214 vs expected 31），因为增量算式不会替它们开门。*/
const oldSlot = OR.filter(r => r[oh.lineage] === '旧槽位冠军').length;
const expect = oldChamp + (newSlot - oldSlot);
if (nChamp !== expect) {
  console.error('⛔ 冠军枚数 ' + nChamp + ' ≠ 旧表真冠军 ' + oldChamp + ' + 本轮**新增**的旧槽位冠军 ' + (newSlot - oldSlot) +
    '（新表该类 ' + newSlot + ' ‖ 旧表该类 ' + oldSlot + '）⇒ 要么 ' + LIST + ' 那批没被清掉，要么新加的类没打上 lineage（差值 ' + (nChamp - expect) + '）'); process.exit(2); }
console.log('守卫 ✅ 冠军 ' + nChamp + ' = 旧表 ' + oldChamp + ' + 本轮新增旧槽位冠军 ' + (newSlot - oldSlot) + '（旧表该类 ' + oldSlot + '）');
if (bothCols.length) console.log('  §E605 保留下 ' + bothCols.length + ' 枚"既当过槽、又有续训子代"的行（kin 与 lineage 同行，解析认它上过槽）：' + bothCols.join(' ‖ '));
if (nKin !== Object.keys(KIN).length) console.warn('⚠ kin 非空 ' + nKin + ' ‖ 名单 ' + Object.keys(KIN).length + ' —— 差的那几枚在面板里没有行');

if (process.argv.includes('--check')) {
  console.log('--check：会写 ' + body.length + ' 行；清掉假冠军 ' + cleared + ' ‖ 保留真冠军 ' + keptChamp + ' ‖ 搬 Sc 四列 ' + carried + ' 枚');
  process.exit(0);
}
writeFileSync(join(HERE, 'coords.tsv'), out.join('\n') + '\n');
const CH = read(join(HERE, 'coords.tsv'));
console.log('已写 coords.tsv：' + (CH.length - 1) + ' 枚 ‖ lineage 非空（真冠军）' + nChamp + ' ‖ kin 非空 ' + nKin);
if (CH.length - 1 !== body.length) { console.error('⛔ 回读 ' + (CH.length - 1) + ' 行 ≠ 内存 ' + body.length + ' 行'); process.exit(2); }

