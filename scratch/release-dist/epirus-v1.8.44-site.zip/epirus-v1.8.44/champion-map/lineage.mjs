/* lineage.mjs —— §E304：把"家族"从**训练随机种子**换成**训练方法 / 目标的大改**。
 *
 * 为什么必须换（用户 10-05 原话）：「你标记出来的家族是 seed 数字，看起来像是单纯训练过程中随机数的种子，
 *   要是这样就没什么用了」。实测坐实：`coords.tsv` 的 seed 列只有 **14 个取值**（31~36 / 81~82 / 91~96），
 *   而它就是包名尾部那个数 = META 里的 `seed` ⇒ 同一个 seed 被几十上百枚毫不相干的臂复用 ⇒ **它标的是 RNG，不是血统**。
 *
 * 那血统在哪？META 里有三样真东西：
 *   ① `ts`            —— 这枚什么时候训出来的（时间轴）
 *   ② `hotstartFrom`  —— **父指针**：从哪一枚的权重热启动来的（一个哈希）
 *   ③ 目标/方法配置    —— `ecoEffective`/`fightEffective`（divW/divK/stockBonus/hoardPen/dealW/firstW/whistlePen…）
 *                        + `mode`/`n`/`pop`/`gens`/`games`/`opps` 数量 + `rulesFingerprint`（世界版本）
 *
 * 本脚本第一步是**普查**（--survey）：把 717 枚的 META 全读一遍，打印每个字段有多少个不同取值、
 * 哪些字段真的随时间摆过 —— 家族该按哪几根轴分，由这个读数决定，不是我拍脑袋。
 * 第二步（默认）才落 `lineage.tsv`：id → 家族号 + 家族标签 + 父指针 + 时间。
 *
 * 用法：node champion-map/lineage.mjs --survey
 *      node champion-map/lineage.mjs
 */
import { readFileSync, writeFileSync, existsSync, readdirSync } from 'node:fs';
import { braceObj, parseMeta, widOf, packArr, widOfArr } from './pack-id.mjs';
import { sandbox } from '../tools/audit-lib.mjs';   /* §E464 只为拿 embedLegacy：同一枚包的两个身份要按同一条嵌入规则算，不留第二份 */   // §E328：身份三件套搬进单一来源（函数体逐字搬，本文件行为不变）
import { join, dirname, isAbsolute } from 'node:path';   /* §E591：`isAbsolute` 必须有 —— 绝对路径拼进仓根就是"文件在、读不到"（规矩 124） */
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');
const ART = join(ROOT, 'docs', 'artifacts');
const SURVEY = process.argv.includes('--survey');
/* v1.8.34：把**下面那张 10-21 合并/改名表生效之前**的家族表打到 stdout 然后退出（不写文件）。
 *   为什么要有这台读数：那张表历史上是"按号点家族"的，而号来自按 t0 排的原始聚类 ⇒ 往表里加几枚新点
 *   就能让整张表**悄悄指向别的家族**（10-24 实测：`8e39c13e` 加 6 枚之后，标签「融合与续训」压在了一枚 SOUP 都没有的
 *   40 枚家上，而真融合那 6 枚散进别家；「旧生产对照」那一行整个消失 ⇒ 用户看图抓到"点飞到天上去了"）。
 *   现在那张表改成按**锚枚 id** 点家族，锚枚就取自这份读数 ⇒ 要换/加锚，先跑 `--dumpdefs` 看清原始聚类长什么样。 */
const DUMPDEFS = process.argv.includes('--dumpdefs');

/* ⚠ 读表一律先把 CRLF 归一成 LF：本仓工作树是 CRLF，`split('\n')` 会把**末列**留成带裸 \r 的串
 *   ⇒ `indexOf('path')` 返回 −1（path 恰好就是 coords.tsv 的末列，实测被 git checkout 兜一圈后就是这样）。*/
const rd = f => readFileSync(f, 'utf8').replace(/\r\n/g, '\n');
const ids = rd(join(HERE, 'coords.tsv')).trim().split('\n').slice(1).map(l => l.split('\t')[0]);

/* ===== §E613 包内没自报 `ts` 时的**补录表**（10-16 早上用户看图抓出来的那条静默病）=====
 *   病：查看器的横轴就是训出时刻，`viewer.mjs:1781` 对 `Date.parse(ts)` 非有限值**直接不定位**（`PT(i)` 返回 null）
 *     ⇒ `pos[父id]` 缺失 ⇒ `:1819` 那句 `if (!dd.pof || !pos[dd.id] || !pos[dd.pof]) continue` 把父边**一条不画、一声不响**。
 *     实测：`G12H1` 的父 `clone-79101` 是 796 枚里**唯一**没有 ts 的一枚（监督克隆产物不盖时间戳）⇒ 卡片区写着
 *     "父边来路 = hash"，图上却是孤点。症状不是数字错，是**一条有哈希为证的实线被静默丢掉**。
 *   为什么不改包：往包 META 里补 `ts` 会改权重指纹 ⇒ 那条 `hash` 级父边自己作废（R3 同族）。
 *   为什么不在查看器里给"时间未知"造一列：横轴是时间，给未知时间编一个位置 = 把缺测画成一个读数
 *     （[[feedback-subcell-control]] 那条"分母为 0 的 0% 与真 0 同形"的图版）。
 *   ⇒ 补录必须**带证据串**，且由 `audit-parent-evidence.mjs` 那条新腿钉住"有 parentOf 的行两端 ts 都得非空"。
 *   ⚠ 这张表只填**缺 ts 的**，不许拿它覆盖包内自报值（覆盖 = 把训练侧的时钟换成研究侧的，历史读数就没法核）。 */
const TSFIX = {};
{ const p = join(HERE, 'ts-override.tsv');
  if (existsSync(p)) { const T = rd(p).replace(/\n+$/, '').split('\n').map(l => l.split('\t')), th = Object.fromEntries(T[0].map((x, i) => [x, i]));
    for (const r of T.slice(1)) if (r[th.id] && r[th.ts]) TSFIX[r[th.id]] = r[th.ts]; } }
let nTsFix = 0;

/* `braceObj` / `parseMeta` / `widOf` 住在 `./pack-id.mjs`（§E328 起）—— 那份注释也在那里。 */
/* §E330：**同一个 id 在盘上可以有两份不同的包**，而血统表过去只按 `docs/artifacts/<id>.bak` 找 ⇒ 读错了文件。
 *   实测后果：`M05-111` / `D4a` / `E20-71` 这些"续训现役"的臂产品，真身在 `docs/artifacts/e234-out/…`（ts = 10-02），
 *   而顶层另有一份同名的旧拷贝（ts = 现役那颗的 `2026-09-27T08:55:34`）⇒ 谱系图上 **181 枚子代全叠在同一秒**
 *   （用户 10-05 21:0x：「由现役继续训练的一堆点全重合了」）。
 *   修法不是猜：`coords.tsv` 的 `path` 列（由 `attach-path.mjs` 从现测尺表贴进来）就是量它时真用的文件 ⇒
 *   名单和路径同表同序，下游（本文件、`feas.mjs`）不再各自拼约定路径。 */
const PATHOF = {};
{
  const CL = rd(join(HERE, 'coords.tsv')).trim().split('\n');
  const ch = CL[0].split('\t'), iId = ch.indexOf('id'), iPath = ch.indexOf('path');
  if (iPath < 0) { console.error('⛔ coords.tsv 没有 path 列 ⇒ 先跑 node champion-map/attach-path.mjs'); process.exit(2); }
  for (const l of CL.slice(1)) { const c = l.split('\t'); if (c[iId] && c[iPath]) PATHOF[c[iId]] = c[iPath]; }
  console.log('路径表（coords.tsv 的 path 列）：' + Object.keys(PATHOF).length + ' 条');
}
const REC = [];
let nmiss = 0, nByPath = 0;
/* §E503：**声明**是融合粒的枚（包 meta 里写了 `soup.sources`）—— 与"这张表里解析出父边的枚"分开数。
 *   为什么必须分开：融合粒的父多半住在 gitignored 的 `docs/artifacts/…`（本机才有），
 *   干净克隆里 `wid → 节点` 全解不开 ⇒ `psrc` 不再是 'soup' ⇒ **第二父边从 6 条静默塌成 0 条**，
 *   而 `lineage.mjs` 照样退出码 0、页面自测照样绿（它读的是已生成好的表）。这条声明数就是那把"应当有几条"的尺。 */
let nSoupDeclared = 0;
const SOUPDECL = [];
for (const id of ids) {
  const rel = PATHOF[id];
  const p = rel ? join(ROOT, rel) : join(ART, id + '.bak');
  if (rel) nByPath++;
  let m = null, wid = null, used = rel || '';
  if (existsSync(p)) { const txt = readFileSync(p, 'utf8'); m = parseMeta(txt); wid = widOf(txt); }
  else if (/bundled-champion-3p\.js$/.test(String(rel || ''))) { const alt = join(HERE, '..', 'js', 'bundled-champion-3p.js');
    /* §E464 这条兜底**只服务"这一行就是现役那颗"**（SHIPPED-Ldemo 的 path 正是这个文件，只是 ROOT 拼法可能落空）。
     *   原来它挂在"任何文件读不到"的分支上：实测把 e370-out（未入库那批 v7 导出）挪走模拟换台机器 ⇒
     *   16 枚旧槽位冠军全部走进这一支，META/wid 被写成**现役那颗**的（d490dc13…）⇒ 谱系表 711 行的家族签名跟着变。
     *   "读不到"就该是读不到，不许拿别人的身份顶上（同一套判据见 §E330「不许凭一条路径凭空造节点」）。*/
    if (existsSync(alt)) { const txt = readFileSync(alt, 'utf8'); m = parseMeta(txt); wid = widOf(txt); used = 'js/bundled-champion-3p.js'; } }
  if (!m) { nmiss++; REC.push({ id, m: null, wid, rel: used }); continue; }
  REC.push({ id, m, wid, rel: used });
}
console.log('按 coords.tsv 的 path 列解析 ' + nByPath + ' 枚 ‖ 其余按 docs/artifacts/<id>.bak 兜底');
console.log('读到 META ' + REC.filter(r => r.m).length + ' / ' + ids.length + ' 枚（缺 ' + nmiss + '）‖ 算出权重身份 ' +
  REC.filter(r => r.wid).length + ' 枚');

/* 普查的字段清单：目标面 + 方法面 + 世界面。数组值取长度，对象值递归一层。 */
const FIELDS = ['source', 'mode', 'n', 'pop', 'gens', 'games', 'workers', 'fresh', 'seedEmbeddedFrom',
  'styleW', 'styleGames', 'rulesFingerprint', 'hotstartFrom', 'seed',
  'oppsN', 'styleOppsN',
  'eco.divW', 'eco.divK', 'eco.divRoleW', 'eco.divCatW', 'eco.stockBonus', 'eco.hoardPen', 'eco.target', 'eco.cap',
  'eco.targetOverride', 'eco.capOverride', 'eco.K_role',
  'fight.dealW', 'fight.firstW', 'fight.whistlePen', 'fight.override',
  'feas.ok', 'feas.G', 'feas.seatVerdict'];
function get(m, path) {
  const seg = path.split('.');
  if (seg[0] === 'oppsN') return Array.isArray(m.opps) ? m.opps.length : (typeof m.opps === 'string' ? m.opps.split(',').filter(Boolean).length : 0);
  if (seg[0] === 'styleOppsN') return typeof m.styleOpps === 'string' ? m.styleOpps.split(',').filter(Boolean).length : 0;
  let v = m; for (const s of seg) { if (v == null) return undefined; v = s === 'eco' ? (v.ecoEffective || v.ecoOverride) : s === 'fight' ? (v.fightEffective || v.fightOverride) : s === 'feas' ? v.feasibility : v[s]; }
  return v;
}
const prof = {};
for (const f of FIELDS) prof[f] = new Map();
for (const r of REC) { if (!r.m) continue;
  for (const f of FIELDS) { let v = get(r.m, f);
    if (v === undefined || v === null) v = '∅';
    else if (typeof v === 'object') v = JSON.stringify(v).slice(0, 24);
    prof[f].set(String(v), (prof[f].get(String(v)) || 0) + 1); } }
if (SURVEY) {
  for (const f of FIELDS) { const s = [...prof[f].entries()].sort((a, b) => b[1] - a[1]);
    console.log(('  ' + f).padEnd(20) + ' 取值数 ' + String(s.length).padStart(4) + ' ‖ ' +
      s.slice(0, 6).map(([k, c]) => k + '×' + c).join('  ')); }
  /* 时间轴：按月/日分桶看 META 的密度，"大改"必然是时间上的一次跳变 */
  const byDay = {};
  for (const r of REC) { if (!r.m || !r.m.ts) continue; const d = String(r.m.ts).slice(0, 10); byDay[d] = (byDay[d] || 0) + 1; }
  console.log('\n按日（ts）分布：');
  for (const d of Object.keys(byDay).sort()) console.log('  ' + d + '  ' + String(byDay[d]).padStart(4) + ' 枚  ' + '#'.repeat(Math.min(60, byDay[d])));
  process.exit(0);
}

/* ===== 家族 = **方法/目标配置**的等价类；父指针与规则指纹**不进签名** =====
 * 第一版把 `hotstartFrom` 也放进签名 ⇒ 48 个类、还得并掉 120 枚"零散"，而那 120 枚里 49 枚的配置和
 * 家族 13 一模一样、只是换了个热启动父 ⇒ 说明**父指针是"分支"、不是"家族"**（用户要的是"训练方法或目标大改"）。
 * ⇒ 签名只留目标面 + 方法面；parent / rulesFp 另存成 `branch`，给谱系图当分叉用。
 * 轴的选择全部来自普查（只留"真的摆过"的字段）：
 *   目标面  eco.divW（珠价/多样性权重 0/0.06/0.3/0.6 四档）· divK · divRoleW · divCatW · stockBonus · hoardPen
 *            · target · cap ‖ fight.dealW · firstW · whistlePen ‖ styleW
 *   方法面  oppsN（对手池大小）· seedEmbeddedFrom · gens · mode*/
const AXES = ['divW', 'divK', 'divRoleW', 'divCatW', 'stockBonus', 'hoardPen', 'eTarget', 'eCap',
  'dealW', 'firstW', 'whistlePen', 'styleW', 'oppsN', 'seedEmb', 'gens', 'mode'];
const BRANCH = ['parent', 'rulesFp'];
function norm(v) { if (v === undefined || v === null || v === '' || v === '∅') return '-'; 
  const n = Number(v); return Number.isFinite(n) && String(v) !== '∅' ? (Math.round(n * 1000) / 1000) : String(v); }
const ROWS = [];
/* 权重身份表要扫**全部** .bak（1461 个），不能只扫本图的 718 枚 —— 父指针指向的是"当时的现役冠军"，
 *   而那一枚未必进了 §E287 那批面板。实测只扫 718 枚时解析率 11%，扫全库后（下一行打印）才看得清谱系。*/
let nSlotEmb = 0, nOrig = 0;   /* §E607 nOrig = 把"原始 wid"这一头也接回面板行的条数 */
const BYWID = {};
const BYWID_EMB = {};   /* §E464 嵌入成 v7 之后的指纹 → 图上的 id */
let POL = null;
function embOf(arr) { try {
  if (!POL) POL = sandbox().EpirusPolicy;
  const r = POL.embedLegacy(arr); return r ? widOfArr(r) : null;
} catch (e) { return null; } }
const allBak = existsSync(ART) ? readdirSync(ART).filter(f => f.endsWith('.bak')) : [];
/* ⚠ §E604（10-14 折行之后）把这一条的**次序**换过来了：原来是"先扫全部 .bak 按文件名占位，再用面板行补漏"，
 *   于是同一份权重有两个文件时，**先被扫到的文件名**抢走了 BYWID。实测代价：
 *   `docs/artifacts/SHIPPED-Ldemo-2026-10-11-pre-T8s114.bak`（§E588 换包当天钉的快照，wid 与图上的 Ldemo **逐位相同** = d490dc13…）
 *   抢在 `Ldemo` 之前登记 ⇒ 33 枚子代的父边被写成那个文件名，而折行后面板上只有 `Ldemo` 一行
 *   ⇒ 页内那条「不许有任何父边指向图上不存在的枚」当场红 33 条。
 *   规矩本来就是这条（§E330「登记目标必须是面板上真有的那一枚」）：**先按面板登记，文件名只补面板上没有的权重**。 */
for (const r of REC) if (r.wid && !BYWID[r.wid]) BYWID[r.wid] = r.id;
for (const f of allBak) { try {
  const txt = readFileSync(join(ART, f), 'utf8'); const arr = packArr(txt);
  const w = widOfArr(arr); if (!w) continue;
  const id = f.slice(0, -4); if (!BYWID[w]) BYWID[w] = id;
} catch (e) { /* 单枚读不动不影响全表 */ } }
/* §E330 哈希之外还有第二条父指针：`recipe.env.EPIRUS_SEEDPACK` 记的是**文件路径**。
 *   现役那枚（js/bundled-champion-3p.js）走的正是这一条 —— 它**没有** hotstartFrom，实测
 *   `EPIRUS_SEEDPACK = docs/artifacts/kept/artifacts__E51-t8-713.bak` ⇒ 只按哈希解析时"当前线上"那个点没有父边，
 *   用户因此看不到现役的祖先。而它下面那 182 支臂的产物同样只写了这一条
 *   （`EPIRUS_SEEDPACK = js/bundled-champion-3p.js`）⇒ 图上"子代一堆点没有连线"也是这同一个洞。
 *   ⚠ 路径的**文件名 ≠ 图上的 id**：现役在图上叫 `SHIPPED-Ldemo`，文件却叫 `bundled-champion-3p.js`
 *   ⇒ 退路必须按"这枚在图上是从哪个文件读进来的"反查（`BYBASE`），不能拿文件名当 id 用。
 *   认不出的一律留空 —— 不许凭一条路径凭空造节点（chain-scan 同一套判据）。*/
const WIDOF = {}; for (const r of REC) if (r.wid) WIDOF[r.id] = r.wid;
const IDSET = new Set(REC.map(r => r.id));
const BYBASE = {};
for (const r of REC) { const k = String(r.rel || r.id).replace(/^.*[\\/]/, '').replace(/\.(bak|js)$/, '');
  if (k && !BYBASE[k]) BYBASE[k] = r.id; if (r.id && !BYBASE[r.id]) BYBASE[r.id] = r.id;
  const a = r.id.replace(/^SHIPPED-/, ''); if (a !== r.id && !BYBASE[a]) BYBASE[a] = r.id; }   /* 链上节点叫 Ldemo、图上叫 SHIPPED-Ldemo */
function seedpackFile(m) { const e = m.recipe && m.recipe.env; const p = e && e.EPIRUS_SEEDPACK;
  return typeof p === 'string' && p ? p : ''; }
const SLOT_BASE = 'bundled-champion-3p';
let nSlotEra = 0;
function seedpackOf(m, ts) { const p = seedpackFile(m); if (!p) return '';
  const k = p.replace(/^.*[\\/]/, '').replace(/\.(bak|js)$/, '');
  if (BYBASE[k]) return BYBASE[k];
  /* §E593：**活槽路径是时间相关的量** —— 同样的 `js/bundled-champion-3p.js` 在不同时刻住着不同的权重。
   *   ⇒ 按子包自己的 ts 问完整时间轴（那时住的是谁），而不是按"今天那格文件里装的是谁"。
   *   ⚠ 这不是"拿今天的槽主冒充昨天的父"（§E367 那个病）：走的是**当时那一段的实录**；
   *     而且时间轴没追到今天时 `slotEraAt` 直接返回 null ⇒ 这条路径仍解不出父（照旧虚线）。 */
  if (k === SLOT_BASE) { const e = slotEraAt(ts); if (e) { nSlotEra++; return e.id; } }
  return ''; }
/* ===== §E555 把"按路径解析出来的父"再问一句：**那份文件此刻的权重，和图上那个节点的权重是不是同一份？**
 *   为什么这一问值得问（用户 10-09 08:5x：「你昨天刚训练的怎么会不确定父节点」）：
 *   `train-3p` 写进包里的父只有 `EPIRUS_SEEDPACK`（一个**路径**），没有 `hotstartFrom`（权重哈希）⇒
 *   按 DS 10-08 定的分级（实线 = 有哈希为证 ‖ 虚线 = 从路径推断）今晚 271 枚连同 K2/D4a 全被画成虚线，
 *   读起来像"父是谁不知道"。可事实是：**父节点是确定的（K2），不确定的只是证据的级别**。
 *   而这一级其实可以升到"身份可核"：把 env 里那条路径指向的文件算一遍权重指纹，与该节点在册的指纹比 ⇒
 *   相等就不是"拿今天的槽主冒充昨天的父"（§E330/§E367 那两种病都被这一问挡住：同名不同权重会直接不等）。
 *   不等或读不到 ⇒ 保持 `seedpack`（虚线），**不给自己升等**。 */
const WIDCACHE = {};
/* §E591（10-12）：两处"路径还在、证据读不出来"的机械补法。
 *   病（实测，是我 10-11 §E589 那笔去重弄出来的）：`seedpack-wid`（实线）从 **153 掉到 8**，
 *   用户看到的是"后期那批点全变虚线"。两个原因都跟权重无关，纯粹是**文件搬了家 / 写法不同**：
 *     ① 有些包的 `EPIRUS_SEEDPACK` 写的是**绝对路径**（`D:/code/.../win-Ldemo.bak`），
 *        而这里一律 `join(ROOT, rel)` ⇒ 拼出 `D:\code\Epirus-Web\D:/code/...` 这种不存在的路径（规矩 124 那一族）。
 *     ② 去重把文件改名进了 `docs/artifacts/kept/`（两种命名都出现过：`artifacts__X.bak` 与 `dir__X.bak`），
 *        而子包 meta 里记的仍是**老路径** ⇒ `existsSync` 落空。
 *   ⚠ 这不是"猜父"：父节点早由 `byPath` 定死了，这一层只决定**能不能升到"权重身份可核"**，
 *     而升等唯一条件是 `读到的 wid === 节点在册 wid`（逐位相同的权重）。
 *     ⇒ 候选就算挑错文件，结果只会是"升不上去"，**不可能是"升错"**（§E330 的同名不同权重照样被这一问挡住）。 */
function seedCandidates(rel) {
  const out = [rel];
  const push = p => { if (p && out.indexOf(p) < 0) out.push(p); };
  if (isAbsolute(rel)) {
    /* 绝对路径也可能是**指向本仓**的（实测 52 枚的 meta 写的是 `D:/code/Epirus-Web/docs/artifacts/eval-out/win-Ldemo.bak`）。
     *   原样用在我这台机器上能读到，但 CI / 别人的机器上那个盘符路径不存在 ⇒ 同一张表会因机器不同而线型不同。
     *   ⇒ 只要它落在仓根内，就把相对形式也列进候选（读的是同一个文件，两边答案一致）。 */
    const nrm = rel.replace(/\\/g, '/'), rootNrm = ROOT.replace(/\\/g, '/');
    if (nrm.toLowerCase().indexOf(rootNrm.toLowerCase() + '/') === 0) push(nrm.slice(rootNrm.length + 1));
    return out;
  }
  const base = rel.replace(/^.*[\\/]/, '');
  push('docs/artifacts/kept/' + base);                   /* 只搬进 kept/、没改名 */
  if (/^docs\//.test(rel)) push('docs/artifacts/kept/' + rel.replace(/^docs\//, '').replace(/\//g, '__'));
  push('docs/artifacts/kept/' + rel.replace(/^docs\/artifacts\//, '').replace(/\//g, '__'));
  return out;
}
/* ===== 2026-10-12 DS：文件被搬走时，按**登记的别名表**解权重 =====
 * 修的是哪一件事：子包 meta 里 `EPIRUS_SEEDPACK` 点名的父**被去重搬走了**（实测全库只有一例：
 *   63 枚子包点名 `docs/artifacts/e234-out/K2.js`，那份文件在隔离区 `D:/code/Epirus-Web-artifacts-quarantine/`）
 *   ⇒ 候选全是**文件**路径 ⇒ 读不到 ⇒ 只能留虚线，而那 63 条的权重身份**本来是可查的**
 *   （搬它走的那台工具算过 wid：隔离区那份 = `kept/e70-out__D02-31.bak` = 父行 wid = `1d4b687da27187b7`，三边一致）。
 * 安全性：这张表只提供"这个路径当时是哪一粒权重"；**升等条件一字未改**（`seedpackVerified` 仍要求与父行 wid 逐位相等）
 *   ⇒ 登记错了只会升不上去。表里解不出的**照旧虚线** —— 不许拿今天的占位者冒充血统（§E555「读不到不许自我升等」）。
 *   ⚠ 这一段原来还写着「例如 33 条点名**活槽**路径的照旧虚线 —— 活槽换过主人，那些边在原理上就没记下
 *     '当时槽里是谁'」。**10-12 被证伪并升级（§E593）**：当时槽里是谁**有实录** —— `slot-timeline.tsv`
 *     是**槽文件侧**逐提交算权重指纹建的表（40 段全收，`ship-times.tsv` 只有 13 段有名字）
 *     ⇒ 那 33 条连同另外 14 条同族（`slot-at-time` 5 + `slot-infer` 9）已升到 `seedpack-wid`（实线）。 */
const ALIAS = (function () {
  const m = {};
  for (const spec of [['pack-aliases.tsv', 'wantedPath'], ['dupes-manifest.tsv', 'path']]) {
    try {
      const L = readFileSync(join(ROOT, 'champion-map', spec[0]), 'utf8').replace(/\r\n/g, '\n').trim().split('\n');
      const h = L[0].split('\t'), iK = h.indexOf(spec[1]), iW = h.indexOf('wid');
      if (iK < 0 || iW < 0) continue;
      for (const l of L.slice(1)) { const c = l.split('\t');
        if (c[iK] && c[iW] && !m[c[iK]]) m[c[iK]] = c[iW]; }
    } catch (e) { /* 表不在就不解：别让整张图因为缺一张登记表而炸 */ }
  }
  return m;
})();
function widOfFile(rel) { if (!rel) return ''; if (WIDCACHE[rel] !== undefined) return WIDCACHE[rel];
  let w = '';
  for (const cand of seedCandidates(rel)) {
    try { w = widOfArr(packArr(readFileSync(isAbsolute(cand) ? cand : join(ROOT, cand), 'utf8'))) || ''; } catch (e) { w = ''; }
    if (w) break;
  }
  if (!w) w = ALIAS[rel] || '';          /* 候选文件都读不到 ⇒ 按登记表解（搬走的那些）；解不出就留空 = 继续虚线 */
  WIDCACHE[rel] = w; return w; }
let nSpkWid = 0, nSpkLoose = 0, nSlotWid = 0;
function seedpackVerified(m, parId, ts) {
  if (!parId) return false;
  const f = seedpackFile(m); if (!f) return false;
  const wNode = WIDOF[parId] || '';
  const k = f.replace(/^.*[\\/]/, '').replace(/\.(bak|js)$/, '');
  if (k === SLOT_BASE) {
    /* §E593：活槽路径的"权重身份可核" = **当时那一段的实录权重** == 父节点在册的权重。
     *   两边的来路互相独立：段里的 wid 来自"槽文件侧逐提交算指纹"，父节点的 wid 来自面板的包。
     *   ⚠ 不许拿"今天那格文件里的内容"来比（§E367 的病）；时间轴追不到今天 ⇒ `slotEraAt` 返回 null ⇒ 升不上去。 */
    const e = slotEraAt(ts);
    return !!e && e.id === parId && !!wNode && e.wid === wNode; }
  const wFile = widOfFile(f); if (!wFile) return false;
  return !!wNode && wFile === wNode; }
/* ===== §E464 pre-v7 包的「第二身份」登记 =====
 * 训练服务记热启动父走的是 `weightsId(loadAny(种子).params)`，也就是**嵌入成 v7 之后**那份数组的指纹
 *   （FEAT_S 123 → 213 ⇒ 数组 3337 → 5689 ⇒ 哈希必变）⇒ 只索引「文件里那份数组」的哈希时，
 *   所有 pre-v7 包对父指针检索都是隐身的，§E314 因此把 585 枚共用的那个父判成「盘上无实体」。
 * 真相 = v1.3.57/58 那枚 = SLOT-e379c62c。但**登记目标必须是面板上真有的那一枚**，两条通道：
 *   ① 文件名能反查到图上节点（BYBASE，含"文件名 ≠ 图上 id"的那些）；
 *   ② 旧槽位冠军行（id = SLOT-<wid8>）：coords.tsv 把那几行的 path 指向 e370-out 的 v7 导出，而那批文件
 *      **没入库**（git ls-files = 0）⇒ 换台机器 clone 下来 BYWID 就没有这一项，584 条父边又会解不出来。
 *      这里改从**已入库的 v6 文件**推：某 .bak 的原始 wid 前 8 位 = 某个 SLOT 行的后缀 ⇒ 它的嵌入后 wid 登记给那一行。
 *      实测链路：champion-5p-v1.3.58.bak（tracked，commit 24b9f63）原始 e379c62ccd2648fa → 嵌入 d13d3c856c6cff62。
 * ⚠ 原来这条登记写在 .bak 扫描循环里、且不筛面板 ⇒ 它把 `d13d3c85…` 先记成了文件名 `champion-5p-v1.3.58`
 *   （图上没有这一枚），SLOT 规则随后一条也登记不到。不闸门上的结果就是"解析出一个不存在的父"。 */
{ const SLOTBY8 = {};
  for (const r of REC) { const m2 = /^SLOT-([0-9a-f]{8})$/.exec(String(r.id || '')); if (m2) SLOTBY8[m2[1]] = r.id; }
  for (const f of allBak) { try {
    const txt = readFileSync(join(ART, f), 'utf8'); const arr = packArr(txt);
    const w = widOfArr(arr); if (!w) continue;
    const rid = BYBASE[f.slice(0, -4)] || SLOTBY8[w.slice(0, 8)]; if (!rid) continue;
    /* §E607 这座桥原来**只搭了一半**：它登记"嵌入后的 wid → 面板行"，却没管**原始 wid** 那一头。
     *   实测代价（10-15 凌晨查出来的）：`long-33` 等 **56 枚**的 `hotstartFrom` 记的是**原始** wid（`e379c62c…`），
     *   而面板上那一行 `SLOT-e379c62c` 在册的是**嵌入成 v7 之后**的 `d13d3c85…` ⇒ `BYWID[原始]` 被上面那遍
     *   .bak 扫描按**文件名**占了位（`champion-5p-v1.3.58`，而它不是面板行）⇒ 那 56 条父边**一条也画不出来**，
     *   页面上看就像"父不可考"（用户原话：「历代上槽的 long-33 是找不到父节点」）。
     *   守的还是同一条老规矩（§E330 ‖ §E604）：**登记目标必须是面板上真有的那一枚**，文件名只能补面板没有的权重。 */
    if (IDSET.has(rid) && BYWID[w] !== rid && (!BYWID[w] || !IDSET.has(BYWID[w]))) { BYWID[w] = rid; nOrig++; }
    const e = embOf(arr); if (e && e !== w && !BYWID_EMB[e]) { BYWID_EMB[e] = rid; nSlotEmb++; }
  } catch (err) { /* 单枚读不动不影响全表 */ } }
  console.log('§E464 pre-v7 包的第二身份登记：' + nSlotEmb + ' 条（目标一律是面板上真有的节点；SLOT 行走已入库的 v6 文件，不依赖 e370-out 那批未跟踪的 v7 导出）' +
    ' ‖ §E607 其中把**原始 wid** 这一头也接回面板行的 ' + nOrig + ' 条（那批子代记的是嵌入前的哈希，不接就整片断边）'); }
/* 第三级退路 = **臂级**父指针（`chain-scan --emit=` 落的那张表）。为什么需要：一支臂留 7 个文件
 *   （1 枚产物 + 6 枚带内候选），实测**产物那份常常不带指针、带内候选那份带** ⇒ 只看产物就漏。
 *   臂级证据"这支臂是从 X 起步的"对产物同样成立，所以按 productRel 反查图上的那一枚。
 *   ⚠ 只认**面板上已有的父**（IDSET），表里没有的臂一律不接。*/
const ARMPAR = {};
{ const AP = join(HERE, '_e330-armparent.tsv');
  if (existsSync(AP)) {
    const A = rd(AP).trim().split('\n'), ah = A[0].split('\t');
    const iRel = ah.indexOf('productRel'), iPar = ah.indexOf('armParent');
    const REL2ID = {}; for (const r of REC) if (r.rel) REL2ID[r.rel] = r.id;
    for (const l of A.slice(1)) { const c = l.split('\t'); if (iPar < 0 || !c[iRel] || !c[iPar]) continue;
      const id = REL2ID[c[iRel]], par = BYBASE[c[iPar]] || c[iPar];
      if (id && par !== id && IDSET.has(par)) ARMPAR[id] = par; }
    console.log('臂级父指针表（chain-scan --emit）：' + Object.keys(ARMPAR).length + ' 支臂的产物能反查到图上已有的父');
  } else console.log('提示：没有 _e330-armparent.tsv ⇒ 臂级父指针这一级退路不生效（跑 node champion-map/chain-scan.mjs --emit=_e330-armparent.tsv）'); }
/* §E368 **槽位时间轴**（用户 10-06 23:0x 给的办法：「通过出厂日期 + CHANGELOG 里的记录可以推出当时槽上是谁」）。
 *   `ship-times.tsv` 是 §E338 那台 ship-scan 的产物 —— 它逐提交把 `js/bundled-champion-3p.js` 的内容取出来算权重指纹，
 *   某个 wid **第一次出现**的那条提交 = 那枚真正上槽的时刻 ⇒ 这张表本身就是"槽位由谁住过"的时间轴，不用另建。
 *   ⚠ 时区：表里的 shipWhen 是**提交时间的本地格式（+08）**，而包 META 的 ts 是 **UTC（Z）** ⇒ 显式补 +08:00 再比，
 *     不许拿字符串大小直接比（本仓已四次把 UTC/本地混着当）。 */
const SLOT_TL = [];
{ const sp = join(HERE, 'ship-times.tsv');
  if (existsSync(sp)) { const S = rd(sp).trim().split('\n'), sh = S[0].split('\t');
    const ii = sh.indexOf('id'), iw = sh.indexOf('wid'), iwh = sh.indexOf('shipWhen');
    for (const l of S.slice(1)) { const c = l.split('\t'); if (!c[iw] || !c[iwh]) continue;
      const t = Date.parse(c[iwh].replace(' ', 'T') + '+08:00');
      if (isFinite(t)) SLOT_TL.push({ id: c[ii], wid: c[iw], t: t }); }
    SLOT_TL.sort((a, b) => a.t - b.t); } }
/* §E593（10-12 DS）：**凡"当时槽里是谁"一律问完整时间轴**（`slot-timeline.tsv` = §E369 从**槽文件侧**逐提交
 *   算权重指纹建的那张，覆盖全部段落），不再用面板侧的 `ship-times.tsv`（实测只有 13 段有名字 / 槽文件换过 40 段）。
 *   两个病同源：
 *     ① 用户 10-12 报「D4a 一族 8 号时可证、现在不可证」——子包 meta 记的是**活槽路径** `js/bundled-champion-3p.js`，
 *        解析走的是"文件基名 → 面板"（`BYBASE`）。它原来解得出来**只因为**现役那行的 path 恰好就是这个文件；
 *        §E591 把现役行改指钉住的快照（免得量具静默量到别的包）⇒ 这条路径整族解不出父 ⇒ 从 `seedpack-wid`
 *        （实线）掉到 `arm`（虚线）。实测 `341724a`(10-09) 时 D4a/D2a 都是 `seedpack-wid`。
 *     ② `slotAt()` 在**没有名字的那些段**里会返回**上一个有名字的槽主** —— 那不是当时槽里的人，是**错的父**，
 *        而且 §E367 那道的"父比子晚"时间闸拦不住（上一个槽主本来就更早）。
 *   ⇒ 名字优先 `panelId`，其次按 `wid` 反查面板节点，两者都解不出就**不接**（宁缺勿错，与 §E330 同一条规矩）。
 *   ⚠ 时间轴必须**追到今天**（最后一段的权重 == 当下槽文件里的权重）：追不上 ⇒ 最后一段之后的区间"当时是谁"
 *     是不知道的 ⇒ 这一级整体不生效，并**响亮印出来**（不静默降级）。 */
const SLOT_FULL = [];
{ const f = join(HERE, 'slot-timeline.tsv');
  if (existsSync(f)) { const S = rd(f).trim().split('\n'), sh = S[0].split('\t');
    const iw = sh.indexOf('wid'), ip = sh.indexOf('panelId'), iu = sh.indexOf('fromUTC'), ia = sh.indexOf('metaArm');
    for (const l of S.slice(1)) { const c = l.split('\t'); const t = Date.parse(c[iu] || '');
      if (!isFinite(t)) continue;
      SLOT_FULL.push({ t: t, wid: (c[iw] || '').trim(), panelId: (c[ip] || '').trim(), arm: (c[ia] || '').trim() }); }
    SLOT_FULL.sort((a, b) => a.t - b.t); } }
const SLOT_NOWWID = widOfFile('js/bundled-champion-3p.js');
const SLOT_FULL_OK = !!(SLOT_FULL.length && SLOT_NOWWID && SLOT_FULL[SLOT_FULL.length - 1].wid === SLOT_NOWWID);
function slotEraAt(tsStr) {   /* 子包跑的那一刻槽里是谁 ⇒ { id, wid } 或 null */
  if (!SLOT_FULL_OK) return null;
  const t = Date.parse(tsStr); if (!isFinite(t)) return null;
  let hit = null; for (const s of SLOT_FULL) { if (s.t <= t) hit = s; else break; }
  if (!hit) return null;
  const id = (hit.panelId && IDSET.has(hit.panelId)) ? hit.panelId
    : (BYWID[hit.wid] || BYWID_EMB[hit.wid] || (hit.arm && IDSET.has(hit.arm) ? hit.arm : ''));
  return id ? { id: id, wid: hit.wid } : null; }
function slotAt(tsStr) { const e = slotEraAt(tsStr); return e ? e.id : ''; }
console.log('槽位时间轴：完整版（slot-timeline.tsv，槽文件侧）' + SLOT_FULL.length + ' 段 ‖ 面板侧（ship-times.tsv）'
  + SLOT_TL.length + ' 段 —— 凡"当时槽里是谁"一律问完整版（§E593）‖ 追到今天（末段 wid == 现役槽文件 ' + (SLOT_NOWWID || '—') + '）: '
  + (SLOT_FULL_OK ? 'yes' : 'no ⇒ 这一级不生效（跑 node champion-map/slot-timeline.mjs 重烘）'));
let nSpk = 0, nArm = 0;
/* §E367（用户 10-06 22:4x：「e35prod807 比父节点的父节点还要早，太离谱了」）
 *   查出来的真相：**那五条边是假的**。`_e330-armparent.tsv` 里 seed80/seed81/e35prod807/e35prod814/e39ctl911
 *   的 `seedpack` 一律是 **路径** `js/bundled-champion-3p.js`，而 byPath/byArm 这两级退路是拿"这个路径**今天**住的是谁"
 *   反查图上的节点的 ⇒ 于是"当时槽里那份权重（已被覆写、没留档）"被解析成了**现在的槽主 Ldemo**。
 *   实测对不上：现役那份权重 d490dc13 自己 META.ts = 09-27T08:55Z、最早可证的 git 实体 = 提交 3c17e23 @09-27T10:42Z，
 *   而 e35prod807 的 ts = 09-26T06:37Z ⇒ 它不可能热启动自一份**26 小时之后**才产出的权重。
 *   ⇒ 判据（只否**推断级**，不动实录）：父是按路径/臂名推出来的、而那个节点的 ts **晚于**子代 ⇒ 退回"父不可考"，
 *     并且**连那个哈希也不许留**（它是"今天槽主"的哈希，不是当时那份的）。
 *   ⚠ byHash 一级永远不否：那是包自己 META.hotstartFrom 里记的哈希，是实录；那种情况该怀疑的是 ts，不是边。*/
const IDTS = {}; for (const r of REC) IDTS[r.id] = (r.m && r.m.ts) || '';
let nBack = 0, nEmb = 0, nCold = 0, nUnres = 0, nSynthP = 0;   /* §E607 后三个 = "没有父边"的三种来路各多少枚（名字避开下面第 636 行那个 nSynth，那是另一码事） */
for (const r of REC) { const m = r.m || {};
  const byHash = (m.hotstartFrom && (BYWID[m.hotstartFrom] || BYWID_EMB[m.hotstartFrom])) || '';
  /* §E464 靠「嵌入后那个身份」才对上的单独记一笔（pSrc = hash-emb），不许混在 hash 里看不出来 */
  const byHashEmb = byHash && !BYWID[m.hotstartFrom] ? 1 : 0; if (byHashEmb) nEmb++;
  let byPath = byHash ? '' : seedpackOf(m, m.ts);
  let byArm = (byHash || byPath) ? '' : (ARMPAR[r.id] || '');
  const parId = byHash || byPath || byArm;
  const parTs = parId ? (IDTS[parId] || '') : '';
  let demoted = '', bySlot = '';
  if (parId && !byHash && parTs && m.ts && parTs > m.ts) {
    /* §E368：这种倒挂几乎一定是"父指针记的是**槽位路径**"被按今天的槽主解析了 ⇒
     *   先按时间轴问一句"它跑的那一刻槽里是谁"，接得回来就接（那才是真父），接不回来才退回不可考。*/
    const alt = slotAt(m.ts);
    if (alt && alt !== parId && IDTS[alt] && IDTS[alt] <= m.ts) bySlot = alt;
    else { demoted = parId; nBack++; }
    byPath = ''; byArm = ''; }
  /* ===== 2026-10-12 DS：**确实热启动了，但父只在槽位时间轴里** =====
   * 用户 10-12 报的病：`E51-t8-713` 那一大批点**整片断联** —— 它自己 `parent = -`。
   * 证据（写在包里，不是猜）：它的 `recipe.env.EPIRUS_HOTSTART === '1'` ⇒ 它**确实热启动了**；
   *   而 `recipe.env.EPIRUS_SEEDPACK` 是**空的** ⇒ 走 `tools/train-3p.mjs:1050` 的默认
   *   （`process.env.EPIRUS_SEEDPACK || 'js/bundled-champion-3p.js'`）= **当时的活槽**。
   *   ⇒ 父 = `slotAt(ts)`（§E368 那张槽位时间轴），接不上就不接。
   * ⚠ **这一级只在"有 HOTSTART 证据"时才生效** ⇒ 冷启动的包永远不会被接上假父（这是本条与"猜"的分界）。
   * 它和 `seedpack` 级的区别：后者**记了路径**、只是核不出权重；前者**连路径都没记**，靠"默认=活槽"+时间轴推。
   * 与 `slot-at-time` 的区别：那一级是"槽位接替边"（SLOT-* 合成节点的链），不是谁生了谁。 */
  let bySlotInfer = '';
  if (!parId && m.recipe && m.recipe.env && String(m.recipe.env.EPIRUS_HOTSTART) === '1') {
    const sp0 = String(m.recipe.env.EPIRUS_SEEDPACK || '');
    const isSlotDefault = !sp0 || /(^|[\\/])bundled-champion-3p\.js$/.test(sp0);
    if (isSlotDefault) { const alt = slotAt(m.ts); if (alt && IDTS[alt] && (!m.ts || IDTS[alt] <= m.ts)) bySlotInfer = alt; }
  }
  if (byPath) nSpk++; if (byArm) nArm++;
  /* §E555：路径级父指针能不能升到"权重身份可核"，只由这道比较决定（相等才算，读不到/不等一律留在 seedpack）。
   * §E593：**升到实线有两条来路，必须分开标**（原来的写法把它藏进 `seedpack-wid`，于是页面上"时间轴那台机器
   *   真的在用吗"这条腿失去了观测点）：
   *     · `seedpack-wid` = 子包点名的那份**文件此刻的权重** == 父节点在册权重（文件还在，内容就是当时那份）；
   *     · `slot-wid`    = 子包点名的是**活槽路径**，权重要按子包 ts 问完整时间轴（当时那一段住的是谁）才对得上。
   *   两条的**升等条件同一把尺**（逐位相等的权重），只是"那份权重从哪儿读"不同。 */
  const spWid = !!byPath && seedpackVerified(m, byPath, m.ts);
  const spSlot = !!byPath && /(^|[\\/])bundled-champion-3p\.js$/.test(seedpackFile(m) || '');
  if (byPath) { if (spWid) { nSpkWid++; if (spSlot) nSlotWid++; } else nSpkLoose++; }
  /* ===== §E487 融合粒（`tools/soup-pack.mjs` 的产物）：它**天生有两个父** =====
   *   `meta.soup.sources` 是工具自己写进去的实录（每粒来源的 路径 + wid + ts），不是推断 ⇒
   *   第一父走正常的 `parentOf`，第二父走新列 `parentOf2`，图上用**另一种颜色的边**画第二条。
   *   解析只走 wid → 图上节点（`BYWID` / 第二身份 `BYWID_EMB`），**不猜路径、不猜臂名**；
   *   并且吃同一条 §E367 时间闸：父的 ts 晚于子 ⇒ 这条边不许画（融合粒正常总是后生的，红了就说明表错了）。*/
  let sP1 = '', sP2 = '';
  { const src = (m.soup && Array.isArray(m.soup.sources)) ? m.soup.sources : null;
    if (src && src.length) { nSoupDeclared++; SOUPDECL.push(r.id); }
    if (src) { const ids = src.map(s => (s && s.wid && (BYWID[s.wid] || BYWID_EMB[s.wid])) || '');
      sP1 = ids[0] || ''; sP2 = ids.slice(1).find(x => x && x !== sP1) || '';
      const bad = [];
      if (sP1 && IDTS[sP1] && m.ts && Date.parse(IDTS[sP1]) > Date.parse(m.ts)) bad.push(sP1);
      if (sP2 && IDTS[sP2] && m.ts && Date.parse(IDTS[sP2]) > Date.parse(m.ts)) bad.push(sP2);
      if (bad.length) { console.error('⛔ §E487 融合粒 ' + r.id + ' 的父边时间倒挂（' + bad.join(' ‖ ') +
          ' 的 ts 晚于本枚 ' + m.ts + '）⇒ 融合表或 wid 注册错了，不许画成血统'); process.exit(2); }
      if (sP1 && !sP2) console.log('⚠ §E487 ' + r.id + ' 只解析出 1 个父（' + sP1 + '）⇒ 另一粒来源不在图上（融合面板里没登记？）'); } }
  const eco = (m.ecoEffective && typeof m.ecoEffective === 'object') ? m.ecoEffective : {};
  const fig = (m.fightEffective && typeof m.fightEffective === 'object') ? m.fightEffective : {};
  const cfg = { divW: norm(eco.divW), divK: norm(eco.divK), divRoleW: norm(eco.divRoleW), divCatW: norm(eco.divCatW),
    stockBonus: norm(eco.stockBonus), hoardPen: norm(eco.hoardPen), eTarget: norm(eco.target), eCap: norm(eco.cap),
    dealW: norm(fig.dealW), firstW: norm(fig.firstW), whistlePen: norm(fig.whistlePen), styleW: norm(m.styleW),
    oppsN: norm(Array.isArray(m.opps) ? m.opps.length : (typeof m.opps === 'string' && m.opps ? m.opps.split(',').filter(Boolean).length : '')),
    seedEmb: norm(m.seedEmbeddedFrom), gens: norm(m.gens), mode: norm(m.mode), rulesFp: norm(m.rulesFingerprint),
    parent: norm(m.hotstartFrom || WIDOF[byPath || byArm || bySlot] || '') };
  /* ===== §E607 「没有父」与「父找不到」必须在**表里**就分开（用户 10-15 00:3x：「把图上无父节点和父节点不可考分别标注出来」）=====
   *   病：这一列原来只描述"边是从哪儿解析出来的"，**解析不出就一律空串** ⇒ 三种完全不同的事长成一个样：
   *     ① 真包**冷启动**（包里连 `EPIRUS_HOTSTART` 都没有 ⇒ 它本来就没有父，不是漏记）
   *     ② 有热启动证据却解不出（那才是"父不可考"，是要去补证据的那一类）
   *     ③ `SLOT-*` 合成锚点（它根本不是包，是"当时槽里那枚、盘上没留档"的占位）
   *   ⇒ 补两个值：`cold` / `unresolved`，合成节点给 `synthetic`。边本身一条都不因此多画或少画（这些都还是没有父边的行），
   *     变的只是"页面能不能说清楚为什么没有"。 */
  const HASPAR = !!(byHash || byPath || byArm || bySlot || bySlotInfer || sP1);
  const ENVX = (m.recipe && m.recipe.env) || {};
  let ps = byHash ? (byHashEmb ? 'hash-emb' : 'hash') : (byPath ? (spWid ? (spSlot ? 'slot-wid' : 'seedpack-wid') : 'seedpack') : (byArm ? 'arm' : (bySlot ? 'slot-at-time' : (bySlotInfer ? 'slot-infer' : (sP1 ? 'soup' : (demoted ? 'demoted' : ''))))));
  if (!ps && !HASPAR && !demoted) {
    const noEvidence = !m.hotstartFrom && String(ENVX.EPIRUS_HOTSTART || '') !== '1' && !seedpackFile(m);
    ps = (/^SLOT-/.test(r.id) || !Object.keys(m).length) ? 'synthetic' : (noEvidence ? 'cold' : 'unresolved');
    if (ps === 'cold') nCold++; else if (ps === 'unresolved') nUnres++; else nSynthP++; }
  const TSVAL = m.ts || TSFIX[r.id] || '';
  if (!m.ts && TSFIX[r.id]) nTsFix++;
  ROWS.push({ id: r.id, ts: TSVAL, seed: m.seed, cfg, sig: AXES.map(k => k + '=' + cfg[k]).join('|'),
    parentOf: byHash || byPath || byArm || bySlot || bySlotInfer || sP1, wid: r.wid || '',
    psrc: ps,
    pof2: sP2, psrc2: sP2 ? 'soup' : '',
    demoted: demoted,
    branch: BRANCH.map(k => k + '=' + cfg[k]).join('|') }); }
const nres = ROWS.filter(r => r.parentOf).length, np = ROWS.filter(r => r.cfg.parent !== '-').length;
/* §E613 补录 ts 报数 + **孤点父边探测器**：一条有父的边只要有一端没有时间，查看器就把它静默丢掉（见上面补录表的注）。
 *   这条不是"顺手打印"：它是今晚那条病的牙 —— 以前生成器解出 parentOf 就完事，**画不画得出来没人管**。 */
const TSBY2 = {}; for (const r of ROWS) TSBY2[r.id] = r.ts;
const ORPH = ROWS.filter(r => r.parentOf && (!r.ts || !TSBY2[r.parentOf]));
console.log('§E613 ts 来自补录表（包内没自报）：' + nTsFix + ' 枚 ‖ 有父边但两端任一无 ts（⇒ 查看器画不出这条边）：' + ORPH.length + ' 条'
  + (ORPH.length ? ' ⛔ ' + ORPH.map(r => r.id + '→' + r.parentOf + (r.ts ? '（父无 ts）' : '（本枚无 ts）')).join(' ‖ ') : ''));
if (ORPH.length) process.exitCode = 1;
console.log('槽位推断级父边（2026-10-12：包里有 EPIRUS_HOTSTART=1 的证据 + 槽位时间轴）：' +
  ROWS.filter(r => r.psrc === 'slot-infer').length + ' 条');
/* §E607 三种"没有父边"分开报数（页面要说清"为什么没有"，靠的就是这一列） */
console.log('§E607 无父边的 ' + (nCold + nUnres + nSynthP) + ' 枚拆开：冷启动（包里连热启动证据都没有）' + nCold +
  ' ‖ 有证据却解不出（真·父不可考）' + nUnres + ' ‖ SLOT-* 合成锚点 ' + nSynthP + ' ⇒ parentSrc 分别记 cold / unresolved / synthetic');
/* ===== §E464 钉子：第二身份必须**真的登记成功**，不能只看"今天这张表解得开" =====
 *   为什么不能只验结果：BYWID 优先级高于 BYWID_EMB，而本机恰好有 e370-out 那批**未入库**的 v7 导出 ⇒
 *   两条路同时在，表看不出区别。实测就是这么漏的：`embedLegacy()` 返回 Float64Array、`widOfArr` 当时只收 Array ⇒
 *   第二身份登记 0 条、整条 durable 路自写下就空转过（页面自测照样绿，因为它读的是已生成好的表）。
 *   ⇒ 判据钉的是"durable 那条路本身通不通"：凡是被当父用的旧槽位冠军，都要能从**已入库的 v6 文件**推出第二身份。*/
{ const useSlot = {}, embTo = {};
  for (const r of ROWS) if (/^SLOT-/.test(r.parentOf || '')) useSlot[r.parentOf] = (useSlot[r.parentOf] || 0) + 1;
  for (const k in BYWID_EMB) embTo[BYWID_EMB[k]] = (embTo[BYWID_EMB[k]] || 0) + 1;
  const bad = Object.keys(useSlot).filter(id => !embTo[id]);
  console.log('§E464 钉：被当父用的旧槽位冠军 ' + Object.keys(useSlot).length + ' 枚（合计 '
    + Object.keys(useSlot).reduce((a, k) => a + useSlot[k], 0) + ' 条父边）‖ 第二身份能从已入库文件推出的 '
    + (Object.keys(useSlot).length - bad.length) + ' 枚 ‖ 全靠嵌入解开的边 ' + nEmb + ' 条');
  if (bad.length) { console.error('⛔ §E464 这些旧槽位冠军只剩「未入库的 v7 导出」一条路 ⇒ 换台机器 clone 下来这些父边会全断：'
    + bad.map(id => id + '(' + useSlot[id] + ' 条边)').join(' ') + '\n   先查 embedLegacy 的返回值是不是 array-like、widOfArr 收不收');
    process.exit(2); } }
/* §E367 + §E368：被"路径今天住的是谁"骗出来的父边，逐枚点名它**改接到了谁**（不点名就等于悄悄改了数据）*/
console.log('⭐ §E367/§E368 时间倒挂的**推断级**父指针：按槽位时间轴改接 '
  + ROWS.filter(r => r.psrc === 'slot-at-time').length + ' 枚 ‖ 接不回来、退回"不可考" ' + ROWS.filter(r => r.demoted).length + ' 枚');
for (const r of ROWS) if (r.psrc === 'slot-at-time' || r.demoted)
  console.log('   ' + r.id + ' @' + r.ts + '  原解析=' + (r.demoted || '(见下行)') + ' ⇒ 现父=' + (r.parentOf || '不可考')
    + '（其 ts=' + (IDTS[r.parentOf] || '—') + '）');
console.log('父指针：' + np + ' 枚记了 hotstartFrom ‖ 其中 ' + nres + ' 枚能解析到**具体哪一枚**（' +
  (np ? Math.round(nres / np * 100) : 0) + '%）‖ 解析不出的多是"父是当时的现役冠军、后来被覆写没留档"');
console.log('　§E330 退路解析出的：SEEDPACK 路径 ' + nSpk + ' 枚 ‖ 臂级（同臂带内候选留的指针）' + nArm + ' 枚（这些的产物自己不带任何指针）');
/* §E555：路径级父指针里"权重身份可核"的那部分单独报数 —— 它决定图上画实线还是虚线，所以必须看得见是多少枚 */
console.log('　§E555 SEEDPACK 那 ' + nSpk + ' 枚里：**种子文件的权重指纹 == 图上节点的指纹**（可升到实线）' + nSpkWid +
  ' 枚 ‖ 只按名字对上、身份核不了（保持虚线）' + nSpkLoose + ' 枚');
/* §E593：走**活槽路径**的那一支单独报数 —— 它的"身份可核"问的是**当时那一段的实录权重**（完整时间轴），
 *   不是"今天那格文件里装的是谁"（后者正是 §E367 那个病）。时间轴没追到今天时它是 0，且上面那行会响亮印出来。 */
console.log('　§E593 其中点名**现役槽位路径**（`js/bundled-champion-3p.js`）的 ' + nSlotEra +
  ' 枚：父 = 子包 ts 落在的那一段槽主（问 slot-timeline.tsv 完整时间轴，不读今天那格文件）'
  + ' ‖ 这 ' + nSlotEra + ' 枚里有 ' + nSlotWid + ' 枚权重对上了、升到 **`slot-wid`**（实线，与 `seedpack-wid` 同一把尺、不同来路）');
const bySig = new Map();
/* ===== §E466 旧槽位冠军**不参与家族聚类**（用户 10-08 指着图问"怎么有几个后期的点飞到家族 1 去了"）=====
 *   它们不是一次训练产物，是"当时上槽的那枚权重"（16 行的 META 来自 e370-out 的导出，配置字段多半是空的）。
 *   实测混进来的两处代价：
 *   ① SLOT-6ed47e18（ts 09-09）的 16 轴签名与 E59 那批和 BIG 三枚"配置字段全空"的类**逐字相同** ⇒ 被并成一类，
 *      而这一类的 t0 被它拖到 09-09 ⇒ 按 t0 排序时整类排到第 2 行 ⇒ 09-27 / 10-02 的 12 枚显示在"最早那一批"那一行。
 *   ② 另外 15 枚并进"零散实验"，那一行的枚数里有 15 枚根本不是训练产物。
 *   ⇒ 家族号只描述训练家族。这 16 枚**仍然写进表**（584 条父边要以它们为靶），但 fam 一律给 0，
 *      显示交给 viewer 那一行合成家族（§E376 补行 / §E377 放最上面）。 */
const SLOTID = {}; for (const r of ROWS) if (/^SLOT-/.test(r.id)) SLOTID[r.id] = 1;
/* ===== §E490 融合家族单开一行（用户 10-08 17:0x：「融合以及融合后训练单独开一个家族吧」）=====
 *   原来这三枚被并进「零散实验（<6 枚的类合并）」，而那一行是给"训练配置各不相同的散枚"兜底的 ——
 *   融合粒**没有训练配置**（它是两枚的权重平均，meta 里 `mode/n/pop/games` 天生是空的），
 *   并进去等于让图上把"方法根本不同"读成"方法一样"。
 *   成员规则两条，一起算完再**从训练聚类里摘出去**（不是事后改 fam —— 那会让「零散实验」的枚数说谎）：
 *     ① `psrc === 'soup'`：融合粒自己（父是从包 meta 的 `soup.sources[].wid` 反查出来的）；
 *     ② 沿 `parentOf` 链能走到融合粒的：从融合粒续训出来的产物。
 *   ② 必须一起挪：续训那一步的配置签名会和它热启动的那一族一样，留在训练家族里就把"同一条研究线"切成两家。 */
const SOUPSET = {}; for (const r of ROWS) if (r.psrc === 'soup') SOUPSET[r.id] = 1;
const BYID = {}; for (const r of ROWS) BYID[r.id] = r;
function fromSoup(id) { for (let g = BYID[id], n = 0; g && n < 40; g = BYID[g.parentOf], n++) if (SOUPSET[g.id]) return true; return false; }
const FUS = ROWS.filter(r => !SLOTID[r.id] && (SOUPSET[r.id] || fromSoup(r.id)));
const FUSID = {}; for (const r of FUS) FUSID[r.id] = 1;
if (FUS.length) console.log('§E490 融合家族摘出来 ' + FUS.length + ' 枚（融合粒 ' + Object.keys(SOUPSET).length +
  ' ‖ 从它续训的 ' + (FUS.length - Object.keys(SOUPSET).length) + '）：' + FUS.map(r => r.id).join(' '));
/* ===== §E554 训练臂按**方法快照**拆家族（用户 10-09 07:2x：「把晚上训练的东西进图」）=====
 * 病（实测出来的，不是设想）：`train-3p` 从 v1.6 起把旋钮写进 `meta.recipe.env`，而上面那 16 根在册轴**一根都不填** ⇒
 *   照轴聚类，今晚 271 枚（其实是"纯续训 / guardSpam 池 / 狙击池+示范 / SEL_EVAL_SEEDS=8 / veto 单自由度…"好几条线）
 *   全落进同一个兜底类（家族 22，283 枚），标签印的是"珠价 divW 0.3→- ‖ 代数 250→400"—— 它们从没碰过 divW。
 *   那样这张图等于没进：用户问"今晚那批在哪"，答案是"和 9 枚 E59 老臂叠在同一行"。
 * 名单**不许住在 gitignored 的产物目录里**（§E503 的教训：干净克隆里融合父边 6→0 而退出码还是 0）⇒
 *   批次表走**入库件** `champion-map/gate-arms-2026-10-09.tsv` 的 `knobs` / `seedpack` 两列；
 *   读不到就**响亮降级**（合回兜底类可以，但不许静默）。 */
const ARMF = join(HERE, (process.argv.find(x => x.indexOf('--arms=') === 0) || '').slice(7) || 'gate-arms-2026-10-09.tsv');
const ARMMETA = {};
if (existsSync(ARMF)) {
  const AL = rd(ARMF).replace(/\n+$/, '').split('\n'), ah = AL[0].split('\t');
  const iId = ah.indexOf('id'), iK = ah.indexOf('knobs'), iS = ah.indexOf('seedpack');
  if (iId < 0 || iK < 0) { console.error('⛔ §E554 臂批次表 ' + ARMF + ' 没有 id/knobs 两列 ⇒ 不敢按它拆家族'); process.exit(2); }
  for (const l of AL.slice(1)) { const c = l.split('\t');
    if (c[iId] && c[iK]) ARMMETA[c[iId]] = { knobs: c[iK], seedpack: c[iS] || '' }; }
} else {
  console.log('⚠ §E554 读不到臂批次表（' + ARMF.replace(ROOT + '/', '') +
    '）⇒ 本次**不拆臂家族**：臂会落回"只按代数分"的兜底类，图上看不出哪一晚哪条线。要完整图别漏这张入库表。');
}
const INROWS = {}; for (const r of ROWS) INROWS[r.id] = 1;
const ARMID = {}; for (const id of Object.keys(ARMMETA)) if (INROWS[id]) ARMID[id] = 1;
const nArmMiss = Object.keys(ARMMETA).filter(id => !INROWS[id]).length;
if (Object.keys(ARMID).length) console.log('§E554 臂批次表读到 ' + Object.keys(ARMMETA).length + ' 枚 ‖ 在图上 ' +
  Object.keys(ARMID).length + ' 枚（不在图上的 ' + nArmMiss + ' 枚是库里对照件，本来就没登记）⇒ 按 knobs+父 拆臂家族');
for (const r of ROWS) { if (SLOTID[r.id] || FUSID[r.id] || ARMID[r.id]) continue; if (!bySig.has(r.sig)) bySig.set(r.sig, []); bySig.get(r.sig).push(r); }
const groups = [...bySig.entries()].map(([sig, rs]) => ({ sig, rs,
  t0: rs.map(x => x.ts).sort()[0] || '', t1: rs.map(x => x.ts).sort().slice(-1)[0] || '' }))
  .sort((a, b) => (a.t0 < b.t0 ? -1 : a.t0 > b.t0 ? 1 : b.rs.length - a.rs.length));
console.log('方法/目标配置等价类 = ' + groups.length + ' 个（成员数中位 ' +
  groups.map(g => g.rs.length).sort((a, b) => a - b)[groups.length >> 1] + '，最大 ' +
  Math.max.apply(null, groups.map(g => g.rs.length)) + '）');   /* 最大要按成员数取，groups 是按 t0 排的 */
/* 类太多就没法上色：按"成员数 ≥ 6 才独立成家，其余并进『零散实验』"收成可画的规模。*/
const BIG = groups.filter(g => g.rs.length >= 6), SMALL = groups.filter(g => g.rs.length < 6);
console.log('成员 ≥6 的类 ' + BIG.length + ' 个（覆盖 ' + BIG.reduce((s, g) => s + g.rs.length, 0) + ' 枚）‖ 并进零散的 ' + SMALL.length + ' 类 / ' + SMALL.reduce((s, g) => s + g.rs.length, 0) + ' 枚');
let i = 0; const FAM = {};
let defs = BIG.map(g => { i++; return { n: i, g, label: '' }; });
if (SMALL.length) defs.push({ n: i + 1, small: 1, g: { sig: null, rs: SMALL.flatMap(s => s.rs) }, label: '零散实验（<6 枚的类合并）' });
for (const d of defs) for (const r of d.g.rs) FAM[r.id] = d;
/* 标签：说清"这一家相对上一家改了什么"，而不是把 16 个轴念一遍。*/
const CH = { divW: '珠价 divW', divK: 'divK', divRoleW: '角色多样性权', divCatW: '类别多样性权', stockBonus: '囤珠奖励',
  hoardPen: '囤珠惩罚', eTarget: '经济目标', eCap: '经济上限', dealW: '输出权重', firstW: '先手权重',
  whistlePen: '吹哨惩罚', styleW: '风格权重', oppsN: '对手池', seedEmb: '嵌入种子自', gens: '代数', mode: '桌形',
  rulesFp: '规则指纹', parent: '热启动父' };
let prev = null;
for (const d of defs) { const c = d.g.rs[0].cfg;
  const diff = [];
  if (prev) { for (const k of AXES) if (prev[k] !== c[k]) diff.push(CH[k] + ' ' + prev[k] + '→' + c[k]); }
  else { for (const k of ['divW', 'oppsN']) diff.push(CH[k] + '=' + c[k]); }
  const br = [...new Set(d.g.rs.map(r => r.cfg.parent.slice(0, 8)))];
  d.label = (d.g.sig === null ? '零散实验（<6 枚的类合并）'
    : (diff.length ? diff.join(' · ') : '同上（同配置续跑）')) +
    ' ‖ ' + String(d.g.rs.length) + ' 枚 ‖ ' + String(d.g.t0).slice(5, 10) + '→' + String(d.g.t1).slice(5, 10) +
    ' ‖ 父 ' + br.join(',');
  prev = c; }
/* §E490 融合那一行**追加在 defs 末尾**（家族号 = 现有最大 +1）：它的成员不是"某次训练的等价类"，
 *   通用标签那套（拿 16 个轴与上一家做差）对它没有意义 ⇒ 标签自己写，且明说"这不是训练家族"。
 *   放在末尾而不是像旧槽位冠军那样放家族 0：那一行是"横轴换一把钟"的特例，而这一行的横轴与其它行**同一把钟**
 *   （ts = 写盘时刻），只是方法不同 ⇒ 按"上→下即时间推进"的既有读法，最新的这条研究线就该在最下面。 */
if (FUS.length) {
  const n = Math.max.apply(null, defs.map(x => x.n).concat([0])) + 1;
  const t0 = FUS.map(r => (r.ts || '').slice(0, 10)).sort()[0] || '';
  const t1 = FUS.map(r => (r.ts || '').slice(0, 10)).sort().slice(-1)[0] || '';
  const pr = [...new Set(FUS.map(r => [r.parentOf, r.pof2].filter(Boolean).join('+')).filter(Boolean))];
  const d = { n, g: { sig: 'soup', rs: FUS, t0, t1 },
    label: '融合（权重平均）与它的续训 ‖ ' + FUS.length + ' 枚 ‖ ' + t0.slice(5) + '→' + t1.slice(5) +
      ' ‖ 父 ' + (pr.join(' · ') || '不可考') + ' ‖ 不是训练家族：两粒父的权重平均（tools/soup-pack.mjs）' };
  defs.push(d); for (const r of FUS) FAM[r.id] = d;
  console.log('§E490 已开融合家族 号=' + n + '（' + FUS.length + ' 枚 ‖ 标签「' + d.label + '」）'); }
/* ===== §E554 训练臂的**臂线家族**（追加在融合那一行之后 ⇒ 家族号只往后加，不动任何在册枚的号）=====
 *   为什么必须追加而不是插进去：CHANGELOG v1.6.32 与 10-07/10-08 日志都点名"**融合家族 25**"，
 *   把新行排在它前面就会让历史账面指向另一族（25 变成 146 枚的纯续训臂）⇒ 家族号是**身份**，不是排版。
 *   成员规则来自批次表的 `knobs`（`meta.recipe.env` 剔掉逐枚身份键 ARM/SEED/BAND_DIR/T3P_OUT）+ 热启动父；
 *   ≥6 枚独立成行，<6 枚并成"臂线·零散"（与「零散实验」同一口径，但**不混进那一行** —— 那一行是"配置各不相同的老散枚"）。
 *   标签里必须写清"这不是那 16 根轴"，否则读图的人会把 `HOTSTART=1` 当成一次配置改动。 */
{ const byArm = new Map();
  for (const r of ROWS) { const m = ARMMETA[r.id]; if (!m || !ARMID[r.id]) continue;
    const s = 'env:' + m.knobs + '#parent=' + m.seedpack;
    if (!byArm.has(s)) byArm.set(s, []); byArm.get(s).push(r); }
  const ag = [...byArm.entries()].map(([s, rs]) => ({ s, rs,
    t0: rs.map(x => x.ts).sort()[0] || '', t1: rs.map(x => x.ts).sort().slice(-1)[0] || '' }))
    /* 排序键是 **t0**，不是枚数：这张图"上→下即时间推进"是既有的读法，而页内自检那条"家族行序"腿就是钉这条的
     *   （第一版按枚数排 ⇒ guardSpam 那行(52 枚)排在狙击池那行(42 枚)下面，而它的训出时刻更早 ⇒ 当场红一条序违规）。
     *   同 t0 再按枚数多的在上， purely 为了让同一天的几条线有个稳定次序。 */
    .sort((a, b) => (a.t0 < b.t0 ? -1 : a.t0 > b.t0 ? 1 : b.rs.length - a.rs.length));
  const big = ag.filter(g => g.rs.length >= 6), small = ag.filter(g => g.rs.length < 6);
  let an = Math.max.apply(null, defs.map(x => x.n).concat([0]));
  const lab = g => { const k = g.s.replace(/^env:/, '').replace(/#parent=.*$/, '');
    const short = k.split(' · ').filter(x => !/^(HOTSTART|SEEDPACK)=/.test(x));
    return '臂线 ' + (short.join(' · ') || '无额外旋钮（纯续训）') + ' ‖ ' + g.rs.length + ' 枚 ‖ ' +
      String(g.t0).slice(5, 10) + '→' + String(g.t1).slice(5, 10) + ' ‖ 父 ' + (g.s.split('#parent=')[1] || '不可考') +
      ' ‖ 配方差异在 meta.recipe.env，不在那 16 根在册轴上（§E554）'; };
  /* 零散那一行也参加 t0 排序（它是几个小类的合并，t0 取成员里最早的）⇒ 否则"追加在最后"照样会踩行序那条腿 */
  const all = big.slice();
  if (small.length) { const rs = small.flatMap(g => g.rs);
    all.push({ s: '零散#' + small.map(g => g.s.split('#parent=')[1] || '').join(','), rs, merged: small.length,
      t0: rs.map(x => x.ts).sort()[0] || '', t1: rs.map(x => x.ts).sort().slice(-1)[0] || '' }); }
  all.sort((a, b) => (a.t0 < b.t0 ? -1 : a.t0 > b.t0 ? 1 : b.rs.length - a.rs.length));
  for (const g of all) {
    const d = { n: ++an, small: g.merged ? 2 : 0, g: { sig: g.merged ? null : g.s, rs: g.rs, t0: g.t0, t1: g.t1 },
      label: g.merged ? ('臂线·零散（<6 枚的旋钮类合并） ‖ ' + g.rs.length + ' 枚 ‖ ' +
        String(g.t0).slice(5, 10) + '→' + String(g.t1).slice(5, 10) + ' ‖ ' + g.merged +
        ' 个旋钮类（veto 单自由度、示范锚那一族）') : lab(g) };
    defs.push(d); for (const r of g.rs) FAM[r.id] = d; }
  console.log('§E554 臂家族：≥6 枚的线 ' + big.length + ' 个（覆盖 ' + big.reduce((s, g) => s + g.rs.length, 0) + ' 枚 ‖ ' +
    big.map(g => g.rs.length + ' 枚').join(' ‖ ') + '） ‖ 零散 ' + small.reduce((s, g) => s + g.rs.length, 0) +
    ' 枚 / ' + small.length + ' 个类 ‖ 家族号追加到 ' + an + '（在册各行的号一个没动）'); }
/* ===== 10-21 用户：家族太多颜色难分 ⇒ 合并历史步进与零散桶（号保留最小号，不重排 22/23/25）===== */
if (DUMPDEFS) {
  console.log('--dumpdefs ‖ 合并表生效**之前**的家族表（号 = 此刻的 d.n，下面那张表以前点的就是这些号）');
  for (const d of defs) console.log('DEF ' + d.n + ' ‖ t0=' + String(d.g.t0).slice(0, 10) + ' ‖ n=' + d.g.rs.length +
    ' ‖ ' + d.g.rs.map(r => r.id).join(' '));
  process.exit(0);
}
/* ===== v1.8.34（10-24）：这张表从「按号点家族」改成「按**锚枚 id** 点家族」=====
 *   为什么必须改（`8e39c13e` 实测，用户看图抓到"点飞到天上去了"）：号来自上面那次"按 t0 排 + ≥6 独立成家"的
 *   原始聚类 ⇒ **往表里加几枚新点就能让整段号往后挪**。这一次加的 6 枚激光眼与 E1/E2 那 4 枚同签名，
 *   把那一类从 4 枚推过「≥6」那条线 ⇒ 零散桶 24→25、融合 25→26、臂线整段 +1，于是
 *     · `relabel(25,'融合与续训')` 压在「零散实验」那一桶上（40 枚、**一枚 SOUP 都没有**），
 *     · 真融合那 6 枚被 `relabel(26)` 改名成"臂线·env 实验"，
 *     · 「旧生产对照」那一行整个消失（seed80 / e35prod 这批 09-25 的点跑到最上面那一行 = 用户看到的那一幕）。
 *   后果是 **333/807 枚的家族号被无声换掉**，而 280 条门与页内 96 条自检全绿 —— 因为没有任何一条判
 *   "这张表点的还是不是当初那个家族"。锚枚 id 的签名不会变 ⇒ **号会变、锚不会**；锚找不到就 exit 2 点名。
 *   ⚠ 换/加锚之前先跑 `node champion-map/lineage.mjs --dumpdefs` 看清此刻的原始聚类，别照旧表猜号。 */
function defOf(anchor, why) {
  const d = FAM[anchor];
  if (!d) { console.error('⛔ v1.8.34 家族表的锚枚 `' + anchor + '`（' + why + '）在聚类里找不到 ⇒ 这一行点不到家族，不敢猜。\n'
    + '   先看此刻原始聚类长什么样：node champion-map/lineage.mjs --dumpdefs'); process.exit(2); }
  return d;
}
function touch(d) { d.g.t0 = d.g.rs.map(r => r.ts).sort()[0] || ''; d.g.t1 = d.g.rs.map(r => r.ts).sort().slice(-1)[0] || ''; }
/* 点名把若干枚搬成**单独一行**（与 §E490 摘融合、§E466 摘旧槽位冠军同一套路，只是主语换成一份 id 名单）。 */
function carve(ids, label) {
  const rs = [];
  for (const id of ids) {
    const d = defOf(id, '点名家族「' + label + '」');
    const hit = d.g.rs.filter(x => x.id === id);
    if (hit.length !== 1) { console.error('⛔ 锚枚 `' + id + '` 在它自己的家族里查到 ' + hit.length + ' 行 ⇒ 聚类结构变了，不敢猜'); process.exit(2); }
    d.g.rs = d.g.rs.filter(x => x.id !== id);
    rs.push(hit[0]); FAM[id] = null;
  }
  for (const d of defs) touch(d);
  defs = defs.filter(d => d.g.rs.length);
  const t0 = rs.map(r => r.ts).sort()[0] || '', t1 = rs.map(r => r.ts).sort().slice(-1)[0] || '';
  const d = { n: -1, g: { sig: 'named:' + label, rs: rs, t0: t0, t1: t1 },
    label: label + ' ‖ ' + rs.length + ' 枚 ‖ ' + String(t0).slice(5, 10) + '→' + String(t1).slice(5, 10) };
  defs.push(d); for (const r of rs) FAM[r.id] = d;
  console.log('v1.8.34 点名成行：' + rs.length + ' 枚 → 「' + d.label + '」');
  return d;
}
/* 把若干枚搬进锚枚所在那一行（10-23 那份账面的位置）。 */
function moveTo(ids, anchor) {
  const kd = defOf(anchor, '搬入目标');
  let n = 0;
  for (const id of ids) { const d = defOf(id, '待搬枚');
    if (d === kd) continue;
    const hit = d.g.rs.filter(x => x.id === id);
    if (hit.length !== 1) { console.error('⛔ 待搬枚 `' + id + '` 查到 ' + hit.length + ' 行 ⇒ 不敢猜'); process.exit(2); }
    d.g.rs = d.g.rs.filter(x => x.id !== id);
    kd.g.rs.push(hit[0]); FAM[id] = kd; n++; }
  for (const d of defs) touch(d);
  defs = defs.filter(d => d.g.rs.length);
  console.log('v1.8.34 搬回在册那一行：' + n + ' 枚 → 「' + kd.label + '」');
}
/* ===== 10-24（用户：「激光眼线如果搞出了有用的冠军，就把这一条训练链里有用的几个点都放到演化图里面」）=====
 *   这 6 枚是**一条链**（g12→g14→g15→g16→g17→g18，逐枚热启动上一枚），不是"某个配置等价类里的一撮"：
 *   留在签名聚类里它会和 E1/E2 那 4 枚并成一行（16 根在册轴全空 ⇒ 签名相同），而那一行读不出链条。 */
/* ===== 10-25（用户：「你把这一批放在激光眼家族」）：把这一轮训出来的四粒也挂进同一条线 =====
 *   `night-A0-77001` 是 null 臂（只有热启动，没开教师也没开判据桌）‖ `night-T1-77002` 只有教师 ‖
 *   `night-T3-77000` / `night-T3-77002` 是教师 + 判据桌（`COUNTER_OPPS=guardSpam` + `SEL_COUNTER=1`）。
 *   它们与 g12→g18 那 6 枚**同一条研究线**（都是为了"激光眼/抗龟"这一维而训），所以并进同一个点名家族，
 *   而不是让签名聚类把它们和 E1/E2 那批零散臂混成一行（16 根在册轴全空 ⇒ 签名相同）。
 *   父边来自各自 meta 里的 `EPIRUS_SEEDPACK`；种子包住在 gitignored 的目录时父边解析不出 ⇒ 只少一条边，
 *   ts / 家族归属不受影响（下面那段会响亮印"解析不出父"的枚数）。 */
carve(['g12-keep-77000', 'g14-h2-77001', 'g15-long-77001', 'g16-77001', 'g17-77000', 'g18-77001',
  'night-A0-77001', 'night-T1-77002', 'night-T3-77000', 'night-T3-77002',
  /* ===== 10-26 夜班（用户：「这两个都入库」）：ZCode 的冷启批两粒 =====
   *   `D1-77000` = **第一粒 ε=0 原生打激光眼的包**（240 局 9 手 6 落 = 0.0375 次/局），破零杠杆 = `IMIT_ONLY` 里加上 `charge`；
   *   `C2-77000` = 同批只差那一维（示范只 laserEye）⇒ 种群 239/208 代有原生手、末代被选掉，是"动作活着但没被选上"那一格的代表。
   *   两粒都是**冷启**（meta 里没有 hotstartFrom/SEEDPACK ⇒ 父边天然为空，图上就是这条链的两个新梢，不硬造父）。 */
  'D1-77000', 'C2-77000',
  /* ===== 10-26 夜班第二场（§E765/§E767/§E772）：`BEAD_BOOM_W` 破密批的两粒 =====
   *   `N2-77000` = 第一粒把激光眼买到**每席每局 0.96 手**的冷启包（ε=0 镜像 574/1229 出手），代价是当年那句"广度塌"（后来被 §E765 五 撤回）；
   *   `Q4-77000` = **热启 `N2` + `SEL_KEEP=0.7`** 的产物 ⇒ 它的 `meta.hotstartFrom` 就是 `N2` 的权重哈希，
   *     所以这一对是**图上第一条能按 wid 连成实线的"训练变化"父子边**（用户 10-26 00:3x 要的那根追溯链，最直的演示就是它）。
   *   `Q4` 也是这条线证据最全的一粒：1.418/1.463 次/局/席 ‖ G 出手 7.83/6.89 ‖ 技能报告消融轴 +5.3pt「承重」；
   *   但它**不是候选**（1st 48.0% ‖ G4/G5 四格红 ‖ 取严 rc=6）⇒ 入库只为图上看得见，不进池。 */
  'N2-77000', 'Q4-77000',
  /* ===== 10-26 06:4x（§E778/§E779）：`U2-77001` = 今晚**第一条完整达成 §E763 四条判据**的一粒 =====
   *   热启 `N2` + `SEL_KEEP=0.5`（比 `S1` 只紧一档）⇒ 取严 rc=0 ‖ G4 27.3/17.0 ‖ G5 13/7 四格全过 ‖ 密度 1.232/1.780 ‖ 1st 对起点 +0.5pt。
   *   父边同 `Q4` 一样按权重哈希解析 ⇒ 图上现在是 `N2` 分出 `Q4` 与 `U2` 两条实线（同一父代、两种当选档）。 */
  'U2-77001',
  /* ===== 10-27 晚（用户：「这几个新点应该放到家族13」）：`RC1` 的两个子代 =====
   *   `V9-77001` = `RC1` + 珠两档（珠闭环：浪费 0.86→0.17、花珠率 0.83）；`RW2-77001` = `RC1` + `BEAD_WASTE_W=.5`（12/13，缺 G5）。
   *   它们与 `U2`/`N2` 同一条激光线（都是为了激光眼/珠这一维而训）⇒ 并进同一个点名家族。 */
  'V9-77001', 'RW2-77001', 'RC1-77001'],
  '激光眼线（g12→g18 · 教师/判据桌 · 冷启破零 · 破密 · 珠闭环）');
/* E1/E2 那 4 枚搬回 10-23 在册那一行（标签里本来就写着"+ E1/E2 研究臂"）：上面那个点名家族（10-24 那 6 枚，10-25 起 10 枚，10-26 起 12 枚）与它们同签名，
 *   把这一类推过「≥6」⇒ 它们不再落零散桶，于是下面那段"零散按年代搬进具体家族"这一次**不会**再捞到它们。 */
moveTo(['e1-teach-77003', 'e1-ctl-77000', 'e2-grad-77002', 'e2-teach-77000'], 'R-s107');
function mergeDefs(keepAnchor, dropAnchors, label) {
  const kd = defOf(keepAnchor, '合并 keep');
  const ds = [];
  for (const a of dropAnchors) { const d = defOf(a, '合并 drop');
    /* 2026-10-24（ZCode · 修 CI 红 D233）：本机（数据全）撞这条 = 合并表过期，照旧 exit 2。
     * 但**干净克隆**上签名轴退化（在册轴全空 ⇒ 大类并拢）会让好名单也撞这里，且先于 §E503 薄图分支 ⇒
     * 带 `--soup-thin-ok`（= 承认这台机器就是要一张薄图）时降级为**响亮警告 + 跳过这一条**：
     * d === kd 本身说明两族已被聚类并成一家，跳过的只是"再并一次"的空操作，语义无损；默认口径一字不动。 */
    if (d === kd) {
      if (process.argv.includes('--soup-thin-ok')) {
        console.log('⚠ §E503 薄图模式（`--soup-thin-ok`）：合并表把 `' + keepAnchor + '` 与 `' + a +
          '` 当成两个家族，而退化聚类已把它们并成同一个（' + kd.label + '）⇒ 这一条按"已并"跳过（默认口径在此仍 exit 2）');
        continue;
      }
      console.error('⛔ 合并表把 `' + keepAnchor + '` 与 `' + a + '` 当成两个家族，而它们此刻已是同一个（' + kd.label + '）⇒ 名单要更新，不敢静默跳过'); process.exit(2);
    }    ds.push(d); }
  if (!ds.length) return;
  const rs = kd.g.rs.concat(...ds.map(d => d.g.rs));
  kd.g = { sig: kd.g.sig, rs: rs, t0: '', t1: '' }; touch(kd);
  kd.label = label + ' ‖ ' + rs.length + ' 枚 ‖ ' + String(kd.g.t0).slice(5, 10) + '→' + String(kd.g.t1).slice(5, 10);
  for (const r of rs) FAM[r.id] = kd;
  defs = defs.filter(d => !ds.includes(d));
}
mergeDefs('mix-31', ['sty-31', 'eco-31', 'def-31', 'fstA-31'], '历史配方步进 A（09-12～09-13：珠价/风格/对手池）');
mergeDefs('v7a-31', ['v11-61'], '对手池步进 B1（09-13：对手池 1→77）');
mergeDefs('v7attr-31', ['v12-81', 'v7f2-31', 'v7f2b-31'], '珠价/代数步进 B2（09-13～09-16：珠价/代数/对手池）');
mergeDefs('v7curri1-31', ['v7role5-31', 'v7role1-31', 'v7clear2-31'], '多样性步进 C1（09-16：多样性 5→30）');
mergeDefs('v7w3r1-31', ['v7fix1-31', 'v7l2a-81'], '对手池步进 C2（09-16～09-18：对手池 16/19）');
mergeDefs('r61fix-31', ['v7aim1-31', 'v7aim2-31'], '对手池/珠价步进 C3（09-19～09-21：对手池 14→22）');
/* 10-21 用户：零散别再单列一个最早桶（线会先飞上去再下来）⇒ 按各自训练配置/年代并进具体家族。
 *   v1.8.34：这两只桶原来按号点（24 / 27），现在按**创建时打的 `small` 标**点 ⇒ 加多少枚都不会捞错。 */
{
  const src = defs.filter(d => d.small);
  const prod = [];
  for (const d of src) for (const r of d.g.rs) {
    const t = String(r.ts).slice(0, 10);
    let tgt = null;
    if (r.id === 'long-33' || t <= '2026-09-14') tgt = defOf('v7attr-31', '零散→B2');           /* B2 */
    else if (t <= '2026-09-18') tgt = defOf('v7w3r1-31', '零散→C2');                             /* C2 */
    else if (t >= '2026-09-24' && t <= '2026-09-27') { prod.push(r); continue; }                 /* 旧生产对照 */
    else tgt = defOf('R-s107', '零散→臂线');                                                     /* 臂线 */
    /* 2026-10-24（ZCode · 修 CI 红 D233 续）：干净克隆上退化聚类可能把目标锚也落进 small 桶 ⇒
     * tgt === d（正在迭代的那只）⇒ 往活迭代器里 push 自己，数组长到 2^32 抛 RangeError（修前这就是
     * "过了 exit-2 之后死在写表前"的真凶）。目标即当前桶 ⇒ 行已在桶里，只改 FAM 归属、不 push。 */
    if (tgt && tgt !== d) { tgt.g.rs.push(r); FAM[r.id] = tgt; }
    else if (tgt && tgt === d) { FAM[r.id] = tgt; }
  }
  if (prod.length) {
    const d = { n: 90, g: { sig: 'prod-old', rs: prod, t0: '', t1: '' }, label: '' }; touch(d);
    d.label = '旧生产对照（09-25～09-27：e35/e39/seed80/seed81/cal-ctl/E51） ‖ ' + prod.length + ' 枚 ‖ ' + String(d.g.t0).slice(5, 10) + '→' + String(d.g.t1).slice(5, 10);
    defs.push(d); for (const r of prod) FAM[r.id] = d;
  }
  defs = defs.filter(d => !d.small);
  for (const a of ['v7attr-31', 'v7w3r1-31', 'R-s107']) touch(defOf(a, '零散搬入后重算 t0/t1'));
}
/* 臂线两行合一：snipeSpam 那一组（10 枚）与"纯续训/锚点"那一组（27 枚）。
 *   ⚠ 名单里**不含**「臂线·零散」那 9 枚 —— 它们已经由上面那段按年代搬进来了（10-21 那版靠号点，
 *   把 27/28 当成两个原始组；今天按锚枚点，这条被上面那道"两个锚已是同一个家族"的检查挡下来，
 *   所以我按它的提示把名单改短，而不是拿 `⚠ 跳过` 糊过去）。 */
mergeDefs('R-s107', ['P-s22'], '臂线·env 实验（COUNTER_OPPS / 纯续训）');
function relabel(anchor, label) { const d = defOf(anchor, '改名'); const rs = d.g.rs;
  touch(d);
  d.label = label + ' ‖ ' + rs.length + ' 枚 ‖ ' + String(d.g.t0).slice(5, 10) + '→' + String(d.g.t1).slice(5, 10); }
relabel('BIG0', '早期 env 臂（16 轴全空）');
relabel('B0-111', '现代基线（代数 400～1200）');
relabel('SOUP-KE-l60', '融合与续训');
relabel('G-s72', '臂线·COUNTER_OPPS=guardSpam');
relabel('v7attr-31', '珠价/代数步进 B2（09-13～09-16：珠价/代数 + 小类）');
relabel('v7w3r1-31', '对手池步进 C2（09-16～09-18：对手池 16/19 + 小类）');
relabel('R-s107', '臂线·env 实验（COUNTER_OPPS / 纯续训 + T8/snipe 小臂 + E1/E2 研究臂）');
/* 10-21 用户：号从头排、不留空号 ⇒ 按 t0 排序后连续编号 1..N（0 留给旧槽位冠军） */
defs.sort(function (a, b) { return String(a.g.t0 || '').localeCompare(String(b.g.t0 || '')); });
defs.forEach(function (d, i) { d.n = i + 1; });
console.log('10-21 家族合并 → 在册 ' + defs.length + ' 家（连续 1..' + defs.length + '；0=旧槽位冠军）：' + defs.map(d => d.n + ':' + d.g.rs.length).join(' '));
/* §E314 → §E464 更正：这里原来写的「无实体」是**错的**，错的是一台仪器的口径。
 *   §E314 那遍穷尽扫过盘上 1461 个 .bak + 593 个可达 blob + 4190 个对象库 blob，逐枚算权重指纹 ⇒ 没找到 `d13d3c85…`。
 *   但它算的是「文件里那份数组」的哈希，而训练服务记父走的是 `weightsId(loadAny(种子).params)`
 *   = **嵌入成 v7 之后**那份数组的指纹（FEAT_S 123→213 ⇒ 3337→5689 ⇒ sha1 必变）⇒ 差的这一层没人补。
 *   补上之后（见上面 BYWID_EMB）：584 枚的父解析到 **SLOT-e379c62c**（v1.3.57，图上一枚真节点，
 *   实体在 `docs/artifacts/champion-5p-v1.3.58.bak`，git 里 4162e86 / 7859c34 两版槽文件都是它）。
 *   仍然成立的那半句：`tools/ring2-run.mjs` 历史上**无条件**把 EPIRUS_BUNDLE_IN 覆写成这一份 BASE
 *   ⇒ 81% 共父不是"演化收敛"，是 runner 每次都拷同一枚。所以这条边要画，但页脚必须说清它是恒拷。
 *   合成节点这套逻辑保留，只服务**真的**解析不到的那几枚（现在剩 17 行）。*/
const SYNTH_NAME = {};
{ const tally = {};
  for (const r of ROWS) { const p = r.cfg.parent; if (p && p !== '-' && !r.parentOf) tally[p] = (tally[p] || 0) + 1; }
  for (const p of Object.keys(tally)) {
    SYNTH_NAME[p] = tally[p] >= 50
      ? 'RUNNER-BASE ' + p.slice(0, 8) + '…（v1.3.58 BASE · runner 恒拷 EPIRUS_BUNDLE_IN 的产物 · ' + tally[p] + ' 枚共指 · **非血统**）'
      : '父未落档 ' + p.slice(0, 8) + '…（' + tally[p] + ' 枚）'; } }
for (const r of ROWS) r.parentName = r.parentOf ? r.parentOf
  : (r.demoted ? '父不可考（父指针记的是**路径** js/bundled-champion-3p.js ⇒ 反查只能查到**今天的槽主**；'
      + '当时的槽主已被覆写没留档。§E367 之前这里被误接成 ' + r.demoted + '）'
      : (SYNTH_NAME[r.cfg.parent] || ''));
const nSynth = ROWS.filter(r => r.parentName && !r.parentOf).length;
console.log('合成父节点：' + Object.keys(SYNTH_NAME).length + ' 个指纹 ‖ 落到 ' + nSynth + ' 枚身上（其中 ' +
  ROWS.filter(r => SYNTH_NAME[r.cfg.parent] && SYNTH_NAME[r.cfg.parent].indexOf('RUNNER-BASE') === 0).length + ' 枚是 runner 覆写那一格）');
const COLS = ['id', 'fam', 'famLabel', 'ts', 'metaSeed', 'nameSeed', 'parent', 'parentOf', 'parentName', 'wid', 'rulesFp', 'divW', 'divK', 'divRoleW', 'divCatW',
  /* §E367 parentSrc 追加在**最后一列**：现有消费者（chain-scan / dups / directions / gapscan / viewer）都按表头取列，
   *   但插到中间会让任何按下标取数的写法静默错位 ⇒ 新列一律往后放。*/
  'oppsN', 'stockBonus', 'hoardPen', 'dealW', 'firstW', 'whistlePen', 'styleW', 'eTarget', 'eCap', 'gens', 'mode', 'seedEmb', 'parentSrc',
  /* §E487 融合粒的第二父：三条新列一律追加在**表尾**（同 §E367 的规矩 —— 插中间会让按下标取数的写法静默错位）*/
  'parentOf2', 'parentName2', 'parentSrc2'];
const SLOTDEF = { n: 0, label: '旧槽位冠军（不参与家族聚类 ‖ 谱系图上那一行由 viewer 合成 ‖ 横轴 = 训出/写盘时刻）' };
/* ===== §E503 薄图守卫：包 meta 声明"我是两粒父的平均"，而这张表一条父边都没解出来 ⇒ 拒绝 =====
 * 实测的洞（10-08 深夜，我拿 `git archive HEAD` 解出来的干净克隆跑的）：本机 **6 条**第二父边 ‖ 干净克隆 **0 条**，
 *   而 K2 从家族 23（159 枚 · "代数 400→1200"）塌进家族 1 的 868 枚兜底类 ⇒ 融合家族整块没了。
 *   生成器照样 exit 0、页内照样 71 PASS ⇒ **图变薄是静默的**，与 §E489（投影整列写丢）‖ §E491（Hp 空洞冒充 0%）
 *   同族：门测的是"表在不在"，不是"这张图还是不是那张图"。
 * 判据只钉**可控量**：声明数 > 0 而解析数 == 0（"应当有几条"对"实际解出几条"），不钉具体枚数。
 * `--soup-thin-ok` = 承认自己就是要一张薄图（例如只有入库子集的新机器）⇒ 继续跑，但**响亮印出来**，
 *   绝不静默：这是"灰而不判死"和"假装没事"的分界。 */
{ const nSoupRes = ROWS.filter(r => r.psrc === 'soup').length;
  const thin = SOUPDECL.filter(id => !ROWS.some(r => r.id === id && r.psrc === 'soup'));
  if (thin.length && !process.argv.includes('--soup-thin-ok')) {
    console.error('⛔ §E503 融合血统塌了：包 meta 声明 ' + nSoupDeclared + ' 枚是权重平均的产物，' +
      '而本表只解出 ' + nSoupRes + ' 枚的父边（缺的 ' + thin.length + ' 枚：' + thin.slice(0, 8).join(' ‖ ') +
      (thin.length > 8 ? ' …' : '') + '）\n' +
      '   病：融合粒的**父**住在 gitignored 的 `docs/artifacts/…`，这台机器上没有 ⇒ `wid → 节点` 解不开，' +
      '图上就没有紫/红父边（这一笔一旦落盘就把"少了几条边"写进历史，后面再也分不清是数据错还是机器新）。\n' +
      '   要么把父粒 `.bak` 放回 `docs/artifacts/` 再跑本脚本（本机默认就是这样）；\n' +
      '   要么确实要在只有入库子集的机器上出一张薄图：加 `--soup-thin-ok`（会照常印一行警告，不静默）。');
    process.exit(2);
  }
  if (thin.length) console.log('⚠ §E503 薄图模式（`--soup-thin-ok`）：' + thin.length + ' 枚融合粒的父边解不开 ⇒ 图上这几条**不画**（' +
    thin.slice(0, 6).join(' ‖ ') + (thin.length > 6 ? ' …' : '') + '）');
  else console.log('融合血统口径 ✅ ' + nSoupDeclared + ' 枚声明是权重平均的粒，父边全部解析（第二父边 ' +
    ROWS.filter(r => r.pof2).length + ' 条）'); }
const out = [COLS.join('\t')];
for (const r of ROWS) { const d = FAM[r.id] || (SLOTID[r.id] ? SLOTDEF : null); if (!d) continue; const c = r.cfg;
  out.push([r.id, d.n, d.label, (r.ts || '').slice(0, 19), r.seed, r.id.replace(/^.*-/, ''), c.parent.slice(0, 8), r.parentOf, r.parentName, r.wid, c.rulesFp, c.divW, c.divK, c.divRoleW, c.divCatW, c.oppsN,
    c.stockBonus, c.hoardPen, c.dealW, c.firstW, c.whistlePen, c.styleW, c.eTarget, c.eCap, c.gens, c.mode, c.seedEmb, r.psrc || '',
    r.pof2 || '', r.pof2 || '', r.psrc2 || ''].join('\t')); }
/* v1.7.10：落盘行尾跟着**盘上那一份**走，不许写死 '\n'。
 * 为什么（DS 10-14 实测）：本仓工作树是 CRLF（`core.autocrlf=true`），而这里原先写死 `'\n'` ⇒
 *   跑一遍带 D233 ⑤ 腿的门之后，`lineage.tsv` 变成 795 行纯 LF（190413 → 189618 字节），
 *   而**内容逐字节相同**：`git diff` 为空、`git status` 却显示脏 —— 因为 git 见到**尺寸变了**就直接判"改过"。
 *   后果不止"看着脏"：`tools/gate-all.mjs --auto` 是按 `git status` 判改动面的 ⇒ 分类被污染，
 *   而且"工作区干净 ⇒ 按 meta 跑一遍仓库纪律"这条路在整轮之后就不成立了。
 * 同款写法（不是我新发明的）：`champion-map/attach-sc.mjs` 的 `const eol = raw.indexOf('\r\n') >= 0 ? '\r\n' : '\n';`
 *   与 `champion-map/fold-coords.mjs` 的 `EOL`。**新写的落盘器请一律照这个来。** */
const __linPath = join(HERE, 'lineage.tsv');
const __linEol = (existsSync(__linPath) && readFileSync(__linPath, 'utf8').indexOf('\r\n') >= 0) ? '\r\n' : '\n';
writeFileSync(__linPath, out.join(__linEol) + __linEol);
console.log('已写 lineage.tsv（' + (out.length - 1) + ' 行 ‖ ' + defs.length + ' 个家族 ‖ 双父的融合粒 ' +
  ROWS.filter(r => r.pof2).length + ' 枚，第二父边 ' + ROWS.filter(r => r.pof2).length + ' 条）');
for (const d of defs) console.log('  家族 ' + String(d.n).padStart(2) + '  ' + String(d.g.rs.length).padStart(4) + ' 枚  ' + d.label);

